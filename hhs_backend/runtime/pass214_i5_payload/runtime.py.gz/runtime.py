from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any, Iterable

PASS_ID = 214
ITERATION = 5
REPETITIONS = 3
STATUS_READY = "PILOT_READY"

VIRTUAL_MODULE_SOURCES: dict[str, str] = {'vector_cache:baseline': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "vector_cache"\n\nVECTOR_CACHE = ((3, 11, 19, 27, 35, 43, 51, 59, 67, 75, 83, 91, 99, 107, 115, 123, 131, 139, 147, 155, 163, 171, 179, 187, 195, 203, 211, 219, 227, 235, 243, 251, 259, 267, 275, 283, 291, 299, 307, 315, 323, 331, 339, 347, 355, 363, 371, 379, 387, 395, 403, 411, 419, 427, 435, 443, 451, 459, 467, 475, 483, 491, 499, 507), (87, 96, 105, 114, 123, 132, 141, 150, 159, 168, 177, 186, 195, 204, 213, 222, 231, 240, 249, 258, 267, 276, 285, 294, 303, 312, 321, 330, 339, 348, 357, 366, 375, 384, 393, 402, 411, 420, 429, 438, 447, 456, 465, 474, 483, 492, 501, 510, 519, 528, 537, 546, 555, 564, 573, 582, 591, 600, 609, 618, 627, 636, 645, 654), (171, 181, 191, 201, 211, 221, 231, 241, 251, 261, 271, 281, 291, 301, 311, 321, 331, 341, 351, 361, 371, 381, 391, 401, 411, 421, 431, 441, 451, 461, 471, 481, 491, 501, 511, 521, 531, 541, 551, 561, 571, 581, 591, 601, 611, 621, 631, 641, 651, 661, 671, 681, 691, 701, 711, 721, 731, 741, 751, 761, 771, 781, 791, 801), (255, 266, 277, 288, 299, 310, 321, 332, 343, 354, 365, 376, 387, 398, 409, 420, 431, 442, 453, 464, 475, 486, 497, 508, 519, 530, 541, 552, 563, 574, 585, 596, 607, 618, 629, 640, 651, 662, 673, 684, 695, 706, 717, 728, 739, 750, 761, 772, 783, 794, 805, 816, 827, 838, 849, 860, 871, 882, 893, 904, 915, 926, 937, 948), (339, 351, 363, 375, 387, 399, 411, 423, 435, 447, 459, 471, 483, 495, 507, 519, 531, 543, 555, 567, 579, 591, 603, 615, 627, 639, 651, 663, 675, 687, 699, 711, 723, 735, 747, 759, 771, 783, 795, 807, 819, 831, 843, 855, 867, 879, 891, 903, 915, 927, 939, 951, 963, 975, 987, 999, 1011, 1023, 1035, 1047, 1059, 1071, 1083, 1095), (423, 436, 449, 462, 475, 488, 501, 514, 527, 540, 553, 566, 579, 592, 605, 618, 631, 644, 657, 670, 683, 696, 709, 722, 735, 748, 761, 774, 787, 800, 813, 826, 839, 852, 865, 878, 891, 904, 917, 930, 943, 956, 969, 982, 995, 1008, 1021, 1034, 1047, 1060, 1073, 1086, 1099, 1112, 1125, 1138, 1151, 1164, 1177, 1190, 1203, 1216, 1229, 1242), (507, 521, 535, 549, 563, 577, 591, 605, 619, 633, 647, 661, 675, 689, 703, 717, 731, 745, 759, 773, 787, 801, 815, 829, 843, 857, 871, 885, 899, 913, 927, 941, 955, 969, 983, 997, 1011, 1025, 1039, 1053, 1067, 1081, 1095, 1109, 1123, 1137, 1151, 1165, 1179, 1193, 1207, 1221, 1235, 1249, 1263, 1277, 1291, 1305, 1319, 1333, 1347, 1361, 1375, 1389), (591, 606, 621, 636, 651, 666, 681, 696, 711, 726, 741, 756, 771, 786, 801, 816, 831, 846, 861, 876, 891, 906, 921, 936, 951, 966, 981, 996, 1011, 1026, 1041, 1056, 1071, 1086, 1101, 1116, 1131, 1146, 1161, 1176, 1191, 1206, 1221, 1236, 1251, 1266, 1281, 1296, 1311, 1326, 1341, 1356, 1371, 1386, 1401, 1416, 1431, 1446, 1461, 1476, 1491, 1506, 1521, 1536), (675, 691, 707, 723, 739, 755, 771, 787, 803, 819, 835, 851, 867, 883, 899, 915, 931, 947, 963, 979, 995, 1011, 1027, 1043, 1059, 1075, 1091, 1107, 1123, 1139, 1155, 1171, 1187, 1203, 1219, 1235, 1251, 1267, 1283, 1299, 1315, 1331, 1347, 1363, 1379, 1395, 1411, 1427, 1443, 1459, 1475, 1491, 1507, 1523, 1539, 1555, 1571, 1587, 1603, 1619, 1635, 1651, 1667, 1683))\n\ndef self_test() -> dict[str, object]:\n    payload = {"vectors": [list(row) for row in VECTOR_CACHE], "row_sums": [sum(row) for row in VECTOR_CACHE]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'vector_cache:target': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "vector_cache"\n\n\ndef _value(row: int, col: int) -> int:\n    return (row * 81 + col * 7 + (row + 1) * (col + 3)) % 5184\n\n\ndef self_test() -> dict[str, object]:\n    vectors = [[_value(row, col) for col in range(64)] for row in range(9)]\n    payload = {"vectors": vectors, "row_sums": [sum(row) for row in vectors]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'wrapper_duplication:baseline': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "wrapper_duplication"\n\ndef wrapper_0(value: int) -> tuple[int, int, int]:\n    return (0, (value * value + 0 * 72) % 5184, (value + 0 * 9) % 243)\n\ndef wrapper_1(value: int) -> tuple[int, int, int]:\n    return (1, (value * value + 1 * 72) % 5184, (value + 1 * 9) % 243)\n\ndef wrapper_2(value: int) -> tuple[int, int, int]:\n    return (2, (value * value + 2 * 72) % 5184, (value + 2 * 9) % 243)\n\ndef wrapper_3(value: int) -> tuple[int, int, int]:\n    return (3, (value * value + 3 * 72) % 5184, (value + 3 * 9) % 243)\n\ndef wrapper_4(value: int) -> tuple[int, int, int]:\n    return (4, (value * value + 4 * 72) % 5184, (value + 4 * 9) % 243)\n\ndef wrapper_5(value: int) -> tuple[int, int, int]:\n    return (5, (value * value + 5 * 72) % 5184, (value + 5 * 9) % 243)\n\ndef wrapper_6(value: int) -> tuple[int, int, int]:\n    return (6, (value * value + 6 * 72) % 5184, (value + 6 * 9) % 243)\n\ndef wrapper_7(value: int) -> tuple[int, int, int]:\n    return (7, (value * value + 7 * 72) % 5184, (value + 7 * 9) % 243)\n\ndef wrapper_8(value: int) -> tuple[int, int, int]:\n    return (8, (value * value + 8 * 72) % 5184, (value + 8 * 9) % 243)\n\ndef wrapper_9(value: int) -> tuple[int, int, int]:\n    return (9, (value * value + 9 * 72) % 5184, (value + 9 * 9) % 243)\n\ndef wrapper_10(value: int) -> tuple[int, int, int]:\n    return (10, (value * value + 10 * 72) % 5184, (value + 10 * 9) % 243)\n\ndef wrapper_11(value: int) -> tuple[int, int, int]:\n    return (11, (value * value + 11 * 72) % 5184, (value + 11 * 9) % 243)\n\ndef self_test() -> dict[str, object]:\n    payload = {"outputs": [\n        list(wrapper_0(5)),\n        list(wrapper_1(6)),\n        list(wrapper_2(7)),\n        list(wrapper_3(8)),\n        list(wrapper_4(9)),\n        list(wrapper_5(10)),\n        list(wrapper_6(11)),\n        list(wrapper_7(12)),\n        list(wrapper_8(13)),\n        list(wrapper_9(14)),\n        list(wrapper_10(15)),\n        list(wrapper_11(16)),\n    ]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'wrapper_duplication:target': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "wrapper_duplication"\n\n\ndef _wrapper(index: int, value: int) -> tuple[int, int, int]:\n    return (index, (value * value + index * 72) % 5184, (value + index * 9) % 243)\n\n\ndef self_test() -> dict[str, object]:\n    payload = {"outputs": [list(_wrapper(index, index + 5)) for index in range(12)]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'numeric_lookup:baseline': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "numeric_lookup"\n\nLOOKUP = {0: 5, 1: 9, 2: 15, 3: 23, 4: 33, 5: 45, 6: 59, 7: 75, 8: 93, 9: 113, 10: 135, 11: 159, 12: 185, 13: 213, 14: 243, 15: 275, 16: 309, 17: 345, 18: 383, 19: 423, 20: 465, 21: 509, 22: 555, 23: 603, 24: 653, 25: 705, 26: 759, 27: 815, 28: 873, 29: 933, 30: 995, 31: 1059, 32: 1125, 33: 1193, 34: 1263, 35: 1335, 36: 1409, 37: 1485, 38: 1563, 39: 1643, 40: 1725, 41: 1809, 42: 1895, 43: 1983, 44: 2073, 45: 2165, 46: 2259, 47: 2355, 48: 2453, 49: 2553, 50: 2655, 51: 2759, 52: 2865, 53: 2973, 54: 3083, 55: 3195, 56: 3309, 57: 3425, 58: 3543, 59: 3663, 60: 3785, 61: 3909, 62: 4035, 63: 4163, 64: 4293, 65: 4425, 66: 4559, 67: 4695, 68: 4833, 69: 4973, 70: 5115, 71: 75, 72: 221, 73: 369, 74: 519, 75: 671, 76: 825, 77: 981, 78: 1139, 79: 1299, 80: 1461, 81: 1625, 82: 1791, 83: 1959, 84: 2129, 85: 2301, 86: 2475, 87: 2651, 88: 2829, 89: 3009, 90: 3191, 91: 3375, 92: 3561, 93: 3749, 94: 3939, 95: 4131, 96: 4325, 97: 4521, 98: 4719, 99: 4919, 100: 5121, 101: 141, 102: 347, 103: 555, 104: 765, 105: 977, 106: 1191, 107: 1407, 108: 1625, 109: 1845, 110: 2067, 111: 2291, 112: 2517, 113: 2745, 114: 2975, 115: 3207, 116: 3441, 117: 3677, 118: 3915, 119: 4155, 120: 4397, 121: 4641, 122: 4887, 123: 5135, 124: 201, 125: 453, 126: 707, 127: 963, 128: 1221, 129: 1481, 130: 1743, 131: 2007, 132: 2273, 133: 2541, 134: 2811, 135: 3083, 136: 3357, 137: 3633, 138: 3911, 139: 4191, 140: 4473, 141: 4757, 142: 5043, 143: 147, 144: 437, 145: 729, 146: 1023, 147: 1319, 148: 1617, 149: 1917, 150: 2219, 151: 2523, 152: 2829, 153: 3137, 154: 3447, 155: 3759, 156: 4073, 157: 4389, 158: 4707, 159: 5027, 160: 165, 161: 489, 162: 815, 163: 1143, 164: 1473, 165: 1805, 166: 2139, 167: 2475, 168: 2813, 169: 3153, 170: 3495, 171: 3839, 172: 4185, 173: 4533, 174: 4883, 175: 51, 176: 405, 177: 761, 178: 1119, 179: 1479, 180: 1841, 181: 2205, 182: 2571, 183: 2939, 184: 3309, 185: 3681, 186: 4055, 187: 4431, 188: 4809, 189: 5, 190: 387, 191: 771, 192: 1157, 193: 1545, 194: 1935, 195: 2327, 196: 2721, 197: 3117, 198: 3515, 199: 3915, 200: 4317, 201: 4721, 202: 5127, 203: 351, 204: 761, 205: 1173, 206: 1587, 207: 2003, 208: 2421, 209: 2841, 210: 3263, 211: 3687, 212: 4113, 213: 4541, 214: 4971, 215: 219, 216: 653, 217: 1089, 218: 1527, 219: 1967, 220: 2409, 221: 2853, 222: 3299, 223: 3747, 224: 4197, 225: 4649, 226: 5103, 227: 375, 228: 833, 229: 1293, 230: 1755, 231: 2219, 232: 2685, 233: 3153, 234: 3623, 235: 4095, 236: 4569, 237: 5045, 238: 339, 239: 819, 240: 1301, 241: 1785, 242: 2271}\n\ndef self_test() -> dict[str, object]:\n    values = [LOOKUP[index] for index in range(243)]\n    payload = {"values": values, "sum": sum(values), "last": values[-1]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'numeric_lookup:target': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "numeric_lookup"\n\n\ndef _lookup(index: int) -> int:\n    return (index * index + 3 * index + 5) % 5184\n\n\ndef self_test() -> dict[str, object]:\n    values = [_lookup(index) for index in range(243)]\n    payload = {"values": values, "sum": sum(values), "last": values[-1]}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'serialization_import:baseline': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "serialization_import"\n\nSERIALIZED = \'{"records":[{"active":false,"cell":0,"lane":0,"phase":0,"value":0},{"active":true,"cell":1,"lane":1,"phase":1,"value":73},{"active":true,"cell":2,"lane":2,"phase":2,"value":148},{"active":false,"cell":3,"lane":3,"phase":3,"value":225},{"active":true,"cell":4,"lane":4,"phase":4,"value":304},{"active":true,"cell":5,"lane":5,"phase":5,"value":385},{"active":false,"cell":6,"lane":6,"phase":6,"value":468},{"active":true,"cell":7,"lane":7,"phase":7,"value":553},{"active":true,"cell":8,"lane":8,"phase":8,"value":640},{"active":false,"cell":9,"lane":9,"phase":9,"value":729},{"active":true,"cell":10,"lane":10,"phase":10,"value":820},{"active":true,"cell":11,"lane":11,"phase":11,"value":913},{"active":false,"cell":12,"lane":12,"phase":12,"value":1008},{"active":true,"cell":13,"lane":13,"phase":13,"value":1105},{"active":true,"cell":14,"lane":14,"phase":14,"value":1204},{"active":false,"cell":15,"lane":15,"phase":15,"value":1305},{"active":true,"cell":16,"lane":16,"phase":16,"value":1408},{"active":true,"cell":17,"lane":17,"phase":17,"value":1513},{"active":false,"cell":18,"lane":18,"phase":18,"value":1620},{"active":true,"cell":19,"lane":19,"phase":19,"value":1729},{"active":true,"cell":20,"lane":20,"phase":20,"value":1840},{"active":false,"cell":21,"lane":21,"phase":21,"value":1953},{"active":true,"cell":22,"lane":22,"phase":22,"value":2068},{"active":true,"cell":23,"lane":23,"phase":23,"value":2185},{"active":false,"cell":24,"lane":24,"phase":24,"value":2304},{"active":true,"cell":25,"lane":25,"phase":25,"value":2425},{"active":true,"cell":26,"lane":26,"phase":26,"value":2548},{"active":false,"cell":27,"lane":27,"phase":27,"value":2673},{"active":true,"cell":28,"lane":28,"phase":28,"value":2800},{"active":true,"cell":29,"lane":29,"phase":29,"value":2929},{"active":false,"cell":30,"lane":30,"phase":30,"value":3060},{"active":true,"cell":31,"lane":31,"phase":31,"value":3193},{"active":true,"cell":32,"lane":32,"phase":32,"value":3328},{"active":false,"cell":33,"lane":33,"phase":33,"value":3465},{"active":true,"cell":34,"lane":34,"phase":34,"value":3604},{"active":true,"cell":35,"lane":35,"phase":35,"value":3745},{"active":false,"cell":36,"lane":36,"phase":36,"value":3888},{"active":true,"cell":37,"lane":37,"phase":37,"value":4033},{"active":true,"cell":38,"lane":38,"phase":38,"value":4180},{"active":false,"cell":39,"lane":39,"phase":39,"value":4329},{"active":true,"cell":40,"lane":40,"phase":40,"value":4480},{"active":true,"cell":41,"lane":41,"phase":41,"value":4633},{"active":false,"cell":42,"lane":42,"phase":42,"value":4788},{"active":true,"cell":43,"lane":43,"phase":43,"value":4945},{"active":true,"cell":44,"lane":44,"phase":44,"value":5104},{"active":false,"cell":45,"lane":45,"phase":45,"value":81},{"active":true,"cell":46,"lane":46,"phase":46,"value":244},{"active":true,"cell":47,"lane":47,"phase":47,"value":409},{"active":false,"cell":48,"lane":48,"phase":48,"value":576},{"active":true,"cell":49,"lane":49,"phase":49,"value":745},{"active":true,"cell":50,"lane":50,"phase":50,"value":916},{"active":false,"cell":51,"lane":51,"phase":51,"value":1089},{"active":true,"cell":52,"lane":52,"phase":52,"value":1264},{"active":true,"cell":53,"lane":53,"phase":53,"value":1441},{"active":false,"cell":54,"lane":54,"phase":54,"value":1620},{"active":true,"cell":55,"lane":55,"phase":55,"value":1801},{"active":true,"cell":56,"lane":56,"phase":56,"value":1984},{"active":false,"cell":57,"lane":57,"phase":57,"value":2169},{"active":true,"cell":58,"lane":58,"phase":58,"value":2356},{"active":true,"cell":59,"lane":59,"phase":59,"value":2545},{"active":false,"cell":60,"lane":60,"phase":60,"value":2736},{"active":true,"cell":61,"lane":61,"phase":61,"value":2929},{"active":true,"cell":62,"lane":62,"phase":62,"value":3124},{"active":false,"cell":63,"lane":63,"phase":63,"value":3321},{"active":true,"cell":64,"lane":0,"phase":64,"value":3520},{"active":true,"cell":65,"lane":1,"phase":65,"value":3721},{"active":false,"cell":66,"lane":2,"phase":66,"value":3924},{"active":true,"cell":67,"lane":3,"phase":67,"value":4129},{"active":true,"cell":68,"lane":4,"phase":68,"value":4336},{"active":false,"cell":69,"lane":5,"phase":69,"value":4545},{"active":true,"cell":70,"lane":6,"phase":70,"value":4756},{"active":true,"cell":71,"lane":7,"phase":71,"value":4969},{"active":false,"cell":72,"lane":8,"phase":72,"value":0},{"active":true,"cell":73,"lane":9,"phase":73,"value":217},{"active":true,"cell":74,"lane":10,"phase":74,"value":436},{"active":false,"cell":75,"lane":11,"phase":75,"value":657},{"active":true,"cell":76,"lane":12,"phase":76,"value":880},{"active":true,"cell":77,"lane":13,"phase":77,"value":1105},{"active":false,"cell":78,"lane":14,"phase":78,"value":1332},{"active":true,"cell":79,"lane":15,"phase":79,"value":1561},{"active":true,"cell":80,"lane":16,"phase":80,"value":1792}],"schema":"HHS_PASS214_I5_SERIALIZATION_FIXTURE_V1"}\'\n\ndef self_test() -> dict[str, object]:\n    payload = json.loads(SERIALIZED)\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'serialization_import:target': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "serialization_import"\n\n\ndef self_test() -> dict[str, object]:\n    payload = {\n        "records": [\n            {\n                "active": index % 3 != 0,\n                "cell": index,\n                "lane": index % 64,\n                "phase": index % 243,\n                "value": (index * 72 + index * index) % 5184,\n            }\n            for index in range(81)\n        ],\n        "schema": "HHS_PASS214_I5_SERIALIZATION_FIXTURE_V1",\n    }\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'coprime_lookup:baseline': 'from __future__ import annotations\n\nimport hashlib\nimport json\n\nFAMILY = "coprime_lookup"\n\nCOPRIME_RESIDUES = (1, 5, 7, 11, 13, 17, 19, 23, 25, 29, 31, 35, 37, 41, 43, 47, 49, 53, 55, 59, 61, 65, 67, 71, 73, 77, 79, 83, 85, 89, 91, 95, 97, 101, 103, 107, 109, 113, 115, 119, 121, 125, 127, 131, 133, 137, 139, 143, 145, 149, 151, 155, 157, 161, 163, 167, 169, 173, 175, 179, 181, 185, 187, 191, 193, 197, 199, 203, 205, 209, 211, 215, 217, 221, 223, 227, 229, 233, 235, 239, 241, 245, 247, 251, 253, 257, 259, 263, 265, 269, 271, 275, 277, 281, 283, 287, 289, 293, 295, 299, 301, 305, 307, 311, 313, 317, 319, 323, 325, 329, 331, 335, 337, 341, 343, 347, 349, 353, 355, 359, 361, 365, 367, 371, 373, 377, 379, 383, 385, 389, 391, 395, 397, 401, 403, 407, 409, 413, 415, 419, 421, 425, 427, 431, 433, 437, 439, 443, 445, 449, 451, 455, 457, 461, 463, 467, 469, 473, 475, 479, 481, 485, 487, 491, 493, 497, 499, 503, 505, 509, 511, 515, 517, 521, 523, 527, 529, 533, 535, 539, 541, 545, 547, 551, 553, 557, 559, 563, 565, 569, 571, 575, 577, 581, 583, 587, 589, 593, 595, 599, 601, 605, 607, 611, 613, 617, 619, 623, 625, 629, 631, 635, 637, 641, 643, 647, 649, 653, 655, 659, 661, 665, 667, 671, 673, 677, 679, 683, 685, 689, 691, 695, 697, 701, 703, 707, 709, 713, 715, 719, 721, 725, 727, 731, 733, 737, 739, 743, 745, 749, 751, 755, 757, 761, 763, 767, 769, 773, 775, 779, 781, 785, 787, 791, 793, 797, 799, 803, 805, 809, 811, 815, 817, 821, 823, 827, 829, 833, 835, 839, 841, 845, 847, 851, 853, 857, 859, 863, 865, 869, 871, 875, 877, 881, 883, 887, 889, 893, 895, 899, 901, 905, 907, 911, 913, 917, 919, 923, 925, 929, 931, 935, 937, 941, 943, 947, 949, 953, 955, 959, 961, 965, 967, 971, 973, 977, 979, 983, 985, 989, 991, 995, 997, 1001, 1003, 1007, 1009, 1013, 1015, 1019, 1021, 1025, 1027, 1031, 1033, 1037, 1039, 1043, 1045, 1049, 1051, 1055, 1057, 1061, 1063, 1067, 1069, 1073, 1075, 1079, 1081, 1085, 1087, 1091, 1093, 1097, 1099, 1103, 1105, 1109, 1111, 1115, 1117, 1121, 1123, 1127, 1129, 1133, 1135, 1139, 1141, 1145, 1147, 1151, 1153, 1157, 1159, 1163, 1165, 1169, 1171, 1175, 1177, 1181, 1183, 1187, 1189, 1193, 1195, 1199, 1201, 1205, 1207, 1211, 1213, 1217, 1219, 1223, 1225, 1229, 1231, 1235, 1237, 1241, 1243, 1247, 1249, 1253, 1255, 1259, 1261, 1265, 1267, 1271, 1273, 1277, 1279, 1283, 1285, 1289, 1291, 1295, 1297, 1301, 1303, 1307, 1309, 1313, 1315, 1319, 1321, 1325, 1327, 1331, 1333, 1337, 1339, 1343, 1345, 1349, 1351, 1355, 1357, 1361, 1363, 1367, 1369, 1373, 1375, 1379, 1381, 1385, 1387, 1391, 1393, 1397, 1399, 1403, 1405, 1409, 1411, 1415, 1417, 1421, 1423, 1427, 1429, 1433, 1435, 1439, 1441, 1445, 1447, 1451, 1453, 1457, 1459, 1463, 1465, 1469, 1471, 1475, 1477, 1481, 1483, 1487, 1489, 1493, 1495, 1499, 1501, 1505, 1507, 1511, 1513, 1517, 1519, 1523, 1525, 1529, 1531, 1535, 1537, 1541, 1543, 1547, 1549, 1553, 1555, 1559, 1561, 1565, 1567, 1571, 1573, 1577, 1579, 1583, 1585, 1589, 1591, 1595, 1597, 1601, 1603, 1607, 1609, 1613, 1615, 1619, 1621, 1625, 1627, 1631, 1633, 1637, 1639, 1643, 1645, 1649, 1651, 1655, 1657, 1661, 1663, 1667, 1669, 1673, 1675, 1679, 1681, 1685, 1687, 1691, 1693, 1697, 1699, 1703, 1705, 1709, 1711, 1715, 1717, 1721, 1723, 1727, 1729, 1733, 1735, 1739, 1741, 1745, 1747, 1751, 1753, 1757, 1759, 1763, 1765, 1769, 1771, 1775, 1777, 1781, 1783, 1787, 1789, 1793, 1795, 1799, 1801, 1805, 1807, 1811, 1813, 1817, 1819, 1823, 1825, 1829, 1831, 1835, 1837, 1841, 1843, 1847, 1849, 1853, 1855, 1859, 1861, 1865, 1867, 1871, 1873, 1877, 1879, 1883, 1885, 1889, 1891, 1895, 1897, 1901, 1903, 1907, 1909, 1913, 1915, 1919, 1921, 1925, 1927, 1931, 1933, 1937, 1939, 1943, 1945, 1949, 1951, 1955, 1957, 1961, 1963, 1967, 1969, 1973, 1975, 1979, 1981, 1985, 1987, 1991, 1993, 1997, 1999, 2003, 2005, 2009, 2011, 2015, 2017, 2021, 2023, 2027, 2029, 2033, 2035, 2039, 2041, 2045, 2047, 2051, 2053, 2057, 2059, 2063, 2065, 2069, 2071, 2075, 2077, 2081, 2083, 2087, 2089, 2093, 2095, 2099, 2101, 2105, 2107, 2111, 2113, 2117, 2119, 2123, 2125, 2129, 2131, 2135, 2137, 2141, 2143, 2147, 2149, 2153, 2155, 2159, 2161, 2165, 2167, 2171, 2173, 2177, 2179, 2183, 2185, 2189, 2191, 2195, 2197, 2201, 2203, 2207, 2209, 2213, 2215, 2219, 2221, 2225, 2227, 2231, 2233, 2237, 2239, 2243, 2245, 2249, 2251, 2255, 2257, 2261, 2263, 2267, 2269, 2273, 2275, 2279, 2281, 2285, 2287, 2291, 2293, 2297, 2299, 2303, 2305, 2309, 2311, 2315, 2317, 2321, 2323, 2327, 2329, 2333, 2335, 2339, 2341, 2345, 2347, 2351, 2353, 2357, 2359, 2363, 2365, 2369, 2371, 2375, 2377, 2381, 2383, 2387, 2389, 2393, 2395, 2399, 2401, 2405, 2407, 2411, 2413, 2417, 2419, 2423, 2425, 2429, 2431, 2435, 2437, 2441, 2443, 2447, 2449, 2453, 2455, 2459, 2461, 2465, 2467, 2471, 2473, 2477, 2479, 2483, 2485, 2489, 2491, 2495, 2497, 2501, 2503, 2507, 2509, 2513, 2515, 2519, 2521, 2525, 2527, 2531, 2533, 2537, 2539, 2543, 2545, 2549, 2551, 2555, 2557, 2561, 2563, 2567, 2569, 2573, 2575, 2579, 2581, 2585, 2587, 2591, 2593, 2597, 2599, 2603, 2605, 2609, 2611, 2615, 2617, 2621, 2623, 2627, 2629, 2633, 2635, 2639, 2641, 2645, 2647, 2651, 2653, 2657, 2659, 2663, 2665, 2669, 2671, 2675, 2677, 2681, 2683, 2687, 2689, 2693, 2695, 2699, 2701, 2705, 2707, 2711, 2713, 2717, 2719, 2723, 2725, 2729, 2731, 2735, 2737, 2741, 2743, 2747, 2749, 2753, 2755, 2759, 2761, 2765, 2767, 2771, 2773, 2777, 2779, 2783, 2785, 2789, 2791, 2795, 2797, 2801, 2803, 2807, 2809, 2813, 2815, 2819, 2821, 2825, 2827, 2831, 2833, 2837, 2839, 2843, 2845, 2849, 2851, 2855, 2857, 2861, 2863, 2867, 2869, 2873, 2875, 2879, 2881, 2885, 2887, 2891, 2893, 2897, 2899, 2903, 2905, 2909, 2911, 2915, 2917, 2921, 2923, 2927, 2929, 2933, 2935, 2939, 2941, 2945, 2947, 2951, 2953, 2957, 2959, 2963, 2965, 2969, 2971, 2975, 2977, 2981, 2983, 2987, 2989, 2993, 2995, 2999, 3001, 3005, 3007, 3011, 3013, 3017, 3019, 3023, 3025, 3029, 3031, 3035, 3037, 3041, 3043, 3047, 3049, 3053, 3055, 3059, 3061, 3065, 3067, 3071, 3073, 3077, 3079, 3083, 3085, 3089, 3091, 3095, 3097, 3101, 3103, 3107, 3109, 3113, 3115, 3119, 3121, 3125, 3127, 3131, 3133, 3137, 3139, 3143, 3145, 3149, 3151, 3155, 3157, 3161, 3163, 3167, 3169, 3173, 3175, 3179, 3181, 3185, 3187, 3191, 3193, 3197, 3199, 3203, 3205, 3209, 3211, 3215, 3217, 3221, 3223, 3227, 3229, 3233, 3235, 3239, 3241, 3245, 3247, 3251, 3253, 3257, 3259, 3263, 3265, 3269, 3271, 3275, 3277, 3281, 3283, 3287, 3289, 3293, 3295, 3299, 3301, 3305, 3307, 3311, 3313, 3317, 3319, 3323, 3325, 3329, 3331, 3335, 3337, 3341, 3343, 3347, 3349, 3353, 3355, 3359, 3361, 3365, 3367, 3371, 3373, 3377, 3379, 3383, 3385, 3389, 3391, 3395, 3397, 3401, 3403, 3407, 3409, 3413, 3415, 3419, 3421, 3425, 3427, 3431, 3433, 3437, 3439, 3443, 3445, 3449, 3451, 3455, 3457, 3461, 3463, 3467, 3469, 3473, 3475, 3479, 3481, 3485, 3487, 3491, 3493, 3497, 3499, 3503, 3505, 3509, 3511, 3515, 3517, 3521, 3523, 3527, 3529, 3533, 3535, 3539, 3541, 3545, 3547, 3551, 3553, 3557, 3559, 3563, 3565, 3569, 3571, 3575, 3577, 3581, 3583, 3587, 3589, 3593, 3595, 3599, 3601, 3605, 3607, 3611, 3613, 3617, 3619, 3623, 3625, 3629, 3631, 3635, 3637, 3641, 3643, 3647, 3649, 3653, 3655, 3659, 3661, 3665, 3667, 3671, 3673, 3677, 3679, 3683, 3685, 3689, 3691, 3695, 3697, 3701, 3703, 3707, 3709, 3713, 3715, 3719, 3721, 3725, 3727, 3731, 3733, 3737, 3739, 3743, 3745, 3749, 3751, 3755, 3757, 3761, 3763, 3767, 3769, 3773, 3775, 3779, 3781, 3785, 3787, 3791, 3793, 3797, 3799, 3803, 3805, 3809, 3811, 3815, 3817, 3821, 3823, 3827, 3829, 3833, 3835, 3839, 3841, 3845, 3847, 3851, 3853, 3857, 3859, 3863, 3865, 3869, 3871, 3875, 3877, 3881, 3883, 3887, 3889, 3893, 3895, 3899, 3901, 3905, 3907, 3911, 3913, 3917, 3919, 3923, 3925, 3929, 3931, 3935, 3937, 3941, 3943, 3947, 3949, 3953, 3955, 3959, 3961, 3965, 3967, 3971, 3973, 3977, 3979, 3983, 3985, 3989, 3991, 3995, 3997, 4001, 4003, 4007, 4009, 4013, 4015, 4019, 4021, 4025, 4027, 4031, 4033, 4037, 4039, 4043, 4045, 4049, 4051, 4055, 4057, 4061, 4063, 4067, 4069, 4073, 4075, 4079, 4081, 4085, 4087, 4091, 4093, 4097, 4099, 4103, 4105, 4109, 4111, 4115, 4117, 4121, 4123, 4127, 4129, 4133, 4135, 4139, 4141, 4145, 4147, 4151, 4153, 4157, 4159, 4163, 4165, 4169, 4171, 4175, 4177, 4181, 4183, 4187, 4189, 4193, 4195, 4199, 4201, 4205, 4207, 4211, 4213, 4217, 4219, 4223, 4225, 4229, 4231, 4235, 4237, 4241, 4243, 4247, 4249, 4253, 4255, 4259, 4261, 4265, 4267, 4271, 4273, 4277, 4279, 4283, 4285, 4289, 4291, 4295, 4297, 4301, 4303, 4307, 4309, 4313, 4315, 4319, 4321, 4325, 4327, 4331, 4333, 4337, 4339, 4343, 4345, 4349, 4351, 4355, 4357, 4361, 4363, 4367, 4369, 4373, 4375, 4379, 4381, 4385, 4387, 4391, 4393, 4397, 4399, 4403, 4405, 4409, 4411, 4415, 4417, 4421, 4423, 4427, 4429, 4433, 4435, 4439, 4441, 4445, 4447, 4451, 4453, 4457, 4459, 4463, 4465, 4469, 4471, 4475, 4477, 4481, 4483, 4487, 4489, 4493, 4495, 4499, 4501, 4505, 4507, 4511, 4513, 4517, 4519, 4523, 4525, 4529, 4531, 4535, 4537, 4541, 4543, 4547, 4549, 4553, 4555, 4559, 4561, 4565, 4567, 4571, 4573, 4577, 4579, 4583, 4585, 4589, 4591, 4595, 4597, 4601, 4603, 4607, 4609, 4613, 4615, 4619, 4621, 4625, 4627, 4631, 4633, 4637, 4639, 4643, 4645, 4649, 4651, 4655, 4657, 4661, 4663, 4667, 4669, 4673, 4675, 4679, 4681, 4685, 4687, 4691, 4693, 4697, 4699, 4703, 4705, 4709, 4711, 4715, 4717, 4721, 4723, 4727, 4729, 4733, 4735, 4739, 4741, 4745, 4747, 4751, 4753, 4757, 4759, 4763, 4765, 4769, 4771, 4775, 4777, 4781, 4783, 4787, 4789, 4793, 4795, 4799, 4801, 4805, 4807, 4811, 4813, 4817, 4819, 4823, 4825, 4829, 4831, 4835, 4837, 4841, 4843, 4847, 4849, 4853, 4855, 4859, 4861, 4865, 4867, 4871, 4873, 4877, 4879, 4883, 4885, 4889, 4891, 4895, 4897, 4901, 4903, 4907, 4909, 4913, 4915, 4919, 4921, 4925, 4927, 4931, 4933, 4937, 4939, 4943, 4945, 4949, 4951, 4955, 4957, 4961, 4963, 4967, 4969, 4973, 4975, 4979, 4981, 4985, 4987, 4991, 4993, 4997, 4999, 5003, 5005, 5009, 5011, 5015, 5017, 5021, 5023, 5027, 5029, 5033, 5035, 5039, 5041, 5045, 5047, 5051, 5053, 5057, 5059, 5063, 5065, 5069, 5071, 5075, 5077, 5081, 5083, 5087, 5089, 5093, 5095, 5099, 5101, 5105, 5107, 5111, 5113, 5117, 5119, 5123, 5125, 5129, 5131, 5135, 5137, 5141, 5143, 5147, 5149, 5153, 5155, 5159, 5161, 5165, 5167, 5171, 5173, 5177, 5179, 5183)\n\ndef self_test() -> dict[str, object]:\n    payload = {"count": len(COPRIME_RESIDUES), "first": list(COPRIME_RESIDUES[:18]), "last": list(COPRIME_RESIDUES[-18:]), "sum_mod_5184": sum(COPRIME_RESIDUES) % 5184}\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n', 'coprime_lookup:target': 'from __future__ import annotations\n\nimport hashlib\nimport json\nimport math\n\nFAMILY = "coprime_lookup"\n\n\ndef self_test() -> dict[str, object]:\n    residues = [value for value in range(1, 5184) if math.gcd(value, 72) == 1]\n    payload = {\n        "count": len(residues),\n        "first": residues[:18],\n        "last": residues[-18:],\n        "sum_mod_5184": sum(residues) % 5184,\n    }\n    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")\n    return {\n        "family": FAMILY,\n        "payload": payload,\n        "payload_sha256": hashlib.sha256(encoded).hexdigest(),\n    }\n'}

FAMILY_SPECS: tuple[dict[str, str], ...] = (
    {"family": "vector_cache", "source_id": "vector_cache:baseline", "target_id": "vector_cache:target", "callable_name": "self_test"},
    {"family": "wrapper_duplication", "source_id": "wrapper_duplication:baseline", "target_id": "wrapper_duplication:target", "callable_name": "self_test"},
    {"family": "numeric_lookup", "source_id": "numeric_lookup:baseline", "target_id": "numeric_lookup:target", "callable_name": "self_test"},
    {"family": "serialization_import", "source_id": "serialization_import:baseline", "target_id": "serialization_import:target", "callable_name": "self_test"},
    {"family": "coprime_lookup", "source_id": "coprime_lookup:baseline", "target_id": "coprime_lookup:target", "callable_name": "self_test"},
)


def _reject_float(value: Any, path: str = "$") -> None:
    if isinstance(value, float):
        raise TypeError(f"floating-point output is forbidden at {path}")
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_float(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _reject_float(item, f"{path}[{index}]")


def canonical_json(value: Any) -> str:
    _reject_float(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _execute_virtual(module_id: str, callable_name: str) -> Any:
    source = VIRTUAL_MODULE_SOURCES[module_id]
    namespace: dict[str, Any] = {"__name__": f"hhs_pass214_i5.{module_id.replace(':', '.')}"}
    exec(compile(source, f"<{module_id}>", "exec"), namespace, namespace)
    value = namespace[callable_name]()
    _reject_float(value)
    return value


def _clean_environment() -> dict[str, str]:
    allowed = {"PATH", "HOME", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "TMPDIR"}
    env = {key: value for key, value in os.environ.items() if key in allowed}
    env["PYTHONHASHSEED"] = "0"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def execute_isolated(module_id: str, callable_name: str, *, timeout_seconds: int = 30) -> Any:
    completed = subprocess.run(
        [sys.executable, "-m", "hhs_backend.runtime.hhs_pass214_iteration5_callable_corpus_v1", "--child", module_id, callable_name],
        cwd=Path(__file__).resolve().parents[2],
        env=_clean_environment(),
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(f"isolated callable failed ({module_id}:{callable_name}): {completed.stderr.strip()}")
    return json.loads(completed.stdout)


def evaluate_pair(spec: dict[str, str]) -> dict[str, Any]:
    source_id = spec["source_id"]
    target_id = spec["target_id"]
    callable_name = spec["callable_name"]
    source_value = execute_isolated(source_id, callable_name)
    target_value = execute_isolated(target_id, callable_name)
    source_canonical = canonical_json(source_value)
    target_canonical = canonical_json(target_value)
    source_bytes = len(VIRTUAL_MODULE_SOURCES[source_id].encode("utf-8"))
    target_bytes = len(VIRTUAL_MODULE_SOURCES[target_id].encode("utf-8"))
    gain_bytes = source_bytes - target_bytes
    return {
        "family": spec["family"],
        "source_id": source_id,
        "target_id": target_id,
        "callable_name": callable_name,
        "source_bytes": source_bytes,
        "target_bytes": target_bytes,
        "gain_bytes": gain_bytes,
        "gain_percent": (gain_bytes * 100) // source_bytes,
        "exact_result_parity": source_canonical == target_canonical,
        "source_result_sha256": hashlib.sha256(source_canonical.encode("utf-8")).hexdigest(),
        "target_result_sha256": hashlib.sha256(target_canonical.encode("utf-8")).hexdigest(),
        "positive_gain": gain_bytes > 0,
    }


def _run_once(run_index: int, specs: Iterable[dict[str, str]]) -> dict[str, Any]:
    pair_results = [evaluate_pair(spec) for spec in specs]
    source_bytes = sum(item["source_bytes"] for item in pair_results)
    target_bytes = sum(item["target_bytes"] for item in pair_results)
    exact = all(item["exact_result_parity"] for item in pair_results)
    positive = all(item["positive_gain"] for item in pair_results) and target_bytes < source_bytes
    semantic_payload = {
        "run_index": run_index,
        "pair_result_digests": [
            {
                "family": item["family"],
                "source_result_sha256": item["source_result_sha256"],
                "target_result_sha256": item["target_result_sha256"],
            }
            for item in pair_results
        ],
    }
    return {
        "run_index": run_index,
        "pair_results": pair_results,
        "source_bytes": source_bytes,
        "target_bytes": target_bytes,
        "gain_bytes": source_bytes - target_bytes,
        "gain_percent": ((source_bytes - target_bytes) * 100) // source_bytes,
        "exact_parity": exact,
        "positive_gain": positive,
        "semantic_root_hash216": sha256_json(semantic_payload),
    }


def build_iteration5_report() -> dict[str, Any]:
    runs = [_run_once(index, FAMILY_SPECS) for index in range(1, REPETITIONS + 1)]
    consecutive_exact_positive = all(run["exact_parity"] and run["positive_gain"] for run in runs)
    report: dict[str, Any] = {
        "schema": "HHS_PASS_214_ITERATION_5_CALLABLE_CORPUS_REPORT_V1",
        "pass": PASS_ID,
        "iteration": ITERATION,
        "status": STATUS_READY if consecutive_exact_positive else "HOLD",
        "family_count": len(FAMILY_SPECS),
        "families": [spec["family"] for spec in FAMILY_SPECS],
        "required_consecutive_runs": REPETITIONS,
        "completed_consecutive_runs": len(runs),
        "consecutive_exact_positive_gain": consecutive_exact_positive,
        "runs": runs,
        "policy": {
            "migration_active": False,
            "authority_promoted": False,
            "terminal_roots_minted": False,
            "pass215_authorized": False,
            "live_pass213_surface_required_for_promotion": True,
        },
    }
    report["corpus_root_hash216"] = sha256_json({
        "families": report["families"],
        "run_roots": [run["semantic_root_hash216"] for run in runs],
        "policy": report["policy"],
    })
    report["receipt_sha256"] = sha256_json(report)
    return report


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", nargs=2, metavar=("MODULE_ID", "CALLABLE"))
    args = parser.parse_args(argv)
    if args.child:
        sys.stdout.write(canonical_json(_execute_virtual(args.child[0], args.child[1])))
        return 0
    sys.stdout.write(json.dumps(build_iteration5_report(), indent=2, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
