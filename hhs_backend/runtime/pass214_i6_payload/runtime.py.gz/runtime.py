"""Pass 214 Iteration 6 repository-native candidate binding authority."""
from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import hmac
import json
from typing import Any, Mapping, Sequence

PASS_NUMBER = 214
ITERATION = 6
SCHEMA = "HHS_PASS_214_ITERATION_6_REPOSITORY_CANDIDATE_BINDING_V1"
REPORT_SCHEMA = "HHS_PASS_214_ITERATION_6_CANDIDATE_BINDING_REPORT_V1"
ADMISSION_SCHEMA = "HHS_PASS_213_LIVE_GOVERNED_SURFACE_ADMISSION_V1"
STATUS_BLOCKED = "CANDIDATE_SET_BOUND_ADMISSION_BLOCKED"
STATUS_ADMITTED = "CANDIDATE_SET_LIVE_ADMITTED_NON_PROMOTING"
SOURCE_COMMIT = "fc5bd81698078fc40b26f827983cfb04176de928"
SOURCE_TREE = "f8f4f12fd581f0cf335442687d4f3662f30ebb8d"
PASS213_CLOSURE = "86ec461818682fc87232740758769602e8f9fe05"
ITERATION5_ROOT = "daed61b048581066e2dd0b0f7986d7c872e979e57079267511516c86f4822767"
ITERATION5_RECEIPT = "f6107632e1f2dd79856e9f01ba6a85c7c5502e9b17e2dd1604a215da69ce80df"

CANDIDATES: tuple[dict[str, Any], ...] = (
    {
        "family": "vector_cache",
        "path": "hhs_runtime/hhs_semantic_composition_cache_v1.py",
        "git_blob_sha1": "8809e746bb270db89bdd3a5cdcc7fda8a0b6e97e",
        "candidate_surface": "SemanticCompositionCache",
        "qualification_basis": "dependency-root-guarded semantic composition cache with advisory vector geometry",
    },
    {
        "family": "wrapper_duplication",
        "path": "hhs_backend/runtime/hhs_agent_algorithm_identity_v1.py",
        "git_blob_sha1": "ab698bcb745e0333e79116a71f06c9ebd6cc94c0",
        "candidate_surface": "self_test",
        "qualification_basis": "thin inherited wrapper over canonical agent economy self-test authority",
    },
    {
        "family": "numeric_lookup",
        "path": "hhs_backend/runtime/hhs_pass213_tensor_geometry_v1.py",
        "git_blob_sha1": "9046f6b3b8ecc1c39ce423fd67b98660415490e2",
        "candidate_surface": "lo_shu_grid/fibonacci_phase/permutation",
        "qualification_basis": "exact integer geometry, Lo Shu transforms, Fibonacci phase, and deterministic permutations",
    },
    {
        "family": "serialization_import",
        "path": "hhs_backend/runtime/hhs_pass213_compiled_rom_v1.py",
        "git_blob_sha1": "daffda13abedcc77bb48fe1936aaef22b7d610b9",
        "candidate_surface": "canonical_bytes/CompiledROMStore",
        "qualification_basis": "Pass 213 canonical JSON serialization and immutable compiled-ROM records",
    },
    {
        "family": "coprime_lookup",
        "path": "hhs_backend/runtime/hhs_pass213_tensor_closure_v1.py",
        "git_blob_sha1": "83699bfe237a2d73e47dedf0bfb6eef8beb6919c",
        "candidate_surface": "_coprime/TensorClosureProof",
        "qualification_basis": "exact affine modular bijection and coprime multiplier proof",
    },
)

POLICY = {
    "candidate_imported_for_replacement": False,
    "candidate_executed_for_migration": False,
    "migration_active": False,
    "authority_promoted": False,
    "terminal_roots_minted": False,
    "pass215_authorized": False,
    "live_pass213_surface_required_for_promotion": True,
}


class Pass214Iteration6Error(RuntimeError):
    pass


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")


def hash216(domain: str, value: Any) -> str:
    framed = b"HHS-P214-I6-HASH216-V1\0" + domain.encode("utf-8") + b"\0" + canonical_bytes(value)
    return sha256(framed).hexdigest()


def _validate_hex(value: str, length: int, code: str) -> None:
    if not isinstance(value, str) or len(value) != length:
        raise Pass214Iteration6Error(code)
    try:
        int(value, 16)
    except ValueError as exc:
        raise Pass214Iteration6Error(code) from exc


def validate_candidate(candidate: Mapping[str, Any]) -> None:
    required = {"family", "path", "git_blob_sha1", "candidate_surface", "qualification_basis"}
    if set(candidate) != required:
        raise Pass214Iteration6Error("PASS214_I6_CANDIDATE_FIELDS_INVALID")
    if not all(isinstance(candidate[key], str) and candidate[key] for key in required):
        raise Pass214Iteration6Error("PASS214_I6_CANDIDATE_TEXT_INVALID")
    _validate_hex(str(candidate["git_blob_sha1"]), 40, "PASS214_I6_GIT_BLOB_INVALID")
    path = str(candidate["path"])
    if path.startswith("/") or ".." in path.split("/") or not path.endswith(".py"):
        raise Pass214Iteration6Error("PASS214_I6_CANDIDATE_PATH_INVALID")


def bind_candidate(candidate: Mapping[str, Any]) -> dict[str, Any]:
    validate_candidate(candidate)
    unsigned = {
        **dict(candidate),
        "source_commit": SOURCE_COMMIT,
        "source_tree": SOURCE_TREE,
        "pass213_closure": PASS213_CLOSURE,
        "iteration5_root": ITERATION5_ROOT,
        "iteration5_receipt": ITERATION5_RECEIPT,
        "admission_state": "BOUND_AWAITING_PASS213_LIVE_GOVERNED_SURFACE",
        "promotion_state": "NON_PROMOTING",
    }
    return {**unsigned, "binding_hash216": hash216("candidate-binding", unsigned)}


def validate_live_admission(admission: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if admission is None:
        return None
    required = {
        "schema", "pass213_closure", "candidate_set_root_hash216",
        "governed_surface_receipt_hash216", "native_dispatch_receipt_hash216",
        "moving_tensor_state_hash216", "rfc3161_anchor_hash216",
        "validation_profile", "production_authority_claimed",
    }
    if set(admission) != required:
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_FIELDS_INVALID")
    if admission["schema"] != ADMISSION_SCHEMA:
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_SCHEMA_INVALID")
    if admission["pass213_closure"] != PASS213_CLOSURE:
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_PASS213_MISMATCH")
    if admission["validation_profile"] != "PASS213_LIVE_GOVERNED_SURFACE":
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_PROFILE_NOT_LIVE")
    if admission["production_authority_claimed"] is not True:
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_AUTHORITY_FLAG_INVALID")
    for key in (
        "candidate_set_root_hash216", "governed_surface_receipt_hash216",
        "native_dispatch_receipt_hash216", "moving_tensor_state_hash216",
        "rfc3161_anchor_hash216",
    ):
        _validate_hex(str(admission[key]), 64, f"PASS214_I6_{key.upper()}_INVALID")
        if str(admission[key]) == "0" * 64:
            raise Pass214Iteration6Error(f"PASS214_I6_{key.upper()}_ZERO")
    return dict(admission)


def build_report(admission: Mapping[str, Any] | None = None) -> dict[str, Any]:
    bindings = [bind_candidate(candidate) for candidate in CANDIDATES]
    families = [binding["family"] for binding in bindings]
    if len(bindings) != 5 or len(set(families)) != 5:
        raise Pass214Iteration6Error("PASS214_I6_FAMILY_COVERAGE_INVALID")
    candidate_set_root = hash216("candidate-set", bindings)
    live = validate_live_admission(admission)
    if live is not None and live["candidate_set_root_hash216"] != candidate_set_root:
        raise Pass214Iteration6Error("PASS214_I6_ADMISSION_CANDIDATE_ROOT_MISMATCH")
    status = STATUS_ADMITTED if live is not None else STATUS_BLOCKED
    unsigned = {
        "schema": REPORT_SCHEMA,
        "pass": PASS_NUMBER,
        "iteration": ITERATION,
        "source_commit": SOURCE_COMMIT,
        "source_tree": SOURCE_TREE,
        "pass213_closure": PASS213_CLOSURE,
        "iteration5_root": ITERATION5_ROOT,
        "iteration5_receipt": ITERATION5_RECEIPT,
        "family_count": len(bindings),
        "families": families,
        "bindings": bindings,
        "candidate_set_root_hash216": candidate_set_root,
        "live_admission": live,
        "status": status,
        "policy": dict(POLICY),
    }
    report_root = hash216("candidate-binding-report", unsigned)
    receipt_unsigned = {
        "schema": SCHEMA,
        "report_root_hash216": report_root,
        "candidate_set_root_hash216": candidate_set_root,
        "status": status,
        "policy": dict(POLICY),
    }
    return {
        **unsigned,
        "report_root_hash216": report_root,
        "receipt_sha256": hash216("candidate-binding-receipt", receipt_unsigned),
    }


def validate_report(report: Mapping[str, Any]) -> None:
    rebuilt = build_report(report.get("live_admission"))
    if not hmac.compare_digest(canonical_bytes(rebuilt), canonical_bytes(dict(report))):
        raise Pass214Iteration6Error("PASS214_I6_REPORT_REPLAY_MISMATCH")


def tamper_copy(report: Mapping[str, Any], family: str) -> dict[str, Any]:
    candidate = deepcopy(dict(report))
    for binding in candidate["bindings"]:
        if binding["family"] == family:
            binding["candidate_surface"] += "/tampered"
            break
    return candidate
