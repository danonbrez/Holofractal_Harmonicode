# AGENTS.md — Codex instructions for HHS General Programming Environment

## Prime directive

Do not replace, bypass, or reimplement the locked kernel authority. New work must be additive and must route through existing runtime modules.

## Authority boundaries

Allowed in adapter layers:

- parse syntax
- normalize input
- package witnesses
- call runtime/kernel APIs
- persist receipts/traces
- quarantine failures

Forbidden in adapter layers:

- redefining Hash72
- inventing alternate drift logic
- silently bypassing `Manifold9` / `drift_gate`
- duplicating security checks as independent authorities
- coercing non-commutative products into commutative scalar arithmetic
- treating `xy` and `yx` as interchangeable

## Required checks after changes

Run at least:

```bash
python tests/test_smoke_entrypoint.py
python tests/test_regression_entrypoint.py
```

For broader validation:

```bash
python hhs_runtime/hhs_v1_bundle_runner.py
python hhs_runtime/hhs_physics_evolution_v1.py --demo
```

If a check fails because of environment pathing, report it clearly and patch the path adapter, not the kernel logic.

## Coding style

- Prefer thin wrappers over duplicated logic.
- Preserve exact rational handling using `Fraction` where applicable.
- Preserve symbolic expressions as symbolic witnesses unless a kernel/runtime operation explicitly evaluates them.
- Fail closed: quarantine rather than guessing.
- Document any new module in `docs/MODULE_MAP.md`.

## Pull request summary requirements

Summaries should include:

1. what layer changed,
2. whether kernel authority was touched,
3. tests run,
4. any quarantine/failure behavior observed.
