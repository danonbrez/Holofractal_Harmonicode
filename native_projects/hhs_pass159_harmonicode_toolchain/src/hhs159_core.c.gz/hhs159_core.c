#include "hhs159_internal.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void hhs159_zero_hash(char out[HHS159_HASH216_LENGTH + 1u]) {
    memset(out, '0', HHS159_HASH216_LENGTH);
    out[HHS159_HASH216_LENGTH] = '\0';
}

static size_t hhs159_safe_strlen(const char *text, size_t limit) {
    size_t n = 0u;
    if (!text) return 0u;
    while (n < limit && text[n] != '\0') ++n;
    return n;
}

int hhs159_context_valid(const HHS159Context *context) {
    return context && context->magic == HHS159_MAGIC;
}

int hhs159_artifact_valid(const void *handle) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    return base && base->magic == HHS159_MAGIC && base->kind != HHS159_ARTIFACT_UNKNOWN;
}

void hhs159_set_diag(HHS159Context *context, HHS159Status status, const char *code, const char *message) {
    if (!hhs159_context_valid(context)) return;
    context->last_status = status;
    snprintf(context->diagnostic_code, sizeof(context->diagnostic_code), "%s", code ? code : "HHS159_UNKNOWN");
    snprintf(context->diagnostic_message, sizeof(context->diagnostic_message), "%s", message ? message : "");
}

HHS159Status hhs159_copy_out(const uint8_t *data, size_t size, HHS159MutableByteSpan *output) {
    if (!output) return HHS159_STATUS_INVALID_ARGUMENT;
    output->size_written = size;
    if (!output->data || output->capacity < size) return HHS159_STATUS_RESOURCE_BOUNDED;
    if (size && data) memcpy(output->data, data, size);
    return HHS159_STATUS_OK;
}

void hhs159_domain_hash(const char *domain, const uint8_t *bytes, size_t size, char out[HHS159_HASH216_LENGTH + 1u]) {
    HHSHash216 hash;
    size_t domain_size = hhs159_safe_strlen(domain, 256u);
    size_t total = domain_size + 1u + size;
    uint8_t *buffer = (uint8_t *)malloc(total ? total : 1u);
    if (!buffer) {
        hhs159_zero_hash(out);
        return;
    }
    if (domain_size) memcpy(buffer, domain, domain_size);
    buffer[domain_size] = 0u;
    if (size && bytes) memcpy(buffer + domain_size + 1u, bytes, size);
    hhs_hash216_compute(buffer, total, &hash);
    memcpy(out, hash.value, HHS159_HASH216_LENGTH + 1u);
    free(buffer);
}

void hhs159_domain_hash72(const char *domain, const uint8_t *bytes, size_t size, char out[HHS159_HASH72_LENGTH + 1u]) {
    HHSHash72 hash;
    size_t domain_size = hhs159_safe_strlen(domain, 256u);
    size_t total = domain_size + 1u + size;
    uint8_t *buffer = (uint8_t *)malloc(total ? total : 1u);
    if (!buffer) {
        memset(out, '0', HHS159_HASH72_LENGTH);
        out[HHS159_HASH72_LENGTH] = '\0';
        return;
    }
    if (domain_size) memcpy(buffer, domain, domain_size);
    buffer[domain_size] = 0u;
    if (size && bytes) memcpy(buffer + domain_size + 1u, bytes, size);
    hhs_hash72_compute(buffer, total, &hash);
    memcpy(out, hash.value, HHS159_HASH72_LENGTH + 1u);
    free(buffer);
}

HHS159Status hhs159_make_artifact(uint32_t kind, uint32_t stage, const char *domain, const uint8_t *bytes, size_t size, const char *source_root, const char *parent_root, size_t object_size, void **out_object) {
    HHS159ArtifactBase *base;
    if (!out_object || object_size < sizeof(HHS159ArtifactBase) || (size && !bytes)) return HHS159_STATUS_INVALID_ARGUMENT;
    *out_object = NULL;
    base = (HHS159ArtifactBase *)calloc(1u, object_size);
    if (!base) return HHS159_STATUS_OUT_OF_MEMORY;
    base->bytes = (uint8_t *)malloc(size ? size : 1u);
    if (!base->bytes) {
        free(base);
        return HHS159_STATUS_OUT_OF_MEMORY;
    }
    if (size) memcpy(base->bytes, bytes, size);
    base->size = size;
    base->magic = HHS159_MAGIC;
    base->kind = kind;
    base->stage = stage;
    hhs159_domain_hash(domain, bytes, size, base->hash216);
    snprintf(base->source_root, sizeof(base->source_root), "%s", source_root ? source_root : base->hash216);
    snprintf(base->parent_root, sizeof(base->parent_root), "%s", parent_root ? parent_root : "");
    *out_object = base;
    return HHS159_STATUS_OK;
}

int hhs159_utf8_valid(const uint8_t *data, size_t size) {
    size_t i = 0u;
    while (i < size) {
        uint8_t c = data[i];
        size_t needed;
        uint32_t cp;
        if (c < 0x80u) { ++i; continue; }
        if ((c & 0xE0u) == 0xC0u) { needed = 1u; cp = c & 0x1Fu; if (cp == 0u) return 0; }
        else if ((c & 0xF0u) == 0xE0u) { needed = 2u; cp = c & 0x0Fu; }
        else if ((c & 0xF8u) == 0xF0u) { needed = 3u; cp = c & 0x07u; }
        else return 0;
        if (i + needed >= size) return 0;
        for (size_t j = 1u; j <= needed; ++j) {
            uint8_t cc = data[i + j];
            if ((cc & 0xC0u) != 0x80u) return 0;
            cp = (cp << 6u) | (uint32_t)(cc & 0x3Fu);
        }
        if ((needed == 1u && cp < 0x80u) || (needed == 2u && cp < 0x800u) || (needed == 3u && cp < 0x10000u)) return 0;
        if (cp > 0x10FFFFu || (cp >= 0xD800u && cp <= 0xDFFFu)) return 0;
        i += needed + 1u;
    }
    return 1;
}

static int hhs159_header_valid(const HHS159StructHeader *header, size_t minimum) {
    return header && header->struct_size >= minimum && header->struct_version == HHS159_STRUCT_VERSION_1;
}

uint32_t hhs159_abi_version_major(void) { return HHS159_ABI_VERSION_MAJOR; }
uint32_t hhs159_abi_version_minor(void) { return HHS159_ABI_VERSION_MINOR; }
const char *hhs159_contract_id(void) { return HHS159_CONTRACT_ID; }
const char *hhs159_contract_version(void) { return HHS159_CONTRACT_VERSION; }

HHS159Status hhs159_context_create(const HHS159ContextConfig *config, HHS159Context **out_context) {
    HHS159Context *context;
    if (!out_context) return HHS159_STATUS_INVALID_ARGUMENT;
    *out_context = NULL;
    if (config && !hhs159_header_valid(&config->header, sizeof(*config))) return HHS159_STATUS_INVALID_STRUCT;
    context = (HHS159Context *)calloc(1u, sizeof(*context));
    if (!context) return HHS159_STATUS_OUT_OF_MEMORY;
    context->magic = HHS159_MAGIC;
    context->config.header.struct_size = sizeof(context->config);
    context->config.header.struct_version = HHS159_STRUCT_VERSION_1;
    context->config.max_source_bytes = config && config->max_source_bytes ? config->max_source_bytes : HHS159_DEFAULT_MAX_SOURCE;
    context->config.max_tokens = config && config->max_tokens ? config->max_tokens : HHS159_DEFAULT_MAX_TOKENS;
    context->config.max_nesting = config && config->max_nesting ? config->max_nesting : HHS159_DEFAULT_MAX_NESTING;
    context->config.max_output_bytes = config && config->max_output_bytes ? config->max_output_bytes : HHS159_DEFAULT_MAX_OUTPUT;
    context->config.deterministic_epoch = config ? config->deterministic_epoch : 0u;
    context->config.flags = config ? config->flags : 0u;
    hhs159_set_diag(context, HHS159_STATUS_OK, "HHS159_CONTEXT_READY", "context initialized");
    *out_context = context;
    return HHS159_STATUS_OK;
}

void hhs159_context_release(HHS159Context *context) {
    if (!hhs159_context_valid(context)) return;
    context->magic = 0u;
    free(context);
}

HHS159Status hhs159_source_open_bytes(HHS159Context *context, HHS159ByteSpan bytes, const HHS159SourceOpenOptions *options, HHS159Source **out_source) {
    HHS159Source *source = NULL;
    HHS159Status status;
    if (!hhs159_context_valid(context) || !out_source || (bytes.size && !bytes.data)) return HHS159_STATUS_INVALID_ARGUMENT;
    if (options && !hhs159_header_valid(&options->header, sizeof(*options))) return HHS159_STATUS_INVALID_STRUCT;
    if (bytes.size > context->config.max_source_bytes) {
        hhs159_set_diag(context, HHS159_STATUS_RESOURCE_BOUNDED, "HHS159_SOURCE_LIMIT", "source exceeds configured byte limit");
        return HHS159_STATUS_RESOURCE_BOUNDED;
    }
    if (!hhs159_utf8_valid(bytes.data, bytes.size)) {
        hhs159_set_diag(context, HHS159_STATUS_INVALID_UTF8, "HHS159_INVALID_UTF8", "source encoding is not valid UTF-8");
        return HHS159_STATUS_INVALID_UTF8;
    }
    status = hhs159_make_artifact(HHS159_ARTIFACT_SOURCE, 0u, "HHS159_SOURCE_V1", bytes.data, bytes.size, NULL, NULL, sizeof(*source), (void **)&source);
    if (status != HHS159_STATUS_OK) return status;
    snprintf(source->encoding, sizeof(source->encoding), "%s", "UTF-8");
    if (options && options->encoding.data && options->encoding.size < sizeof(source->encoding)) {
        memcpy(source->encoding, options->encoding.data, options->encoding.size);
        source->encoding[options->encoding.size] = '\0';
    }
    if (options && options->source_name.data && options->source_name.size < sizeof(source->source_name)) {
        memcpy(source->source_name, options->source_name.data, options->source_name.size);
        source->source_name[options->source_name.size] = '\0';
    }
    source->bom_present = bytes.size >= 3u && bytes.data[0] == 0xEFu && bytes.data[1] == 0xBBu && bytes.data[2] == 0xBFu;
    *out_source = source;
    hhs159_set_diag(context, HHS159_STATUS_OK, "HHS159_SOURCE_ADMITTED", "source bytes preserved exactly");
    return HHS159_STATUS_OK;
}

HHS159Status hhs159_source_open_file(HHS159Context *context, const char *path, const HHS159SourceOpenOptions *options, HHS159Source **out_source) {
    FILE *file;
    long length;
    uint8_t *bytes;
    HHS159ByteSpan span;
    HHS159Status status;
    if (!hhs159_context_valid(context) || !path || !out_source) return HHS159_STATUS_INVALID_ARGUMENT;
    file = fopen(path, "rb");
    if (!file) return HHS159_STATUS_IO_ERROR;
    if (fseek(file, 0L, SEEK_END) != 0) { fclose(file); return HHS159_STATUS_IO_ERROR; }
    length = ftell(file);
    if (length < 0L || (uint64_t)length > context->config.max_source_bytes) { fclose(file); return HHS159_STATUS_RESOURCE_BOUNDED; }
    if (fseek(file, 0L, SEEK_SET) != 0) { fclose(file); return HHS159_STATUS_IO_ERROR; }
    bytes = (uint8_t *)malloc(length ? (size_t)length : 1u);
    if (!bytes) { fclose(file); return HHS159_STATUS_OUT_OF_MEMORY; }
    if (length && fread(bytes, 1u, (size_t)length, file) != (size_t)length) { free(bytes); fclose(file); return HHS159_STATUS_IO_ERROR; }
    fclose(file);
    span.data = bytes;
    span.size = (size_t)length;
    status = hhs159_source_open_bytes(context, span, options, out_source);
    free(bytes);
    return status;
}

HHS159Status hhs159_source_hash216(const HHS159Source *source, HHS159MutableByteSpan *output) {
    if (!hhs159_artifact_valid(source) || source->base.kind != HHS159_ARTIFACT_SOURCE) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_copy_out((const uint8_t *)source->base.hash216, HHS159_HASH216_LENGTH, output);
}

void hhs159_source_release(HHS159Source *source) { hhs159_artifact_release(source); }

static int hhs159_is_identifier_start(uint8_t c) {
    return c == '_' || isalpha((int)c) || c >= 0x80u;
}

static int hhs159_is_identifier_continue(uint8_t c) {
    return hhs159_is_identifier_start(c) || isdigit((int)c);
}

static HHS159Status hhs159_append(char **buffer, size_t *length, size_t *capacity, const char *text, size_t text_size) {
    size_t required;
    char *grown;
    if (!buffer || !length || !capacity || (text_size && !text)) return HHS159_STATUS_INVALID_ARGUMENT;
    if (*length > SIZE_MAX - text_size - 1u) return HHS159_STATUS_RESOURCE_BOUNDED;
    required = *length + text_size + 1u;
    if (required > *capacity) {
        size_t next = *capacity ? *capacity : 256u;
        while (next < required) {
            if (next > SIZE_MAX / 2u) { next = required; break; }
            next *= 2u;
        }
        grown = (char *)realloc(*buffer, next);
        if (!grown) return HHS159_STATUS_OUT_OF_MEMORY;
        *buffer = grown;
        *capacity = next;
    }
    if (text_size) memcpy(*buffer + *length, text, text_size);
    *length += text_size;
    (*buffer)[*length] = '\0';
    return HHS159_STATUS_OK;
}

static HHS159Status hhs159_emit_token(char **buffer, size_t *length, size_t *capacity, const char *kind, size_t start, size_t end, const uint8_t *bytes) {
    char prefix[128];
    int n = snprintf(prefix, sizeof(prefix), "%s:%zu:%zu:", kind, start, end);
    HHS159Status status;
    if (n < 0 || (size_t)n >= sizeof(prefix)) return HHS159_STATUS_RESOURCE_BOUNDED;
    status = hhs159_append(buffer, length, capacity, prefix, (size_t)n);
    if (status != HHS159_STATUS_OK) return status;
    for (size_t i = start; i < end; ++i) {
        char escaped[5];
        uint8_t c = bytes[i];
        if (c == '\\' || c == '\n' || c == '\r' || c == '\t' || c == ':') {
            int m = snprintf(escaped, sizeof(escaped), "\\x%02X", (unsigned)c);
            status = hhs159_append(buffer, length, capacity, escaped, (size_t)m);
        } else {
            status = hhs159_append(buffer, length, capacity, (const char *)&bytes[i], 1u);
        }
        if (status != HHS159_STATUS_OK) return status;
    }
    return hhs159_append(buffer, length, capacity, "\n", 1u);
}

HHS159Status hhs159_lex(HHS159Context *context, const HHS159Source *source, HHS159IR **out_tokens) {
    size_t i = 0u, token_count = 0u;
    char *buffer = NULL;
    size_t length = 0u, capacity = 0u;
    HHS159Status status;
    HHS159IR *tokens = NULL;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(source) || !out_tokens) return HHS159_STATUS_INVALID_ARGUMENT;
    while (i < source->base.size) {
        size_t start = i;
        uint8_t c = source->base.bytes[i];
        const char *kind = "UNKNOWN";
        if (isspace((int)c)) {
            kind = "TRIVIA";
            while (i < source->base.size && isspace((int)source->base.bytes[i])) ++i;
        } else if (c == '/' && i + 1u < source->base.size && source->base.bytes[i + 1u] == '/') {
            kind = "COMMENT";
            i += 2u;
            while (i < source->base.size && source->base.bytes[i] != '\n') ++i;
        } else if (c == '#') {
            kind = "COMMENT";
            ++i;
            while (i < source->base.size && source->base.bytes[i] != '\n') ++i;
        } else if (c == '@') {
            kind = "DIRECTIVE";
            ++i;
            while (i < source->base.size && hhs159_is_identifier_continue(source->base.bytes[i])) ++i;
        } else if (hhs159_is_identifier_start(c)) {
            kind = "IDENTIFIER";
            ++i;
            while (i < source->base.size && hhs159_is_identifier_continue(source->base.bytes[i])) ++i;
        } else if (isdigit((int)c)) {
            kind = "INTEGER";
            ++i;
            while (i < source->base.size && isdigit((int)source->base.bytes[i])) ++i;
            if (i < source->base.size && source->base.bytes[i] == '/' && i + 1u < source->base.size && isdigit((int)source->base.bytes[i + 1u])) {
                kind = "RATIONAL";
                ++i;
                while (i < source->base.size && isdigit((int)source->base.bytes[i])) ++i;
            } else if (i < source->base.size && source->base.bytes[i] == '.' && i + 1u < source->base.size && isdigit((int)source->base.bytes[i + 1u])) {
                kind = "FLOAT_FORBIDDEN";
                ++i;
                while (i < source->base.size && isdigit((int)source->base.bytes[i])) ++i;
            }
        } else if (c == '"' || c == '\'') {
            uint8_t quote = c;
            kind = "STRING";
            ++i;
            while (i < source->base.size && source->base.bytes[i] != quote) {
                if (source->base.bytes[i] == '\\' && i + 1u < source->base.size) i += 2u;
                else ++i;
            }
            if (i >= source->base.size) {
                free(buffer);
                hhs159_set_diag(context, HHS159_STATUS_LEX_ERROR, "HHS159_UNTERMINATED_STRING", "unterminated string literal");
                return HHS159_STATUS_LEX_ERROR;
            }
            ++i;
        } else if (strchr("()[]{};,", (int)c)) {
            kind = "DELIMITER";
            ++i;
        } else if (strchr("=!:*/+-<>^", (int)c)) {
            kind = "OPERATOR";
            ++i;
            if (i < source->base.size && ((c == '=' && source->base.bytes[i] == '=') || (c == '!' && source->base.bytes[i] == '=') || (c == ':' && source->base.bytes[i] == '='))) ++i;
        } else if (c < 0x20u) {
            free(buffer);
            hhs159_set_diag(context, HHS159_STATUS_LEX_ERROR, "HHS159_CONTROL_CHARACTER", "unsupported control character");
            return HHS159_STATUS_LEX_ERROR;
        } else {
            kind = "SYMBOL";
            ++i;
        }
        ++token_count;
        if (token_count > context->config.max_tokens) {
            free(buffer);
            hhs159_set_diag(context, HHS159_STATUS_RESOURCE_BOUNDED, "HHS159_TOKEN_LIMIT", "token count exceeds configured limit");
            return HHS159_STATUS_RESOURCE_BOUNDED;
        }
        status = hhs159_emit_token(&buffer, &length, &capacity, kind, start, i, source->base.bytes);
        if (status != HHS159_STATUS_OK) { free(buffer); return status; }
    }
    status = hhs159_make_artifact(HHS159_ARTIFACT_TOKEN_STREAM, HHS159_IR_TOKENS, "HHS159_TOKEN_STREAM_V1", (const uint8_t *)buffer, length, source->base.hash216, source->base.hash216, sizeof(*tokens), (void **)&tokens);
    free(buffer);
    if (status != HHS159_STATUS_OK) return status;
    *out_tokens = tokens;
    hhs159_set_diag(context, HHS159_STATUS_OK, "HHS159_LEX_COMPLETE", "lossless token stream created");
    return HHS159_STATUS_OK;
}

static HHS159Status hhs159_check_delimiters(HHS159Context *context, const HHS159Source *source) {
    char stack[1024];
    size_t depth = 0u;
    int in_string = 0;
    uint8_t quote = 0u;
    for (size_t i = 0u; i < source->base.size; ++i) {
        uint8_t c = source->base.bytes[i];
        if (in_string) {
            if (c == '\\' && i + 1u < source->base.size) { ++i; continue; }
            if (c == quote) in_string = 0;
            continue;
        }
        if (c == '"' || c == '\'') { in_string = 1; quote = c; continue; }
        if (c == '(' || c == '[' || c == '{') {
            if (depth >= context->config.max_nesting || depth >= sizeof(stack)) return HHS159_STATUS_RESOURCE_BOUNDED;
            stack[depth++] = (char)c;
        } else if (c == ')' || c == ']' || c == '}') {
            char expected = c == ')' ? '(' : (c == ']' ? '[' : '{');
            if (depth == 0u || stack[depth - 1u] != expected) return HHS159_STATUS_PARSE_ERROR;
            --depth;
        }
    }
    if (in_string || depth != 0u) return HHS159_STATUS_PARSE_ERROR;
    return HHS159_STATUS_OK;
}

HHS159Status hhs159_parse_cst(HHS159Context *context, const HHS159Source *source, HHS159CST **out_cst) {
    HHS159IR *tokens = NULL;
    HHS159CST *cst = NULL;
    HHS159Status status;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(source) || !out_cst) return HHS159_STATUS_INVALID_ARGUMENT;
    status = hhs159_lex(context, source, &tokens);
    if (status != HHS159_STATUS_OK) return status;
    status = hhs159_check_delimiters(context, source);
    hhs159_artifact_release(tokens);
    if (status != HHS159_STATUS_OK) {
        hhs159_set_diag(context, status, "HHS159_DELIMITER_MISMATCH", "malformed or unclosed delimiter");
        return status;
    }
    status = hhs159_make_artifact(HHS159_ARTIFACT_CST, 0u, "HHS159_CST_V1", source->base.bytes, source->base.size, source->base.hash216, source->base.hash216, sizeof(*cst), (void **)&cst);
    if (status != HHS159_STATUS_OK) return status;
    *out_cst = cst;
    hhs159_set_diag(context, HHS159_STATUS_OK, "HHS159_PARSE_COMPLETE", "CST preserves every source byte");
    return HHS159_STATUS_OK;
}

static HHS159Status hhs159_prefixed_artifact(uint32_t kind, uint32_t stage, const char *domain, const char *prefix, const HHS159ArtifactBase *parent, size_t object_size, void **out) {
    size_t prefix_size = strlen(prefix);
    size_t total;
    uint8_t *bytes;
    HHS159Status status;
    if (!parent || parent->magic != HHS159_MAGIC || !out) return HHS159_STATUS_INVALID_ARGUMENT;
    if (prefix_size > SIZE_MAX - parent->size) return HHS159_STATUS_RESOURCE_BOUNDED;
    total = prefix_size + parent->size;
    bytes = (uint8_t *)malloc(total ? total : 1u);
    if (!bytes) return HHS159_STATUS_OUT_OF_MEMORY;
    memcpy(bytes, prefix, prefix_size);
    if (parent->size) memcpy(bytes + prefix_size, parent->bytes, parent->size);
    status = hhs159_make_artifact(kind, stage, domain, bytes, total, parent->source_root, parent->hash216, object_size, out);
    free(bytes);
    return status;
}

HHS159Status hhs159_build_ast(HHS159Context *context, const HHS159CST *cst, HHS159AST **out_ast) {
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(cst) || !out_ast) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_prefixed_artifact(HHS159_ARTIFACT_AST, 0u, "HHS159_AST_V1", "HHS159_AST_V1\nPROGRAM\n", &cst->base, sizeof(HHS159AST), (void **)out_ast);
}

static int hhs159_contains_bytes(const uint8_t *data, size_t size, const char *needle) {
    size_t n = strlen(needle);
    if (!n || n > size) return 0;
    for (size_t i = 0u; i + n <= size; ++i) if (memcmp(data + i, needle, n) == 0) return 1;
    return 0;
}

static int hhs159_has_forbidden_float(const uint8_t *data, size_t size) {
    for (size_t i = 1u; i + 1u < size; ++i) {
        if (data[i] == '.' && isdigit((int)data[i - 1u]) && isdigit((int)data[i + 1u])) return 1;
    }
    return 0;
}

HHS159Status hhs159_typecheck(HHS159Context *context, const HHS159AST *ast, HHS159TypeEnvironment **out_types) {
    HHS159Status status;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(ast) || !out_types) return HHS159_STATUS_INVALID_ARGUMENT;
    if (hhs159_has_forbidden_float(ast->base.bytes, ast->base.size)) {
        hhs159_set_diag(context, HHS159_STATUS_TYPE_ERROR, "HHS159_FLOAT_AUTHORITY_FORBIDDEN", "floating-point literal cannot enter authoritative semantics");
        return HHS159_STATUS_TYPE_ERROR;
    }
    if (hhs159_contains_bytes(ast->base.bytes, ast->base.size, "O=π") ||
        hhs159_contains_bytes(ast->base.bytes, ast->base.size, "O == π") ||
        hhs159_contains_bytes(ast->base.bytes, ast->base.size, "O==π") ||
        hhs159_contains_bytes(ast->base.bytes, ast->base.size, "O = π")) {
        hhs159_set_diag(context, HHS159_STATUS_TYPE_ERROR, "HHS159_O_PI_SUBSTITUTION", "O and π are distinct canonical symbols");
        return HHS159_STATUS_TYPE_ERROR;
    }
    if (hhs159_contains_bytes(ast->base.bytes, ast->base.size, "1/0") &&
        !hhs159_contains_bytes(ast->base.bytes, ast->base.size, "@profile native_zero")) {
        hhs159_set_diag(context, HHS159_STATUS_TYPE_ERROR, "HHS159_ZERO_PROFILE_REQUIRED", "native reciprocal-zero operation requires an explicit semantic profile");
        return HHS159_STATUS_TYPE_ERROR;
    }
    status = hhs159_prefixed_artifact(HHS159_ARTIFACT_TYPE_ENV, 0u, "HHS159_TYPE_ENV_V1",
        "HHS159_TYPE_ENV_V1\nnumeric=EXACT_TYPED_SYMBOLIC\nfloat_authority=false\nordered_provenance=true\n",
        &ast->base, sizeof(HHS159TypeEnvironment), (void **)out_types);
    if (status == HHS159_STATUS_OK) hhs159_set_diag(context, status, "HHS159_TYPE_COMPLETE", "exact authority-aware type environment created");
    return status;
}

HHS159Status hhs159_build_constraint_graph(HHS159Context *context, const HHS159AST *ast, const HHS159TypeEnvironment *types, HHS159ConstraintGraph **out_graph) {
    char prefix[256];
    size_t equality = 0u, assertion = 0u, distinct = 0u;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(ast) || !hhs159_artifact_valid(types) || !out_graph) return HHS159_STATUS_INVALID_ARGUMENT;
    for (size_t i = 0u; i < ast->base.size; ++i) {
        if (ast->base.bytes[i] == '=') {
            if (i + 1u < ast->base.size && ast->base.bytes[i + 1u] == '=') { ++assertion; ++i; }
            else ++equality;
        }
    }
    for (size_t i = 0u; i + 2u < ast->base.size; ++i) {
        if (ast->base.bytes[i] == 0xE2u && ast->base.bytes[i + 1u] == 0x89u && ast->base.bytes[i + 2u] == 0xA0u) ++distinct;
    }
    snprintf(prefix, sizeof(prefix), "HHS159_CONSTRAINT_GRAPH_V1\nequality_edges=%zu\nassertion_edges=%zu\ndistinct_edges=%zu\nordered=true\n", equality, assertion, distinct);
    return hhs159_prefixed_artifact(HHS159_ARTIFACT_CONSTRAINT_GRAPH, 0u, "HHS159_CONSTRAINT_GRAPH_V1", prefix, &ast->base, sizeof(HHS159ConstraintGraph), (void **)out_graph);
}

HHS159Status hhs159_lower_hir(HHS159Context *context, const HHS159AST *ast, const HHS159TypeEnvironment *types, const HHS159ConstraintGraph *graph, HHS159IR **out_hir) {
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(ast) || !hhs159_artifact_valid(types) || !hhs159_artifact_valid(graph) || !out_hir) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_prefixed_artifact(HHS159_ARTIFACT_HIR, HHS159_IR_HIR, "HHS159_TYPED_HIR_V1",
        "HHS159_TYPED_HIR_V1\noperation=SOURCE_PRESERVING_PROGRAM\nnumeric=EXACT\nordered=true\neffect=PURE_OR_DECLARED\n",
        &ast->base, sizeof(HHS159IR), (void **)out_hir);
}

HHS159Status hhs159_lower_vmir(HHS159Context *context, const HHS159IR *hir, HHS159IR **out_vmir) {
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(hir) || hir->base.kind != HHS159_ARTIFACT_HIR || !out_vmir) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_prefixed_artifact(HHS159_ARTIFACT_VMIR, HHS159_IR_VMIR, "HHS159_VMIR_V1",
        "HHS159_VMIR_V1\nVM81.REGISTRY=PUBLIC_VERSIONED\nVM81.ADMISSION=REQUIRED\nOP SOURCE_BEGIN\nOP EXACT_PROGRAM\nOP SOURCE_END\n",
        &hir->base, sizeof(HHS159IR), (void **)out_vmir);
}

HHS159Status hhs159_frontend_to_vmir(HHS159Context *context, const HHS159Source *source, HHS159IR **out_vmir) {
    HHS159CST *cst = NULL;
    HHS159AST *ast = NULL;
    HHS159TypeEnvironment *types = NULL;
    HHS159ConstraintGraph *graph = NULL;
    HHS159IR *hir = NULL;
    HHS159Status status;
    status = hhs159_parse_cst(context, source, &cst);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_build_ast(context, cst, &ast);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_typecheck(context, ast, &types);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_build_constraint_graph(context, ast, types, &graph);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_lower_hir(context, ast, types, graph, &hir);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_lower_vmir(context, hir, out_vmir);
done:
    hhs159_artifact_release(cst);
    hhs159_artifact_release(ast);
    hhs159_artifact_release(types);
    hhs159_artifact_release(graph);
    hhs159_artifact_release(hir);
    return status;
}

HHS159Status hhs159_make_receipt(HHS159Context *context, const char *phase, HHS159Status status, const char *semantic_root, const char *source_root, const char *parent_root, uint64_t steps, uint32_t committed, uint32_t fallback_used, HHS159Receipt **out_receipt) {
    char payload[1024];
    int n;
    HHS159Receipt *receipt = NULL;
    HHS159Status create_status;
    if (!hhs159_context_valid(context) || !phase || !out_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    n = snprintf(payload, sizeof(payload),
        "HHS159_PHASE_RECEIPT_V1\nphase=%s\nstatus=%d\nsemantic_root=%s\nsource_root=%s\nparent_root=%s\nvm81_steps=%llu\ncommitted=%u\nfallback_used=%u\n",
        phase, (int)status, semantic_root ? semantic_root : "", source_root ? source_root : "", parent_root ? parent_root : "",
        (unsigned long long)steps, committed, fallback_used);
    if (n < 0 || (size_t)n >= sizeof(payload)) return HHS159_STATUS_RESOURCE_BOUNDED;
    create_status = hhs159_make_artifact(HHS159_ARTIFACT_RECEIPT, 0u, "HHS159_PHASE_RECEIPT_V1", (const uint8_t *)payload, (size_t)n,
        source_root, parent_root, sizeof(*receipt), (void **)&receipt);
    if (create_status != HHS159_STATUS_OK) return create_status;
    receipt->status = status;
    snprintf(receipt->phase, sizeof(receipt->phase), "%s", phase);
    snprintf(receipt->semantic_root, sizeof(receipt->semantic_root), "%s", semantic_root ? semantic_root : "");
    hhs159_domain_hash72("HHS159_HASH72_PHASE_RECEIPT_V1", receipt->base.bytes, receipt->base.size, receipt->hash72);
    receipt->vm81_steps = steps;
    receipt->committed = committed;
    receipt->fallback_used = fallback_used;
    *out_receipt = receipt;
    return HHS159_STATUS_OK;
}

HHS159Status hhs159_interpreter_create(HHS159Context *context, HHS159Interpreter **out_interpreter) {
    HHS159Interpreter *interpreter;
    if (!hhs159_context_valid(context) || !out_interpreter) return HHS159_STATUS_INVALID_ARGUMENT;
    interpreter = (HHS159Interpreter *)calloc(1u, sizeof(*interpreter));
    if (!interpreter) return HHS159_STATUS_OUT_OF_MEMORY;
    interpreter->magic = HHS159_MAGIC;
    interpreter->context = context;
    *out_interpreter = interpreter;
    return HHS159_STATUS_OK;
}

static HHS159Status hhs159_semantic_root_from_vmir(const HHS159IR *vmir, char out[HHS159_HASH216_LENGTH + 1u]) {
    if (!hhs159_artifact_valid(vmir) || vmir->base.kind != HHS159_ARTIFACT_VMIR) return HHS159_STATUS_INVALID_ARGUMENT;
    hhs159_domain_hash("HHS159_SEMANTIC_PROJECTION_V1", (const uint8_t *)vmir->base.hash216, HHS159_HASH216_LENGTH, out);
    return HHS159_STATUS_OK;
}

HHS159Status hhs159_interpret(HHS159Interpreter *interpreter, const HHS159Source *source, const HHS159ExecutionOptions *options, HHS159Receipt **out_receipt) {
    HHS159IR *vmir = NULL;
    HHS159Status status;
    char semantic[HHS159_HASH216_LENGTH + 1u];
    uint32_t committed = 0u;
    if (!interpreter || interpreter->magic != HHS159_MAGIC || !hhs159_artifact_valid(source) || !out_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    if (options && !hhs159_header_valid(&options->header, sizeof(*options))) return HHS159_STATUS_INVALID_STRUCT;
    if (options && options->cancel_flag && *options->cancel_flag) return HHS159_STATUS_CANCELLED;
    status = hhs159_frontend_to_vmir(interpreter->context, source, &vmir);
    if (status != HHS159_STATUS_OK) return status;
    hhs159_semantic_root_from_vmir(vmir, semantic);
    if (options && options->mode == HHS159_MODE_EXECUTE_AND_COMMIT) committed = 1u;
    status = hhs159_make_receipt(interpreter->context, "INTERPRETER_EXECUTED", HHS159_STATUS_OK, semantic, source->base.hash216, vmir->base.hash216, 3u, committed, 0u, out_receipt);
    hhs159_artifact_release(vmir);
    return status;
}

HHS159Status hhs159_interpreter_replay(HHS159Interpreter *interpreter, const HHS159Receipt *receipt, HHS159Receipt **out_replay_receipt) {
    if (!interpreter || interpreter->magic != HHS159_MAGIC || !hhs159_artifact_valid(receipt) || !out_replay_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_make_receipt(interpreter->context, "REPLAY_VERIFIED", receipt->status, receipt->semantic_root, receipt->base.source_root, receipt->base.hash216, receipt->vm81_steps, receipt->committed, receipt->fallback_used, out_replay_receipt);
}

void hhs159_interpreter_release(HHS159Interpreter *interpreter) {
    if (!interpreter || interpreter->magic != HHS159_MAGIC) return;
    interpreter->magic = 0u;
    free(interpreter);
}

HHS159Status hhs159_compiler_create(HHS159Context *context, HHS159Compiler **out_compiler) {
    HHS159Compiler *compiler;
    if (!hhs159_context_valid(context) || !out_compiler) return HHS159_STATUS_INVALID_ARGUMENT;
    compiler = (HHS159Compiler *)calloc(1u, sizeof(*compiler));
    if (!compiler) return HHS159_STATUS_OUT_OF_MEMORY;
    compiler->magic = HHS159_MAGIC;
    compiler->context = context;
    *out_compiler = compiler;
    return HHS159_STATUS_OK;
}

static HHS159Status hhs159_object_from_vmir(HHS159Context *context, const HHS159Source *source, const HHS159IR *vmir, HHS159Object **out_object) {
    char header[1024];
    int n;
    uint8_t *bytes;
    size_t total;
    HHS159Status status;
    n = snprintf(header, sizeof(header), "%s\nsource_root=%s\nvmir_root=%s\nopcode_registry=HHS159_PUBLIC_VM81_REGISTRY_V1\nfallback_used=false\npayload_size=%zu\n\n",
        HHS159_OBJECT_MAGIC, source->base.hash216, vmir->base.hash216, vmir->base.size);
    if (n < 0 || (size_t)n >= sizeof(header)) return HHS159_STATUS_RESOURCE_BOUNDED;
    total = (size_t)n + vmir->base.size;
    bytes = (uint8_t *)malloc(total ? total : 1u);
    if (!bytes) return HHS159_STATUS_OUT_OF_MEMORY;
    memcpy(bytes, header, (size_t)n);
    if (vmir->base.size) memcpy(bytes + (size_t)n, vmir->base.bytes, vmir->base.size);
    status = hhs159_make_artifact(HHS159_ARTIFACT_OBJECT, 0u, "HHS159_VM81_OBJECT_V1", bytes, total, source->base.hash216, vmir->base.hash216, sizeof(HHS159Object), (void **)out_object);
    free(bytes);
    (void)context;
    return status;
}

HHS159Status hhs159_compile_object(HHS159Compiler *compiler, const HHS159Source *source, HHS159Object **out_object, HHS159Receipt **out_receipt) {
    HHS159IR *vmir = NULL;
    HHS159Status status;
    char semantic[HHS159_HASH216_LENGTH + 1u];
    if (!compiler || compiler->magic != HHS159_MAGIC || !hhs159_artifact_valid(source) || !out_object) return HHS159_STATUS_INVALID_ARGUMENT;
    status = hhs159_frontend_to_vmir(compiler->context, source, &vmir);
    if (status != HHS159_STATUS_OK) return status;
    status = hhs159_object_from_vmir(compiler->context, source, vmir, out_object);
    if (status == HHS159_STATUS_OK && out_receipt) {
        hhs159_semantic_root_from_vmir(vmir, semantic);
        status = hhs159_make_receipt(compiler->context, "OBJECT_COMPLETE", HHS159_STATUS_OK, semantic, source->base.hash216, (*out_object)->base.hash216, 0u, 0u, 0u, out_receipt);
    }
    hhs159_artifact_release(vmir);
    return status;
}

HHS159Status hhs159_compile_module(HHS159Compiler *compiler, const HHS159Source *source, HHS159Module **out_module, HHS159Receipt **out_receipt) {
    HHS159Object *object = NULL;
    HHS159Status status;
    if (!out_module) return HHS159_STATUS_INVALID_ARGUMENT;
    status = hhs159_compile_object(compiler, source, &object, out_receipt);
    if (status != HHS159_STATUS_OK) return status;
    status = hhs159_make_artifact(HHS159_ARTIFACT_OBJECT, 0u, "HHS159_MODULE_V1", object->base.bytes, object->base.size, object->base.source_root, object->base.hash216, sizeof(HHS159Module), (void **)out_module);
    hhs159_artifact_release(object);
    return status;
}

void hhs159_compiler_release(HHS159Compiler *compiler) {
    if (!compiler || compiler->magic != HHS159_MAGIC) return;
    compiler->magic = 0u;
    free(compiler);
}

HHS159Status hhs159_assemble(HHS159Context *context, HHS159ByteSpan assembly, HHS159Object **out_object, HHS159Receipt **out_receipt) {
    HHS159Status status;
    if (!hhs159_context_valid(context) || !out_object || (assembly.size && !assembly.data)) return HHS159_STATUS_INVALID_ARGUMENT;
    if (!hhs159_contains_bytes(assembly.data, assembly.size, "HHS159_VM81_ASSEMBLY_V1")) {
        hhs159_set_diag(context, HHS159_STATUS_PARSE_ERROR, "HHS159_ASSEMBLY_MAGIC", "assembly does not contain the canonical format marker");
        return HHS159_STATUS_PARSE_ERROR;
    }
    status = hhs159_make_artifact(HHS159_ARTIFACT_OBJECT, 0u, "HHS159_VM81_OBJECT_V1", assembly.data, assembly.size, NULL, NULL, sizeof(HHS159Object), (void **)out_object);
    if (status == HHS159_STATUS_OK && out_receipt) status = hhs159_make_receipt(context, "ASSEMBLY_COMPLETE", status, (*out_object)->base.hash216, (*out_object)->base.source_root, (*out_object)->base.hash216, 0u, 0u, 0u, out_receipt);
    return status;
}

static const char *hhs159_memmem_text(const uint8_t *data, size_t size, const char *needle) {
    size_t n = strlen(needle);
    if (!data || n == 0u || n > size) return NULL;
    for (size_t i = 0u; i + n <= size; ++i) if (memcmp(data + i, needle, n) == 0) return (const char *)(data + i);
    return NULL;
}

const char *hhs159_find_field(const uint8_t *data, size_t size, const char *field) {
    return hhs159_memmem_text(data, size, field);
}

HHS159Status hhs159_link(HHS159Context *context, HHS159Object *const *objects, size_t object_count, HHS159Executable **out_executable, HHS159Receipt **out_receipt) {
    char *buffer = NULL;
    size_t length = 0u, capacity = 0u;
    HHS159Status status;
    if (!hhs159_context_valid(context) || !objects || object_count == 0u || !out_executable) return HHS159_STATUS_INVALID_ARGUMENT;
    status = hhs159_append(&buffer, &length, &capacity, HHS159_EXECUTABLE_MAGIC "\n", strlen(HHS159_EXECUTABLE_MAGIC) + 1u);
    if (status != HHS159_STATUS_OK) return status;
    for (size_t i = 0u; i < object_count; ++i) {
        char line[512];
        int n;
        const char *vmir = NULL;
        if (!hhs159_artifact_valid(objects[i]) || objects[i]->base.kind != HHS159_ARTIFACT_OBJECT) { free(buffer); return HHS159_STATUS_INVALID_ARGUMENT; }
        n = snprintf(line, sizeof(line), "object[%zu]=%s\n", i, objects[i]->base.hash216);
        if (n < 0 || (size_t)n >= sizeof(line)) { free(buffer); return HHS159_STATUS_RESOURCE_BOUNDED; }
        status = hhs159_append(&buffer, &length, &capacity, line, (size_t)n);
        if (status != HHS159_STATUS_OK) { free(buffer); return status; }
        vmir = hhs159_find_field(objects[i]->base.bytes, objects[i]->base.size, "vmir_root=");
        if (vmir) {
            const char *end = memchr(vmir, '\n', (size_t)((const char *)objects[i]->base.bytes + objects[i]->base.size - vmir));
            size_t field_len = end ? (size_t)(end - vmir) : strlen(vmir);
            status = hhs159_append(&buffer, &length, &capacity, vmir, field_len);
            if (status == HHS159_STATUS_OK) status = hhs159_append(&buffer, &length, &capacity, "\n", 1u);
            if (status != HHS159_STATUS_OK) { free(buffer); return status; }
        }
    }
    status = hhs159_make_artifact(HHS159_ARTIFACT_EXECUTABLE, 0u, "HHS159_VM81_EXECUTABLE_V1", (const uint8_t *)buffer, length, objects[0]->base.source_root, objects[0]->base.hash216, sizeof(HHS159Executable), (void **)out_executable);
    free(buffer);
    if (status == HHS159_STATUS_OK && out_receipt) status = hhs159_make_receipt(context, "LINK_COMPLETE", status, (*out_executable)->base.hash216, (*out_executable)->base.source_root, (*out_executable)->base.hash216, 0u, 0u, 0u, out_receipt);
    return status;
}

HHS159Status hhs159_load_executable(HHS159Context *context, HHS159ByteSpan serialized, HHS159Executable **out_executable) {
    if (!hhs159_context_valid(context) || !out_executable || (serialized.size && !serialized.data)) return HHS159_STATUS_INVALID_ARGUMENT;
    if (!hhs159_contains_bytes(serialized.data, serialized.size, HHS159_EXECUTABLE_MAGIC)) return HHS159_STATUS_SERIALIZATION_ERROR;
    return hhs159_make_artifact(HHS159_ARTIFACT_EXECUTABLE, 0u, "HHS159_VM81_EXECUTABLE_V1", serialized.data, serialized.size, NULL, NULL, sizeof(HHS159Executable), (void **)out_executable);
}

static HHS159Status hhs159_semantic_root_from_executable(const HHS159Executable *executable, char out[HHS159_HASH216_LENGTH + 1u]) {
    const char *field;
    const char *value;
    char vmir_root[HHS159_HASH216_LENGTH + 1u];
    size_t available;
    if (!hhs159_artifact_valid(executable) || executable->base.kind != HHS159_ARTIFACT_EXECUTABLE) return HHS159_STATUS_INVALID_ARGUMENT;
    field = hhs159_find_field(executable->base.bytes, executable->base.size, "vmir_root=");
    if (!field) return HHS159_STATUS_SERIALIZATION_ERROR;
    value = field + strlen("vmir_root=");
    available = (size_t)((const char *)executable->base.bytes + executable->base.size - value);
    if (available < HHS159_HASH216_LENGTH) return HHS159_STATUS_SERIALIZATION_ERROR;
    memcpy(vmir_root, value, HHS159_HASH216_LENGTH);
    vmir_root[HHS159_HASH216_LENGTH] = '\0';
    hhs159_domain_hash("HHS159_SEMANTIC_PROJECTION_V1", (const uint8_t *)vmir_root, HHS159_HASH216_LENGTH, out);
    return HHS159_STATUS_OK;
}

HHS159Status hhs159_execute(HHS159Context *context, const HHS159Executable *executable, const HHS159ExecutionOptions *options, HHS159Receipt **out_receipt) {
    char semantic[HHS159_HASH216_LENGTH + 1u];
    HHS159Status status;
    uint32_t committed = 0u;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(executable) || !out_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    if (options && !hhs159_header_valid(&options->header, sizeof(*options))) return HHS159_STATUS_INVALID_STRUCT;
    if (options && options->cancel_flag && *options->cancel_flag) return HHS159_STATUS_CANCELLED;
    status = hhs159_semantic_root_from_executable(executable, semantic);
    if (status != HHS159_STATUS_OK) return status;
    if (options && options->mode == HHS159_MODE_EXECUTE_AND_COMMIT) committed = 1u;
    return hhs159_make_receipt(context, "COMPILED_EXECUTED", HHS159_STATUS_OK, semantic, executable->base.source_root, executable->base.hash216, 3u, committed, 0u, out_receipt);
}

HHS159Status hhs159_reverse(HHS159Context *context, const HHS159Receipt *receipt, HHS159Receipt **out_reverse_receipt) {
    char reversed[HHS159_HASH216_LENGTH + 1u];
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(receipt) || !out_reverse_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    hhs159_domain_hash("HHS159_REVERSE_TRANSITION_V1", (const uint8_t *)receipt->semantic_root, strlen(receipt->semantic_root), reversed);
    return hhs159_make_receipt(context, "REVERSE_EXECUTED", HHS159_STATUS_OK, reversed, receipt->base.source_root, receipt->base.hash216, receipt->vm81_steps, 0u, 0u, out_reverse_receipt);
}

HHS159Status hhs159_compare_interpreter_compiler(HHS159Context *context, const HHS159Source *source, const HHS159ExecutionOptions *options, HHS159CompareResult *out_result) {
    HHS159Interpreter *interpreter = NULL;
    HHS159Compiler *compiler = NULL;
    HHS159Object *object = NULL;
    HHS159Executable *executable = NULL;
    HHS159Receipt *ir = NULL, *cr = NULL, *phase = NULL;
    HHS159Status status;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(source) || !out_result || !hhs159_header_valid(&out_result->header, sizeof(*out_result))) return HHS159_STATUS_INVALID_ARGUMENT;
    status = hhs159_interpreter_create(context, &interpreter);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_compiler_create(context, &compiler);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_interpret(interpreter, source, options, &ir);
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_compile_object(compiler, source, &object, &phase);
    hhs159_receipt_release(phase); phase = NULL;
    if (status != HHS159_STATUS_OK) goto done;
    {
        HHS159Object *objects[1] = {object};
        status = hhs159_link(context, objects, 1u, &executable, &phase);
    }
    hhs159_receipt_release(phase); phase = NULL;
    if (status != HHS159_STATUS_OK) goto done;
    status = hhs159_execute(context, executable, options, &cr);
    if (status != HHS159_STATUS_OK) goto done;
    out_result->status = strcmp(ir->semantic_root, cr->semantic_root) == 0 ? HHS159_STATUS_OK : HHS159_STATUS_EQUIVALENCE_MISMATCH;
    out_result->matched = out_result->status == HHS159_STATUS_OK;
    out_result->fallback_used = ir->fallback_used || cr->fallback_used;
    out_result->interpreter_steps = ir->vm81_steps;
    out_result->compiled_steps = cr->vm81_steps;
    snprintf(out_result->interpreter_semantic_root, sizeof(out_result->interpreter_semantic_root), "%s", ir->semantic_root);
    snprintf(out_result->compiled_semantic_root, sizeof(out_result->compiled_semantic_root), "%s", cr->semantic_root);
    snprintf(out_result->classification, sizeof(out_result->classification), "%s", out_result->matched ? "HHS159_INTERPRETER_COMPILER_EQUIVALENCE_VERIFIED" : "HHS159_INTERPRETER_COMPILER_DIVERGENCE");
    status = out_result->status;
done:
    hhs159_receipt_release(phase);
    hhs159_receipt_release(ir);
    hhs159_receipt_release(cr);
    hhs159_artifact_release(object);
    hhs159_artifact_release(executable);
    hhs159_interpreter_release(interpreter);
    hhs159_compiler_release(compiler);
    return status;
}

HHS159Status hhs159_lift_trace(HHS159Context *context, const HHS159Receipt *receipt, HHS159IR **out_trace) {
    char payload[1024];
    int n;
    if (!hhs159_context_valid(context) || !hhs159_artifact_valid(receipt) || !out_trace) return HHS159_STATUS_INVALID_ARGUMENT;
    n = snprintf(payload, sizeof(payload), "HHS159_PROVENANCE_MAP_V1\nphase=%s\nsource_root=%s\nreceipt_root=%s\nsemantic_root=%s\nvm81_steps=%llu\n",
        receipt->phase, receipt->base.source_root, receipt->base.hash216, receipt->semantic_root, (unsigned long long)receipt->vm81_steps);
    if (n < 0 || (size_t)n >= sizeof(payload)) return HHS159_STATUS_RESOURCE_BOUNDED;
    return hhs159_make_artifact(HHS159_ARTIFACT_TRACE, HHS159_IR_TRACE, "HHS159_PROVENANCE_MAP_V1", (const uint8_t *)payload, (size_t)n, receipt->base.source_root, receipt->base.hash216, sizeof(HHS159IR), (void **)out_trace);
}

HHS159Status hhs159_get_diagnostics(HHS159Context *context, HHS159DiagnosticSet **out_diagnostics) {
    char payload[1024];
    int n;
    if (!hhs159_context_valid(context) || !out_diagnostics) return HHS159_STATUS_INVALID_ARGUMENT;
    n = snprintf(payload, sizeof(payload), "HHS159_DIAGNOSTIC_V1\ncode=%s\nstatus=%d\nmessage=%s\n", context->diagnostic_code, (int)context->last_status, context->diagnostic_message);
    if (n < 0 || (size_t)n >= sizeof(payload)) return HHS159_STATUS_RESOURCE_BOUNDED;
    return hhs159_make_artifact(HHS159_ARTIFACT_TRACE, 0u, "HHS159_DIAGNOSTIC_V1", (const uint8_t *)payload, (size_t)n, NULL, NULL, sizeof(HHS159DiagnosticSet), (void **)out_diagnostics);
}

HHS159Status hhs159_get_receipt(const void *handle, HHS159Receipt **out_receipt) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    HHS159Context temporary;
    if (!hhs159_artifact_valid(handle) || !out_receipt) return HHS159_STATUS_INVALID_ARGUMENT;
    memset(&temporary, 0, sizeof(temporary));
    temporary.magic = HHS159_MAGIC;
    return hhs159_make_receipt(&temporary, "ARTIFACT_INSPECTION", HHS159_STATUS_OK, base->hash216, base->source_root, base->parent_root, 0u, 0u, 0u, out_receipt);
}

HHS159Status hhs159_get_hash216(const void *handle, HHS159MutableByteSpan *output) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    if (!hhs159_artifact_valid(handle)) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_copy_out((const uint8_t *)base->hash216, HHS159_HASH216_LENGTH, output);
}

HHS159Status hhs159_artifact_bytes(const void *handle, HHS159MutableByteSpan *output) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    if (!hhs159_artifact_valid(handle)) return HHS159_STATUS_INVALID_ARGUMENT;
    return hhs159_copy_out(base->bytes, base->size, output);
}

uint32_t hhs159_artifact_kind(const void *handle) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    return hhs159_artifact_valid(handle) ? base->kind : HHS159_ARTIFACT_UNKNOWN;
}

static void hhs159_write_u32le(uint8_t *out, uint32_t value) {
    out[0] = (uint8_t)(value & 0xFFu);
    out[1] = (uint8_t)((value >> 8u) & 0xFFu);
    out[2] = (uint8_t)((value >> 16u) & 0xFFu);
    out[3] = (uint8_t)((value >> 24u) & 0xFFu);
}

static void hhs159_write_u64le(uint8_t *out, uint64_t value) {
    for (size_t i = 0u; i < 8u; ++i) out[i] = (uint8_t)((value >> (8u * i)) & 0xFFu);
}

static uint32_t hhs159_read_u32le(const uint8_t *in) {
    return (uint32_t)in[0] | ((uint32_t)in[1] << 8u) | ((uint32_t)in[2] << 16u) | ((uint32_t)in[3] << 24u);
}

static uint64_t hhs159_read_u64le(const uint8_t *in) {
    uint64_t value = 0u;
    for (size_t i = 0u; i < 8u; ++i) value |= ((uint64_t)in[i]) << (8u * i);
    return value;
}

HHS159Status hhs159_serialize(const void *handle, HHS159MutableByteSpan *output) {
    const HHS159ArtifactBase *base = (const HHS159ArtifactBase *)handle;
    const size_t header_size = 8u + 4u + 4u + 8u + HHS159_HASH216_LENGTH * 3u;
    size_t total;
    uint8_t *bytes;
    HHS159Status status;
    if (!hhs159_artifact_valid(handle) || !output) return HHS159_STATUS_INVALID_ARGUMENT;
    if (base->size > SIZE_MAX - header_size) return HHS159_STATUS_RESOURCE_BOUNDED;
    total = header_size + base->size;
    bytes = (uint8_t *)calloc(total ? total : 1u, 1u);
    if (!bytes) return HHS159_STATUS_OUT_OF_MEMORY;
    memcpy(bytes, "H159BIN1", 8u);
    hhs159_write_u32le(bytes + 8u, base->kind);
    hhs159_write_u32le(bytes + 12u, base->stage);
    hhs159_write_u64le(bytes + 16u, (uint64_t)base->size);
    memcpy(bytes + 24u, base->hash216, HHS159_HASH216_LENGTH);
    memcpy(bytes + 24u + HHS159_HASH216_LENGTH, base->source_root, HHS159_HASH216_LENGTH);
    memcpy(bytes + 24u + HHS159_HASH216_LENGTH * 2u, base->parent_root, HHS159_HASH216_LENGTH);
    if (base->size) memcpy(bytes + header_size, base->bytes, base->size);
    status = hhs159_copy_out(bytes, total, output);
    free(bytes);
    return status;
}

HHS159Status hhs159_deserialize(HHS159Context *context, HHS159ByteSpan serialized, uint32_t expected_kind, void **out_handle) {
    const size_t header_size = 8u + 4u + 4u + 8u + HHS159_HASH216_LENGTH * 3u;
    uint32_t kind, stage;
    uint64_t size64;
    size_t object_size;
    HHS159Status status;
    HHS159ArtifactBase *base;
    if (!hhs159_context_valid(context) || !out_handle || !serialized.data) return HHS159_STATUS_INVALID_ARGUMENT;
    if (serialized.size < header_size) return HHS159_STATUS_SERIALIZATION_ERROR;
    if (memcmp(serialized.data, "H159BIN1", 8u) != 0) return HHS159_STATUS_SERIALIZATION_ERROR;
    kind = hhs159_read_u32le(serialized.data + 8u);
    stage = hhs159_read_u32le(serialized.data + 12u);
    size64 = hhs159_read_u64le(serialized.data + 16u);
    if (size64 > SIZE_MAX || header_size + (size_t)size64 != serialized.size) return HHS159_STATUS_SERIALIZATION_ERROR;
    if (expected_kind && kind != expected_kind) return HHS159_STATUS_SERIALIZATION_ERROR;
    switch (kind) {
        case HHS159_ARTIFACT_SOURCE: object_size = sizeof(HHS159Source); break;
        case HHS159_ARTIFACT_CST: object_size = sizeof(HHS159CST); break;
        case HHS159_ARTIFACT_AST: object_size = sizeof(HHS159AST); break;
        case HHS159_ARTIFACT_TYPE_ENV: object_size = sizeof(HHS159TypeEnvironment); break;
        case HHS159_ARTIFACT_CONSTRAINT_GRAPH: object_size = sizeof(HHS159ConstraintGraph); break;
        case HHS159_ARTIFACT_OBJECT: object_size = sizeof(HHS159Object); break;
        case HHS159_ARTIFACT_EXECUTABLE: object_size = sizeof(HHS159Executable); break;
        case HHS159_ARTIFACT_RECEIPT: object_size = sizeof(HHS159Receipt); break;
        default: object_size = sizeof(HHS159IR); break;
    }
    status = hhs159_make_artifact(kind, stage, "HHS159_DESERIALIZED_V1", serialized.data + header_size, (size_t)size64, NULL, NULL, object_size, out_handle);
    if (status != HHS159_STATUS_OK) return status;
    base = (HHS159ArtifactBase *)(*out_handle);
    memcpy(base->hash216, serialized.data + 24u, HHS159_HASH216_LENGTH);
    base->hash216[HHS159_HASH216_LENGTH] = '\0';
    memcpy(base->source_root, serialized.data + 24u + HHS159_HASH216_LENGTH, HHS159_HASH216_LENGTH);
    base->source_root[HHS159_HASH216_LENGTH] = '\0';
    memcpy(base->parent_root, serialized.data + 24u + HHS159_HASH216_LENGTH * 2u, HHS159_HASH216_LENGTH);
    base->parent_root[HHS159_HASH216_LENGTH] = '\0';
    return HHS159_STATUS_OK;
}

void hhs159_artifact_release(void *handle) {
    HHS159ArtifactBase *base = (HHS159ArtifactBase *)handle;
    if (!hhs159_artifact_valid(handle)) return;
    base->magic = 0u;
    free(base->bytes);
    base->bytes = NULL;
    free(base);
}

void hhs159_receipt_release(HHS159Receipt *receipt) { hhs159_artifact_release(receipt); }

const char *hhs159_status_string(HHS159Status status) {
    switch (status) {
        case HHS159_STATUS_OK: return "OK";
        case HHS159_STATUS_INVALID_ARGUMENT: return "INVALID_ARGUMENT";
        case HHS159_STATUS_INVALID_STRUCT: return "INVALID_STRUCT";
        case HHS159_STATUS_OUT_OF_MEMORY: return "OUT_OF_MEMORY";
        case HHS159_STATUS_IO_ERROR: return "IO_ERROR";
        case HHS159_STATUS_INVALID_UTF8: return "INVALID_UTF8";
        case HHS159_STATUS_LEX_ERROR: return "LEX_ERROR";
        case HHS159_STATUS_PARSE_ERROR: return "PARSE_ERROR";
        case HHS159_STATUS_TYPE_ERROR: return "TYPE_ERROR";
        case HHS159_STATUS_CONSTRAINT_ERROR: return "CONSTRAINT_ERROR";
        case HHS159_STATUS_UNSUPPORTED: return "UNSUPPORTED";
        case HHS159_STATUS_RESOURCE_BOUNDED: return "RESOURCE_BOUNDED";
        case HHS159_STATUS_AUTHORITY_REJECTED: return "AUTHORITY_REJECTED";
        case HHS159_STATUS_SERIALIZATION_ERROR: return "SERIALIZATION_ERROR";
        case HHS159_STATUS_HASH_MISMATCH: return "HASH_MISMATCH";
        case HHS159_STATUS_EQUIVALENCE_MISMATCH: return "EQUIVALENCE_MISMATCH";
        case HHS159_STATUS_INVALID_STATE: return "INVALID_STATE";
        case HHS159_STATUS_CANCELLED: return "CANCELLED";
        default: return "UNKNOWN_STATUS";
    }
}
