Verify manifest.json and knowledge.sqlite3 before applying restore.
