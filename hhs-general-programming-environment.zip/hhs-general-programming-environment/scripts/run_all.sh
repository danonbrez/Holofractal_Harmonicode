#!/usr/bin/env bash
set -euo pipefail
python tests/test_smoke_entrypoint.py
python tests/test_regression_entrypoint.py
python hhs_runtime/hhs_v1_bundle_runner.py
python hhs_runtime/hhs_physics_evolution_v1.py --demo
