"""
terminal_hhsprog_v4_symbolic.py

Symbolic-algebra native terminal/parser for HARMONICODE.

Purpose
-------
Accept HHS equations as valid input/output syntax without collapsing them into
ordinary Python arithmetic.

This layer treats large HHS expressions as symbolic programs/witness payloads:
- parses and canonicalizes them
- preserves chained == / != / ≠ assertions
- preserves List / MatrixTimes / Mod / Sqrt / Power / RealSurd / Factorial
- preserves implicit multiplication patterns such as xyb⁴, 4x, Au⁹
- preserves named gate blocks like PLASTIC_EIGENSTATE_CLOSURE_GATE := {...}
- emits Hash72 receipts through AuditedRunner
- does not execute arbitrary Python

Important
---------
This is a symbolic syntax layer, not a numeric simplifier. It compiles algebraic
source into a canonical symbolic payload and commits that payload through the
kernel receipt chain. Numeric execution remains delegated to AuditedRunner ops.

Run:
    python terminal_hhsprog_v4_symbolic.py
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import json
import re
import sys

from hhs_general_runtime_layer_v1 import AuditedRunner, DEFAULT_KERNEL_PATH, canonicalize_for_hash72
from hhs_receipt_replay_verifier_v1 import HHSReceiptReplayVerifierV1
from hhs_program_format_and_cli_v1 import verify_run_file, RUN_RESULT_FORMAT, load_json


TERMINAL_FORMAT = "TERMINAL_HHSPROG_V4_SYMBOLIC"


SUPERSCRIPT_MAP = {
    "⁰": "^0",
    "¹": "^1",
    "²": "^2",
    "³": "^3",
    "⁴": "^4",
    "⁵": "^5",
    "⁶": "^6",
    "⁷": "^7",
    "⁸": "^8",
    "⁹": "^9",
    "⁻": "^-",
}

# Operators sorted by length first.
OPERATORS = [
    ":=",
    "==",
    "!=",
    "≠",
    "<=",
    ">=",
    "->",
    "→",
    "+",
    "-",
    "*",
    "/",
    "^",
    "=",
    "<",
    ">",
    ":",
    ",",
    ";",
]

BRACKETS = {
    "(": "RPAREN",
    ")": "LPAREN",
    "[": "RBRACKET",
    "]": "LBRACKET",
    "{": "RBRACE",
    "}": "LBRACE",
}

FUNCTION_NAMES = {
    "List",
    "MatrixTimes",
    "Mod",
    "Sqrt",
    "Power",
    "RealSurd",
    "Factorial",
    "Pi",
    "π",
    "E",
    "STRING",
}

GATE_KEYWORDS = {
    "PLASTIC_EIGENSTATE_CLOSURE_GATE",
    "CUBIC_EXPANSION_NORMALIZATION_GATE",
}


@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    index: int

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SymbolicForm:
    form_type: str
    source: str
    normalized_source: str
    tokens: List[Dict[str, Any]]
    structure: Dict[str, Any]
    source_hash72: str
    symbolic_hash72: str
    receipt: Optional[Dict[str, Any]]
    ok: bool
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class HHSSymbolicSyntaxError(RuntimeError):
    pass


class HHSSymbolicLexerV1:
    """
    Lexer for HHS symbolic algebra.

    It intentionally accepts broad symbolic source and performs structure-level
    checks instead of trying to reduce the expression to scalar arithmetic.
    """

    @staticmethod
    def normalize_unicode(source: str) -> str:
        s = source.replace("√", "Sqrt")
        s = s.replace("−", "-")
        s = s.replace("×", "*")
        s = s.replace("÷", "/")
        s = s.replace("π", "π")
        for sup, rep in SUPERSCRIPT_MAP.items():
            s = s.replace(sup, rep)
        # Normalize whitespace but keep line boundaries recoverable via spaces.
        s = re.sub(r"\s+", " ", s).strip()
        return s

    @staticmethod
    def tokenize(source: str) -> List[Token]:
        s = HHSSymbolicLexerV1.normalize_unicode(source)
        tokens: List[Token] = []
        i = 0

        while i < len(s):
            ch = s[i]

            if ch.isspace():
                i += 1
                continue

            # Brackets.
            if ch in "()[]{}":
                kind = {
                    "(": "LPAREN",
                    ")": "RPAREN",
                    "[": "LBRACKET",
                    "]": "RBRACKET",
                    "{": "LBRACE",
                    "}": "RBRACE",
                }[ch]
                tokens.append(Token(kind, ch, i))
                i += 1
                continue

            # Operators.
            matched = None
            for op in OPERATORS:
                if s.startswith(op, i):
                    matched = op
                    break
            if matched is not None:
                tokens.append(Token("OP", matched, i))
                i += len(matched)
                continue

            # Numbers: decimal, integer, rational-ish handled as number/op/number.
            if ch.isdigit():
                j = i + 1
                while j < len(s) and (s[j].isdigit() or s[j] == "."):
                    j += 1
                tokens.append(Token("NUMBER", s[i:j], i))
                i = j
                continue

            # Identifiers / greek / symbolic words.
            if ch.isalpha() or ch == "_" or ord(ch) > 127:
                j = i + 1
                while j < len(s):
                    cj = s[j]
                    if cj.isalnum() or cj == "_" or ord(cj) > 127:
                        j += 1
                    else:
                        break
                value = s[i:j]
                kind = "FUNCTION" if value in FUNCTION_NAMES else "IDENT"
                if value in GATE_KEYWORDS:
                    kind = "GATE"
                tokens.append(Token(kind, value, i))
                i = j
                continue

            # Any remaining single glyph is symbolic.
            tokens.append(Token("SYMBOL", ch, i))
            i += 1

        return tokens

    @staticmethod
    def check_balanced(tokens: List[Token]) -> Dict[str, Any]:
        stack: List[Token] = []
        pairs = {"RPAREN": "LPAREN", "RBRACKET": "LBRACKET", "RBRACE": "LBRACE"}
        openings = {"LPAREN", "LBRACKET", "LBRACE"}

        for tok in tokens:
            if tok.kind in openings:
                stack.append(tok)
            elif tok.kind in pairs:
                if not stack or stack[-1].kind != pairs[tok.kind]:
                    return {
                        "balanced": False,
                        "error": f"unmatched closing {tok.value} at {tok.index}",
                    }
                stack.pop()

        if stack:
            top = stack[-1]
            return {
                "balanced": False,
                "error": f"unclosed {top.value} at {top.index}",
            }

        return {"balanced": True, "error": ""}


class HHSSymbolicParserV1:
    """
    Structure parser.

    Produces enough structure for receipts, replay, GUI rendering, and later
    semantic validators.
    """

    def __init__(self, authority):
        self.authority = authority

    @staticmethod
    def token_dicts(tokens: List[Token]) -> List[Dict[str, Any]]:
        return [t.to_dict() for t in tokens]

    @staticmethod
    def split_top_level(tokens: List[Token], separators: set[str]) -> List[List[Token]]:
        parts: List[List[Token]] = []
        current: List[Token] = []
        depth = 0

        for tok in tokens:
            if tok.kind in {"LPAREN", "LBRACKET", "LBRACE"}:
                depth += 1
            elif tok.kind in {"RPAREN", "RBRACKET", "RBRACE"}:
                depth -= 1

            if depth == 0 and tok.kind == "OP" and tok.value in separators:
                parts.append(current)
                current = []
            else:
                current.append(tok)

        parts.append(current)
        return parts

    @staticmethod
    def untokenize(tokens: List[Token]) -> str:
        return "".join(t.value for t in tokens)

    def classify(self, source: str, tokens: List[Token]) -> Dict[str, Any]:
        balance = HHSSymbolicLexerV1.check_balanced(tokens)
        if not balance["balanced"]:
            raise HHSSymbolicSyntaxError(balance["error"])

        ops = [t.value for t in tokens if t.kind == "OP"]
        functions = [t.value for t in tokens if t.kind == "FUNCTION"]
        identifiers = [t.value for t in tokens if t.kind in {"IDENT", "GATE"}]

        structure: Dict[str, Any] = {
            "balanced": True,
            "operator_counts": {op: ops.count(op) for op in sorted(set(ops))},
            "functions": sorted(set(functions)),
            "identifiers": sorted(set(identifiers)),
            "token_count": len(tokens),
            "implicit_multiplication_candidates": self.detect_implicit_multiplication(tokens),
        }

        if any(t.kind == "GATE" for t in tokens) and ":=" in ops:
            structure["form"] = "GATE_DEFINITION"
            structure["gate_name"] = next(t.value for t in tokens if t.kind == "GATE")
            return structure

        if "==" in ops or "!=" in ops or "≠" in ops:
            structure["form"] = "ASSERTION_CHAIN"
            terms = self.split_top_level(tokens, {"==", "!=", "≠"})
            separators = [t.value for t in tokens if t.kind == "OP" and t.value in {"==", "!=", "≠"}]
            structure["chain_terms"] = [self.untokenize(p) for p in terms]
            structure["chain_operators"] = separators
            structure["chain_length"] = len(terms)
            return structure

        if ":=" in ops:
            structure["form"] = "SYMBOLIC_ASSIGNMENT"
            parts = self.split_top_level(tokens, {":="})
            structure["lhs"] = self.untokenize(parts[0]) if parts else ""
            structure["rhs"] = self.untokenize(parts[1]) if len(parts) > 1 else ""
            return structure

        if functions:
            structure["form"] = "FUNCTIONAL_SYMBOLIC_EXPRESSION"
            return structure

        structure["form"] = "SYMBOLIC_EXPRESSION"
        return structure

    @staticmethod
    def detect_implicit_multiplication(tokens: List[Token]) -> List[Dict[str, Any]]:
        """
        Detect adjacency that should be preserved as implicit product.
        Examples:
            4x, xyb^4, Au^9, )(, )x, xy(
        """
        candidates = []
        left_kinds = {"NUMBER", "IDENT", "FUNCTION", "GATE", "RPAREN", "RBRACKET", "RBRACE"}
        right_kinds = {"NUMBER", "IDENT", "FUNCTION", "GATE", "LPAREN", "LBRACKET", "LBRACE"}

        for a, b in zip(tokens, tokens[1:]):
            if a.kind in left_kinds and b.kind in right_kinds:
                # Exclude function call: Sqrt(, List(
                if a.kind == "FUNCTION" and b.kind == "LPAREN":
                    continue
                # Exclude operator separated because operators are tokens themselves.
                candidates.append({
                    "left": a.to_dict(),
                    "right": b.to_dict(),
                    "implicit_operator": "*",
                })
        return candidates

    def parse(self, source: str) -> Dict[str, Any]:
        normalized = HHSSymbolicLexerV1.normalize_unicode(source)
        tokens = HHSSymbolicLexerV1.tokenize(source)
        structure = self.classify(normalized, tokens)
        source_hash = self.authority.commit(
            {"source": source, "normalized": normalized},
            domain="HHS_SYMBOLIC_SOURCE",
        )
        symbolic_hash = self.authority.commit(
            {
                "normalized_source": normalized,
                "tokens": self.token_dicts(tokens),
                "structure": structure,
            },
            domain="HHS_SYMBOLIC_FORM",
        )
        return {
            "source": source,
            "normalized_source": normalized,
            "tokens": self.token_dicts(tokens),
            "structure": structure,
            "source_hash72": source_hash,
            "symbolic_hash72": symbolic_hash,
        }


class HHSSymbolicTerminalV4:
    def __init__(self, kernel_path: str | Path = DEFAULT_KERNEL_PATH):
        self.kernel_path = Path(kernel_path)
        self.runner = AuditedRunner(self.kernel_path)
        self.parser = HHSSymbolicParserV1(self.runner.authority)
        self.symbolic_forms: Dict[str, Dict[str, Any]] = {}
        self.history: List[Dict[str, Any]] = []
        self.running = True

    def commit_symbolic_source(self, source: str) -> SymbolicForm:
        try:
            parsed = self.parser.parse(source)
            witness = {
                "terminal": TERMINAL_FORMAT,
                "form": "SYMBOLIC_SOURCE_COMMIT",
                "parsed": parsed,
                "semantic_mode": "PRESERVE_SYMBOLIC_FORM",
                "note": "accepted as HHS symbolic syntax; semantic reduction delegated to later gates",
            }

            # Use SUM [1] as the neutral receipt carrier. The payload carries the
            # symbolic source; the numeric value only lets the existing runtime
            # produce a LOCKED receipt without pretending to solve the expression.
            out = self.runner.execute(
                "SUM",
                [1],
                input_payload=witness,
            )

            ok = bool(out.get("ok"))
            receipt = out.get("receipt")

            form = SymbolicForm(
                form_type=parsed["structure"]["form"],
                source=source,
                normalized_source=parsed["normalized_source"],
                tokens=parsed["tokens"],
                structure=parsed["structure"],
                source_hash72=parsed["source_hash72"],
                symbolic_hash72=parsed["symbolic_hash72"],
                receipt=receipt,
                ok=ok,
                error="" if ok else out.get("reason", "symbolic commit failed"),
            )

            self.symbolic_forms[form.symbolic_hash72] = form.to_dict()
            self.history.append(form.to_dict())
            return form

        except Exception as exc:
            form = SymbolicForm(
                form_type="SYNTAX_ERROR",
                source=source,
                normalized_source=HHSSymbolicLexerV1.normalize_unicode(source),
                tokens=[],
                structure={},
                source_hash72="",
                symbolic_hash72="",
                receipt=None,
                ok=False,
                error=f"{type(exc).__name__}: {exc}",
            )
            self.history.append(form.to_dict())
            return form

    def command(self, line: str) -> Optional[Dict[str, Any]]:
        stripped = line.strip()
        if not stripped:
            return {"ok": True, "noop": True}

        parts = stripped.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd in {"quit", "exit"}:
            self.running = False
            return {"ok": True, "terminal": "closing"}

        if cmd == "help":
            return {
                "ok": True,
                "terminal": TERMINAL_FORMAT,
                "primary": "Paste HHS equations directly. They are accepted as symbolic syntax and hash-committed.",
                "examples": [
                    "(a^2==b^2/a^4==c^2-b^2)^2/((c^2-b^2)*a^2)==b^2",
                    "PLASTIC_EIGENSTATE_CLOSURE_GATE := { ρ^3 = ρ + 1, b = ρ^2 }",
                    "List(List(4,9,2),List(3,5,7),List(8,1,6))/(x*y)-x-y==0",
                    "x≠y≠xy≠yx≠Sqrtxy≠Sqrtyx≠a≠b",
                ],
                "commands": [
                    "status",
                    "chain",
                    "forms",
                    "show <symbolic_hash72>",
                    "save <file.hhsrun>",
                    "load <file.hhsrun>",
                    "verify <file.hhsrun>",
                    "quit",
                ],
            }

        if cmd == "status":
            return {
                "ok": True,
                "phase": self.runner.commitments.phase,
                "receipt_count": len(self.runner.commitments.receipts),
                "symbolic_form_count": len(self.symbolic_forms),
                "tip_hash72": self.runner.commitments.tip_hash72,
                "chain": self.runner.commitments.verify_chain(),
            }

        if cmd == "chain":
            report = HHSReceiptReplayVerifierV1(self.kernel_path).verify_runner(self.runner).to_dict()
            return {
                "ok": report["ok"],
                "chain": self.runner.commitments.verify_chain(),
                "replay": report,
            }

        if cmd == "forms":
            return {
                "ok": True,
                "forms": [
                    {
                        "symbolic_hash72": h,
                        "form_type": f["form_type"],
                        "source_preview": f["source"][:160],
                        "ok": f["ok"],
                    }
                    for h, f in self.symbolic_forms.items()
                ],
            }

        if cmd == "show":
            if not arg:
                return {"ok": False, "error": "show requires symbolic_hash72"}
            if arg not in self.symbolic_forms:
                return {"ok": False, "error": f"unknown symbolic_hash72: {arg}"}
            return {"ok": True, "form": self.symbolic_forms[arg]}

        if cmd == "save":
            if not arg:
                return {"ok": False, "error": "save requires output path"}
            payload = {
                "format": RUN_RESULT_FORMAT,
                "program_name": "TERMINAL_SYMBOLIC_SESSION",
                "terminal_format": TERMINAL_FORMAT,
                "symbolic_forms": list(self.symbolic_forms.values()),
                "history": self.history,
                "receipts": [r.to_dict() for r in self.runner.commitments.receipts],
                "chain": self.runner.commitments.verify_chain(),
                "replay": HHSReceiptReplayVerifierV1(self.kernel_path).verify_runner(self.runner).to_dict(),
                "all_ok": self.runner.commitments.verify_chain().get("ok") is True,
            }
            Path(arg).write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            return {"ok": True, "saved": arg, "tip_hash72": self.runner.commitments.tip_hash72}

        if cmd == "load":
            if not arg:
                return {"ok": False, "error": "load requires .hhsrun path"}
            payload = load_json(arg)
            verify = HHSReceiptReplayVerifierV1(self.kernel_path).verify(
                payload.get("receipts", []),
                expected_tip_hash72=payload.get("chain", {}).get("tip_hash72"),
            ).to_dict()
            if not verify.get("ok"):
                return {"ok": False, "error": "replay verification failed", "verify": verify}
            for f in payload.get("symbolic_forms", []):
                if "symbolic_hash72" in f:
                    self.symbolic_forms[f["symbolic_hash72"]] = f
            return {
                "ok": True,
                "loaded": arg,
                "verify": verify,
                "symbolic_form_count": len(self.symbolic_forms),
            }

        if cmd == "verify":
            if not arg:
                return {"ok": False, "error": "verify requires .hhsrun path"}
            return verify_run_file(arg, kernel_path=self.kernel_path)

        return None

    def dispatch(self, line: str) -> Dict[str, Any]:
        command_result = self.command(line)
        if command_result is not None:
            return command_result

        form = self.commit_symbolic_source(line)
        return form.to_dict()

    def repl(self) -> None:
        print("TERMINAL_HHSPROG_V4_SYMBOLIC LOCKED SHELL")
        print("paste HHS equations directly; type 'help' for commands")
        while self.running:
            try:
                line = input("hhsΣ> ")
            except EOFError:
                break
            out = self.dispatch(line)
            print(json.dumps(out, indent=2, ensure_ascii=False))


def main(argv: Optional[List[str]] = None) -> int:
    term = HHSSymbolicTerminalV4()
    if argv and len(argv) > 0:
        out = term.dispatch(" ".join(argv))
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0 if out.get("ok") else 1
    term.repl()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
