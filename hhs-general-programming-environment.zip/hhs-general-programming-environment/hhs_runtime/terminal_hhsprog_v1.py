"""
terminal_hhsprog_v1.py

Native interactive terminal for the HARMONICODE General Programming Environment V1.

Purpose
-------
Provide a minimal shell for interactive command-line execution through AuditedRunner.

Every command routes through:
    command parse -> AuditedRunner operation -> kernel audit -> Hash72 receipt -> output

Supported commands
------------------
help
status
ops
add A B
sub A B
mul A B
div A B
sum [1,2,3]
sort [3,1,2]
search [1,2,3] 2
run path/to/file.hhsprog
verify path/to/file.hhsrun
save path/to/output.hhsrun
receipts
chain
quit / exit

Run:
    python terminal_hhsprog_v1.py
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import shlex
import sys

from hhs_general_runtime_layer_v1 import AuditedRunner, DEFAULT_KERNEL_PATH, canonicalize_for_hash72
from hhs_program_format_and_cli_v1 import execute_program, load_json, verify_run_file, RUN_RESULT_FORMAT
from hhs_receipt_replay_verifier_v1 import HHSReceiptReplayVerifierV1


TERMINAL_FORMAT = "TERMINAL_HHSPROG_V1"


class HHSTerminalV1:
    def __init__(self, kernel_path: str | Path = DEFAULT_KERNEL_PATH):
        self.kernel_path = Path(kernel_path)
        self.runner = AuditedRunner(self.kernel_path)
        self.history: List[Dict[str, Any]] = []
        self.last_output: Optional[Dict[str, Any]] = None
        self.running = True

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def parse_json_arg(text: str) -> Any:
        return json.loads(text)

    def emit(self, payload: Dict[str, Any]) -> None:
        self.last_output = payload
        print(json.dumps(payload, indent=2, ensure_ascii=False))

    def execute_op(self, op: str, *args: Any) -> Dict[str, Any]:
        out = self.runner.execute(
            op,
            *args,
            input_payload={
                "terminal": TERMINAL_FORMAT,
                "op": op,
                "args": canonicalize_for_hash72(args),
                "history_index": len(self.history),
            },
        )
        record = {
            "kind": "operation",
            "op": op,
            "args": canonicalize_for_hash72(args),
            "output": out,
        }
        self.history.append(record)
        return out

    # ------------------------------------------------------------------
    # Commands
    # ------------------------------------------------------------------

    def cmd_help(self, args: List[str]) -> Dict[str, Any]:
        return {
            "ok": True,
            "terminal": TERMINAL_FORMAT,
            "commands": [
                "help",
                "status",
                "ops",
                "add A B",
                "sub A B",
                "mul A B",
                "div A B",
                "sum [1,2,3]",
                "sort [3,1,2]",
                "search [1,2,3] 2",
                "run path/to/file.hhsprog",
                "verify path/to/file.hhsrun",
                "save path/to/output.hhsrun",
                "receipts",
                "chain",
                "quit / exit",
            ],
        }

    def cmd_status(self, args: List[str]) -> Dict[str, Any]:
        chain = self.runner.commitments.verify_chain()
        return {
            "ok": True,
            "kernel_path": str(self.kernel_path),
            "phase": self.runner.commitments.phase,
            "receipt_count": len(self.runner.commitments.receipts),
            "tip_hash72": self.runner.commitments.tip_hash72,
            "chain": chain,
        }

    def cmd_ops(self, args: List[str]) -> Dict[str, Any]:
        return {
            "ok": True,
            "operations": self.runner.registry.names(),
        }

    def cmd_receipts(self, args: List[str]) -> Dict[str, Any]:
        return {
            "ok": True,
            "receipts": [r.to_dict() for r in self.runner.commitments.receipts],
        }

    def cmd_chain(self, args: List[str]) -> Dict[str, Any]:
        verifier = HHSReceiptReplayVerifierV1(self.kernel_path)
        report = verifier.verify_runner(self.runner).to_dict()
        return {
            "ok": report["ok"],
            "chain": self.runner.commitments.verify_chain(),
            "replay": report,
        }

    def cmd_save(self, args: List[str]) -> Dict[str, Any]:
        if not args:
            return {"ok": False, "error": "save requires output path"}
        path = Path(args[0])
        payload = {
            "format": RUN_RESULT_FORMAT,
            "program_name": "TERMINAL_SESSION",
            "terminal_format": TERMINAL_FORMAT,
            "operation_count_declared": len(self.history),
            "operation_count_executed": len(self.history),
            "results": self.history,
            "receipts": [r.to_dict() for r in self.runner.commitments.receipts],
            "chain": self.runner.commitments.verify_chain(),
            "replay": HHSReceiptReplayVerifierV1(self.kernel_path).verify_runner(self.runner).to_dict(),
            "storage_report": None,
            "all_ok": self.runner.commitments.verify_chain().get("ok") is True,
        }
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return {
            "ok": True,
            "saved": str(path),
            "receipt_count": len(self.runner.commitments.receipts),
            "tip_hash72": self.runner.commitments.tip_hash72,
        }

    def cmd_run(self, args: List[str]) -> Dict[str, Any]:
        if not args:
            return {"ok": False, "error": "run requires .hhsprog path"}
        path = Path(args[0])
        program = load_json(path)
        result = execute_program(program, kernel_path=self.kernel_path)
        self.history.append({
            "kind": "program_run",
            "path": str(path),
            "output": result,
        })
        return result

    def cmd_verify(self, args: List[str]) -> Dict[str, Any]:
        if not args:
            return {"ok": False, "error": "verify requires .hhsrun path"}
        return verify_run_file(args[0], kernel_path=self.kernel_path)

    def cmd_add(self, args: List[str]) -> Dict[str, Any]:
        return self.execute_op("ADD", args[0], args[1])

    def cmd_sub(self, args: List[str]) -> Dict[str, Any]:
        return self.execute_op("SUB", args[0], args[1])

    def cmd_mul(self, args: List[str]) -> Dict[str, Any]:
        return self.execute_op("MUL", args[0], args[1])

    def cmd_div(self, args: List[str]) -> Dict[str, Any]:
        return self.execute_op("DIV", args[0], args[1])

    def cmd_sum(self, args: List[str]) -> Dict[str, Any]:
        if not args:
            return {"ok": False, "error": "sum requires JSON list"}
        return self.execute_op("SUM", self.parse_json_arg(args[0]))

    def cmd_sort(self, args: List[str]) -> Dict[str, Any]:
        if not args:
            return {"ok": False, "error": "sort requires JSON list"}
        return self.execute_op("SORT", self.parse_json_arg(args[0]))

    def cmd_search(self, args: List[str]) -> Dict[str, Any]:
        if len(args) < 2:
            return {"ok": False, "error": "search requires JSON list and target"}
        return self.execute_op("BINARY_SEARCH", self.parse_json_arg(args[0]), args[1])

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def dispatch(self, line: str) -> Dict[str, Any]:
        line = line.strip()
        if not line:
            return {"ok": True, "noop": True}

        try:
            parts = shlex.split(line)
        except ValueError as exc:
            return {"ok": False, "error": f"parse error: {exc}"}

        cmd = parts[0].lower()
        args = parts[1:]

        if cmd in {"quit", "exit"}:
            self.running = False
            return {"ok": True, "terminal": "closing"}

        table = {
            "help": self.cmd_help,
            "status": self.cmd_status,
            "ops": self.cmd_ops,
            "receipts": self.cmd_receipts,
            "chain": self.cmd_chain,
            "save": self.cmd_save,
            "run": self.cmd_run,
            "verify": self.cmd_verify,
            "add": self.cmd_add,
            "sub": self.cmd_sub,
            "mul": self.cmd_mul,
            "div": self.cmd_div,
            "sum": self.cmd_sum,
            "sort": self.cmd_sort,
            "search": self.cmd_search,
        }

        if cmd not in table:
            return {"ok": False, "error": f"unknown command: {cmd}", "hint": "type help"}

        try:
            return table[cmd](args)
        except Exception as exc:
            return {
                "ok": False,
                "error": type(exc).__name__,
                "message": str(exc),
            }

    def repl(self) -> None:
        print("TERMINAL_HHSPROG_V1 LOCKED SHELL")
        print("type 'help' for commands; 'exit' to close")
        while self.running:
            try:
                line = input("hhs> ")
            except EOFError:
                break
            out = self.dispatch(line)
            self.emit(out)


def main(argv: Optional[List[str]] = None) -> int:
    term = HHSTerminalV1()
    if argv and len(argv) > 0:
        out = term.dispatch(" ".join(argv))
        term.emit(out)
        return 0 if out.get("ok") else 1
    term.repl()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
