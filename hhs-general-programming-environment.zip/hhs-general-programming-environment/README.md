# HHS General Programming Environment V1

This repository packages the HARMONICODE / HHS deterministic programming stack for Codex and local development.

The environment routes normal and symbolic programs through a kernel-audited execution loop:

```text
input / observation / symbolic source
→ exact rational or symbolic carrier
→ macro expansion / state patch / operation dispatch
→ Manifold9 drift gate
→ authoritative Hash72 receipt
→ replayable state or output
```

## Codex readiness

Codex works best when a repository includes clear instructions and runnable checks. OpenAI notes that Codex can be guided by `AGENTS.md` files and that configured environments, reliable tests, and clear documentation improve agent performance. See the official Codex materials for AGENTS.md guidance and repository setup expectations.

## Repository layout

```text
hhs_runtime/     Core kernel, runtime, terminals, state, physics, verification layers
examples/        .hhsprog and GUI macro bootstrap examples
demo_reports/    Physics model demo output reports
docs/            Architecture, module map, handoff, and operating notes
tests/           Minimal smoke/regression entrypoints for Codex
scripts/         Convenience local runners
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Run smoke tests
python tests/test_smoke_entrypoint.py

# Run regression suite
python tests/test_regression_entrypoint.py

# Run bundle certification
python hhs_runtime/hhs_v1_bundle_runner.py
```

## Main entrypoints

```bash
# CLI program runner
python hhs_runtime/hhs_program_format_and_cli_v1.py demo -o examples/demo_program.hhsprog
python hhs_runtime/hhs_program_format_and_cli_v1.py run examples/demo_program.hhsprog -o /tmp/demo.hhsrun
python hhs_runtime/hhs_program_format_and_cli_v1.py verify /tmp/demo.hhsrun

# Symbolic macro algebra terminal
python hhs_runtime/terminal_hhsprog_v5_macro_algebra.py

# Input bridge demo
python hhs_runtime/hhs_input_bridge_v1.py demo

# Physics model demo
python hhs_runtime/hhs_physics_model_v1.py --demo

# Physics evolution demo
python hhs_runtime/hhs_physics_evolution_v1.py --demo
```

## Integrity model

New layers are adapters only. They may parse, normalize, route, package witnesses, and call kernel/module APIs. They may not redefine Hash72, drift logic, kernel invariants, or security checks. The locked kernel remains the authority.

## Notes

Some original module filenames include hyphens and version suffixes. The runtime loader handles the locked kernel by file path. If moving files, update `DEFAULT_KERNEL_PATH` or pass `--kernel-path` where supported.
