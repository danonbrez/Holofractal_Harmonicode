from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "hhs_runtime"))
from hhs_runtime_smoke_tests_v1 import HHSSmokeTestSuiteV1

if __name__ == "__main__":
    report = HHSSmokeTestSuiteV1().run_all()
    print(report)
    raise SystemExit(0 if report.get("all_ok") else 1)
