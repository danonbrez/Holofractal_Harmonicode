# Codex Handoff

## Start here

1. Read `AGENTS.md`.
2. Run smoke tests.
3. Run regression tests.
4. Inspect failures without changing kernel authority first.

## Commands

```bash
python tests/test_smoke_entrypoint.py
python tests/test_regression_entrypoint.py
python hhs_runtime/hhs_v1_bundle_runner.py
python hhs_runtime/hhs_physics_evolution_v1.py --demo
```

## Common tasks

- Add a new adapter: route through `AuditedRunner` and `HHSStateLayerV1`.
- Add a new macro: define it through `terminal_hhsprog_v5_macro_algebra.py` and commit expansion traces.
- Add persistence: extend `hhs_database_integration_layer_v1.py` without replacing existing tables.
- Add physics behavior: add rules to `hhs_physics_evolution_v1.py`, not to the kernel.

## Do not

- Replace `security_hash72_v44`.
- Add SHA-based integrity for security commitments.
- Treat symbolic equality as a raw boolean outside witness contexts.
- Collapse ordered products.
