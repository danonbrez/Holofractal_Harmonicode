#ifndef HHS_PASS160_RUNTIME_H
#define HHS_PASS160_RUNTIME_H

#include <stddef.h>
#include <stdint.h>
#include "hhs_hash216.h"

#ifdef __cplusplus
extern "C" {
#endif

#define HHS160_ABI_VERSION_MAJOR 1u
#define HHS160_ABI_VERSION_MINOR 0u
#define HHS160_STRUCT_VERSION 1u
#define HHS160_SHA256_BYTES 32u
#define HHS160_MAX_REASON 96u
#define HHS160_MAX_OPERATIONS 256u
#define HHS160_MAX_TRANSITIONS 8192u
#define HHS160_MAX_SEGMENTS 512u
#define HHS160_MAX_EFFECTS 64u
#define HHS160_MAX_PROOF_DEPTH 32u

#define HHS_PASS160_CONTRACT_ID "HHS-P160-FPPORT-VTR"
#define HHS_PASS160_CONTRACT_VERSION "1.2.0"
#define HHS_PASS160_PREMAIN_CLASSIFICATION "HHS_PASS_160_IMPLEMENTATION_VERIFIED_PENDING_TERMINAL_EVIDENCE"
#define HHS_PASS160_TERMINAL_CLASSIFICATION "HHS_PASS_160_FIBONACCI_PRIME_PSEUDORANDOM_OVERLAP_RECEIPT_TIP_VALIDATED_TRANSITION_RUNTIME_VERIFIED"

typedef enum HHS160Status {
    HHS160_OK = 0,
    HHS160_INVALID_ARGUMENT = -1,
    HHS160_INVALID_VERSION = -2,
    HHS160_OUT_OF_MEMORY = -3,
    HHS160_RESOURCE_BOUNDED = -4,
    HHS160_NOT_FOUND = -5,
    HHS160_ALREADY_EXISTS = -6,
    HHS160_IDENTITY_MISMATCH = -7,
    HHS160_INTEGRITY_MISMATCH = -8,
    HHS160_REGISTRY_MISMATCH = -9,
    HHS160_PARENT_MISMATCH = -10,
    HHS160_MEMBERSHIP_MISMATCH = -11,
    HHS160_OVERLAP_MISMATCH = -12,
    HHS160_UNSEALED = -13,
    HHS160_REVOKED = -14,
    HHS160_QUARANTINED = -15,
    HHS160_CAPABILITY_DENIED = -16,
    HHS160_EXTERNAL_EFFECT_PROPOSAL_ONLY = -17,
    HHS160_STALE_FRONTIER = -18,
    HHS160_EPOCH_MISMATCH = -19,
    HHS160_OUTER_ADMISSION_REQUIRED = -20,
    HHS160_REPLAY_MISMATCH = -21,
    HHS160_CANONICAL_ENCODING_ERROR = -22,
    HHS160_PERMUTATION_ERROR = -23,
    HHS160_AUDIT_INCOMPLETE = -24,
    HHS160_UNSUPPORTED = -25,
    HHS160_INTERNAL_ERROR = -26
} HHS160Status;

typedef struct HHS160Integrity256 { uint8_t bytes[HHS160_SHA256_BYTES]; } HHS160Integrity256;
typedef struct HHS160Runtime HHS160Runtime;
typedef struct HHS160NestedRuntime HHS160NestedRuntime;
typedef struct HHS160AuditEpoch HHS160AuditEpoch;

typedef struct HHS160Result {
    uint32_t struct_size;
    uint32_t struct_version;
    HHS160Status status;
    uint8_t admitted;
    uint8_t authoritative_state_changed;
    uint8_t external_effect_executed;
    uint8_t reserved;
    char reason[HHS160_MAX_REASON];
    HHSHash72 receipt_hash72;
} HHS160Result;

typedef struct HHS160Config {
    uint32_t struct_size;
    uint32_t struct_version;
    uint64_t max_transitions;
    uint64_t max_segments;
    uint64_t max_nested_steps;
    uint64_t max_nested_memory_bytes;
    uint64_t fixed_audit_budget;
} HHS160Config;

typedef struct HHS160CertifiedOperation {
    uint32_t struct_size;
    uint32_t struct_version;
    HHSHash216 operation_id;
    HHSHash216 implementation_hash;
    HHSHash216 semantic_hash;
    HHSHash216 constraint_root;
    HHSHash216 runtime_semantic_root;
    HHSHash216 registry_root;
    HHSHash216 pass159_source_root;
    HHSHash216 pass159_vmir_root;
    HHSHash216 pass159_executable_root;
    uint64_t maximum_steps;
    uint64_t maximum_memory_bytes;
    uint64_t permitted_read_mask;
    uint64_t permitted_write_mask;
    uint32_t effect_class;
    uint8_t deterministic;
    uint8_t reusable;
    uint8_t revoked;
    uint8_t pass159_bound;
} HHS160CertifiedOperation;

typedef struct HHS160ValidatedTransition {
    uint32_t struct_size;
    uint32_t struct_version;
    uint64_t transition_epoch;
    uint64_t operation_sequence;
    uint64_t maximum_reuse_count;
    uint64_t original_validation_epoch;
    HHSHash216 parent_receipt_tip;
    HHSHash216 parent_state_root;
    HHSHash216 operation_id;
    HHSHash216 operation_implementation_hash;
    HHSHash216 operation_semantic_hash;
    HHSHash216 canonical_input_hash;
    HHSHash216 canonical_delta_hash;
    HHSHash216 resulting_state_root;
    HHSHash216 resulting_receipt_tip;
    HHSHash216 constraint_root;
    HHSHash216 runtime_semantic_root;
    HHSHash216 operation_registry_root;
    HHSHash216 validation_receipt_hash;
    HHSHash216 validator_manifest_hash;
    HHSHash216 pass159_source_root;
    HHSHash216 pass159_vmir_root;
    HHSHash216 pass159_executable_root;
    HHSHash216 pass159_equivalence_receipt;
    HHSHash216 transition_object_hash216;
    HHS160Integrity256 transition_integrity_sha256;
    HHS160Integrity256 delta_integrity_sha256;
    HHS160Integrity256 validation_receipt_integrity_sha256;
    uint64_t permitted_read_mask;
    uint64_t permitted_write_mask;
    uint64_t maximum_steps;
    uint64_t maximum_memory_bytes;
    uint32_t input_schema_id;
    uint32_t delta_schema_id;
    uint32_t state_schema_id;
    uint32_t effect_class;
    uint8_t semantically_validated;
    uint8_t sealed;
    uint8_t revoked;
    uint8_t external_effect_free;
    uint8_t pass159_bound;
    uint8_t reserved[7];
} HHS160ValidatedTransition;

typedef struct HHS160LookupKey {
    HHSHash216 parent_receipt_tip;
    HHSHash216 parent_state_root;
    HHSHash216 operation_id;
    HHSHash216 canonical_input_hash;
    HHSHash216 constraint_root;
    HHSHash216 runtime_semantic_root;
    HHSHash216 operation_implementation_hash;
    HHSHash216 operation_registry_root;
} HHS160LookupKey;

typedef struct HHS160SegmentCertificate {
    uint32_t struct_size;
    uint32_t struct_version;
    uint64_t segment_id;
    uint64_t start_index;
    uint64_t transition_count;
    uint64_t overlap_prefix_count;
    uint64_t overlap_suffix_count;
    HHSHash216 start_parent_tip;
    HHSHash216 start_state_root;
    HHSHash216 end_receipt_tip;
    HHSHash216 end_state_root;
    HHSHash216 transition_root_hash216;
    HHSHash216 overlap_prefix_root_hash216;
    HHSHash216 overlap_suffix_root_hash216;
    HHS160Integrity256 transition_merkle_root_sha256;
    HHS160Integrity256 overlap_prefix_root_sha256;
    HHS160Integrity256 overlap_suffix_root_sha256;
    HHSHash216 constraint_root;
    HHSHash216 runtime_semantic_root;
    HHSHash216 operation_registry_root;
    HHSHash216 previous_segment_certificate_hash216;
    HHSHash216 segment_certificate_hash216;
    HHS160Integrity256 segment_certificate_integrity_sha256;
    uint8_t sealed;
    uint8_t quarantined;
    uint8_t revoked;
    uint8_t coverage_valid;
} HHS160SegmentCertificate;

typedef struct HHS160HistoricalFrontier {
    uint32_t struct_size;
    uint32_t struct_version;
    uint64_t frontier_epoch;
    uint64_t terminal_transition_epoch;
    uint64_t segment_count;
    uint64_t total_transition_count;
    HHSHash216 terminal_receipt_tip;
    HHSHash216 terminal_state_root;
    HHSHash216 level0_root;
    HHSHash216 level1_root;
    HHSHash216 level2_root;
    HHSHash216 level3_root;
    HHSHash216 release_frontier_root;
    HHS160Integrity256 release_frontier_integrity_sha256;
    HHSHash216 constraint_root;
    HHSHash216 runtime_semantic_root;
    HHSHash216 operation_registry_root;
    HHSHash216 previous_frontier_hash216;
    HHSHash216 frontier_certificate_hash216;
    HHS160Integrity256 frontier_certificate_integrity_sha256;
    uint8_t sealed;
    uint8_t current;
    uint8_t revoked;
    uint8_t replay_verified;
} HHS160HistoricalFrontier;

typedef struct HHS160MerkleProof {
    uint32_t depth;
    HHS160Integrity256 sibling[HHS160_MAX_PROOF_DEPTH];
    uint8_t sibling_is_left[HHS160_MAX_PROOF_DEPTH];
} HHS160MerkleProof;

typedef struct HHS160EffectProposal {
    uint32_t effect_class;
    HHSHash216 payload_hash216;
    HHS160Integrity256 payload_integrity_sha256;
    uint8_t executed;
    uint8_t externally_admitted;
    uint8_t proposal_only;
    uint8_t reserved;
} HHS160EffectProposal;

typedef enum HHS160CommitBackend {
    HHS160_COMMIT_VM81 = 1,
    HHS160_COMMIT_PASS158 = 2
} HHS160CommitBackend;

typedef struct HHS160CommitCandidate {
    uint64_t expected_frontier_epoch;
    uint64_t proposal_epoch;
    HHSHash216 base_frontier_hash216;
    HHSHash216 resulting_state_root;
    HHSHash216 resulting_receipt_tip;
    HHSHash72 local_receipt_hash72;
    uint32_t backend;
    uint8_t verified;
    uint8_t applied;
    uint8_t outer_admission_verified;
    uint8_t reserved;
} HHS160CommitCandidate;

typedef struct HHS160CoverageCertificate {
    uint64_t audit_epoch;
    uint64_t domain_length;
    uint64_t temporal_cycle_length;
    uint64_t sampled_count;
    uint64_t cover_count;
    uint64_t failed_count;
    HHS160Integrity256 seed_commitment_sha256;
    HHS160Integrity256 sampled_result_accumulator_sha256;
    HHSHash216 coverage_certificate_hash216;
    uint8_t complete_permutation;
    uint8_t every_index_visited_once;
    uint8_t storage_integrity_valid;
    uint8_t segment_reuse_allowed;
} HHS160CoverageCertificate;

typedef int (*HHS160OuterAdmissionFn)(const HHS160CommitCandidate *candidate, void *user_data);

uint32_t hhs160_abi_version_major(void);
uint32_t hhs160_abi_version_minor(void);
const char *hhs160_contract_id(void);
const char *hhs160_contract_version(void);
const char *hhs160_status_string(HHS160Status status);

void hhs160_integrity_sha256(const char *domain, const void *data, size_t size, HHS160Integrity256 *out);
void hhs160_hmac_sha256(const uint8_t key[32], const void *data, size_t size, HHS160Integrity256 *out);
int hhs160_integrity_equal(const HHS160Integrity256 *a, const HHS160Integrity256 *b);
void hhs160_integrity_hex(const HHS160Integrity256 *value, char out[65]);

HHS160Status hhs160_runtime_create(const HHS160Config *config, HHS160Runtime **out_runtime, HHS160Result *result);
void hhs160_runtime_destroy(HHS160Runtime *runtime);
HHS160Status hhs160_register_operation(HHS160Runtime *runtime, const HHS160CertifiedOperation *operation, HHS160Result *result);
HHS160Status hhs160_transition_seal_identity(HHS160ValidatedTransition *transition, HHS160Result *result);
HHS160Status hhs160_transition_verify_identity(const HHS160ValidatedTransition *transition, HHS160Result *result);
HHS160Status hhs160_transition_admit(HHS160Runtime *runtime, HHS160ValidatedTransition *transition, uint64_t *out_index, HHS160Result *result);
void hhs160_lookup_key_from_transition(const HHS160ValidatedTransition *transition, HHS160LookupKey *out_key);
HHS160Status hhs160_transition_lookup(HHS160Runtime *runtime, const HHS160LookupKey *key, uint64_t *out_index, HHS160ValidatedTransition *out_transition, HHS160Result *result);
HHS160Status hhs160_transition_revoke(HHS160Runtime *runtime, uint64_t index, HHS160Result *result);
HHS160Status hhs160_segment_seal(HHS160Runtime *runtime, uint64_t start_index, uint64_t count, uint64_t overlap_prefix, uint64_t overlap_suffix, HHS160SegmentCertificate *out_certificate, HHS160Result *result);
HHS160Status hhs160_segment_verify_overlap(const HHS160SegmentCertificate *left, const HHS160SegmentCertificate *right, HHS160Result *result);
HHS160Status hhs160_segment_quarantine(HHS160Runtime *runtime, uint64_t segment_id, HHS160Result *result);
HHS160Status hhs160_segment_membership_proof(HHS160Runtime *runtime, uint64_t segment_id, uint64_t transition_index, HHS160MerkleProof *out_proof, HHS160Result *result);
HHS160Status hhs160_segment_verify_membership(const HHS160ValidatedTransition *transition, const HHS160MerkleProof *proof, const HHS160SegmentCertificate *certificate, HHS160Result *result);
HHS160Status hhs160_frontier_seal(HHS160Runtime *runtime, uint64_t frontier_epoch, const HHSHash216 *terminal_tip, const HHSHash216 *terminal_state, HHS160HistoricalFrontier *out_frontier, HHS160Result *result);
HHS160Status hhs160_frontier_load(HHS160Runtime *runtime, const HHS160HistoricalFrontier *frontier, HHS160Result *result);
HHS160Status hhs160_nested_begin(HHS160Runtime *runtime, uint64_t runtime_instance_id, uint64_t maximum_steps, HHS160NestedRuntime **out_nested, HHS160Result *result);
HHS160Status hhs160_nested_reuse(HHS160NestedRuntime *nested, uint64_t transition_index, uint64_t segment_id, HHS160Result *result);
HHS160Status hhs160_nested_propose_effect(HHS160NestedRuntime *nested, uint32_t effect_class, const void *payload, size_t payload_size, HHS160EffectProposal *out_proposal, HHS160Result *result);
HHS160Status hhs160_nested_finalize(HHS160NestedRuntime *nested, uint32_t backend, HHS160CommitCandidate *out_candidate, HHS160Result *result);
void hhs160_nested_destroy(HHS160NestedRuntime *nested);
HHS160Status hhs160_commit_verify(HHS160Runtime *runtime, HHS160CommitCandidate *candidate, HHS160Result *result);
HHS160Status hhs160_commit_apply(HHS160Runtime *runtime, HHS160CommitCandidate *candidate, HHS160OuterAdmissionFn outer_admission, void *user_data, HHS160HistoricalFrontier *out_frontier, HHS160Result *result);
uint64_t hhs160_fibonacci_prime_cycle_length(uint32_t level);
HHS160Status hhs160_temporal_bucket_quota(uint64_t bucket, uint64_t domain_length, uint64_t cycle_length, uint64_t *out_quota, HHS160Result *result);
HHS160Status hhs160_permutation_index(const uint8_t key[32], uint64_t domain_length, uint64_t ordinal, uint64_t *out_index, HHS160Result *result);
HHS160Status hhs160_audit_begin(HHS160Runtime *runtime, uint64_t audit_epoch, uint32_t level, const uint8_t key[32], HHS160AuditEpoch **out_audit, HHS160Result *result);
HHS160Status hhs160_audit_step(HHS160AuditEpoch *audit, HHS160Result *result);
HHS160Status hhs160_audit_complete(HHS160AuditEpoch *audit, HHS160CoverageCertificate *out_certificate, HHS160Result *result);
HHS160Status hhs160_audit_replay(HHS160Runtime *runtime, uint64_t audit_epoch, uint32_t level, const uint8_t key[32], const HHS160CoverageCertificate *expected, HHS160Result *result);
void hhs160_audit_destroy(HHS160AuditEpoch *audit);
HHS160Status hhs160_runtime_receipt_export(const HHS160Runtime *runtime, HHSHash72 *out_receipt, HHS160Result *result);
uint64_t hhs160_runtime_transition_count(const HHS160Runtime *runtime);
uint64_t hhs160_runtime_segment_count(const HHS160Runtime *runtime);
uint64_t hhs160_nested_capability_count(const HHS160NestedRuntime *nested);

#ifdef __cplusplus
}
#endif
#endif
