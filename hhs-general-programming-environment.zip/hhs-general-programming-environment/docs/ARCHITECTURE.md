# Architecture

## Stack

```text
HARMONICODE_KERNEL_v44_2...locked-7.py
  ↓
hhs_general_runtime_layer_v1.py
  ↓
Hash receipts / replay verifier / state layer
  ↓
terminals / input bridge / physics model / physics evolution
```

## Execution loop

```text
source/event/observation
→ adapter projection
→ symbolic witness or exact rational operation
→ state patch or operation dispatch
→ kernel audit
→ Hash72 receipt
→ replayable output/state
```

## Layer responsibilities

- **Kernel**: authoritative Hash72, manifold anchor, drift gate.
- **Runtime layer**: operation registry, Hash72 commitment chain, kernel gate adapter.
- **Replay verifier**: receipt continuity and recomputation.
- **Control flow**: IF/LOOP witnesses and stutter/termination gates.
- **Database bridge**: persistent traces, receipts, witnesses.
- **Program CLI**: `.hhsprog` and `.hhsrun` file execution/verification.
- **Terminals**: interactive command, algebra, symbolic, and macro shells.
- **Input bridge**: maps user events to symbolic GUI commitments.
- **State layer**: canonical evolving state with diff-based transitions.
- **Physics model**: typed carrier projection of observations into HHS state.
- **Physics evolution**: deterministic candidate evolution patches over physics state.

## Fail-closed model

Every write-like transition must produce a receipt. Failed checks quarantine and do not advance canonical state.
