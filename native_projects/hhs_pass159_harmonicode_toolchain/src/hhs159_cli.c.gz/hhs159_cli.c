#include "hhs_pass159_api.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int print_artifact(void *artifact) {
    HHS159MutableByteSpan out = {0};
    HHS159Status status = hhs159_artifact_bytes(artifact, &out);
    if (status != HHS159_STATUS_RESOURCE_BOUNDED) return 1;
    out.data = (uint8_t *)malloc(out.size_written + 1u);
    if (!out.data) return 1;
    out.capacity = out.size_written;
    status = hhs159_artifact_bytes(artifact, &out);
    if (status == HHS159_STATUS_OK) {
        fwrite(out.data, 1u, out.size_written, stdout);
        if (out.size_written == 0u || out.data[out.size_written - 1u] != '\n') putchar('\n');
    }
    free(out.data);
    return status == HHS159_STATUS_OK ? 0 : 1;
}

static int open_source(HHS159Context *context, const char *path, HHS159Source **out_source) {
    HHS159SourceOpenOptions options = {{sizeof(options), HHS159_STRUCT_VERSION_1}, {0}, {(const uint8_t *)"UTF-8", 5u}, 1u, 0u};
    return hhs159_source_open_file(context, path, &options, out_source) == HHS159_STATUS_OK ? 0 : 1;
}

static void usage(const char *name) {
    fprintf(stderr,
        "usage: %s <check|parse|ast|types|graph|ir|asm|run|compile|compare|doctor> <source-file>\n",
        name);
}

int main(int argc, char **argv) {
    HHS159ContextConfig config = {{sizeof(config), HHS159_STRUCT_VERSION_1}, 0u, 0u, 0u, 0u, 0u, 0u, 0u};
    HHS159Context *context = NULL;
    HHS159Source *source = NULL;
    HHS159CST *cst = NULL;
    HHS159AST *ast = NULL;
    HHS159TypeEnvironment *types = NULL;
    HHS159ConstraintGraph *graph = NULL;
    HHS159IR *hir = NULL, *vmir = NULL;
    HHS159Compiler *compiler = NULL;
    HHS159Interpreter *interpreter = NULL;
    HHS159Object *object = NULL;
    HHS159Executable *executable = NULL;
    HHS159Receipt *receipt = NULL, *phase = NULL;
    HHS159Status status = HHS159_STATUS_OK;
    int rc = 1;

    if (hhs159_context_create(&config, &context) != HHS159_STATUS_OK) return 2;
    if (argc >= 2 && strcmp(argv[1], "doctor") == 0) {
        printf("{\"contract\":\"%s\",\"version\":\"%s\",\"abi\":\"%u.%u\",\"classification\":\"%s\",\"authoritative_float\":false,\"vm81_admission_required\":true}\n",
            hhs159_contract_id(), hhs159_contract_version(), hhs159_abi_version_major(), hhs159_abi_version_minor(), HHS159_FOUNDATION_CLASSIFICATION);
        hhs159_context_release(context);
        return 0;
    }
    if (argc < 3) { usage(argv[0]); hhs159_context_release(context); return 2; }
    if (open_source(context, argv[2], &source) != 0) goto done;

    if (strcmp(argv[1], "check") == 0) {
        status = hhs159_parse_cst(context, source, &cst);
        if (status == HHS159_STATUS_OK) status = hhs159_build_ast(context, cst, &ast);
        if (status == HHS159_STATUS_OK) status = hhs159_typecheck(context, ast, &types);
        if (status == HHS159_STATUS_OK) printf("HHS159_CHECK_OK %s\n", HHS159_FOUNDATION_CLASSIFICATION);
    } else if (strcmp(argv[1], "parse") == 0) {
        status = hhs159_parse_cst(context, source, &cst);
        if (status == HHS159_STATUS_OK) rc = print_artifact(cst);
        goto done;
    } else if (strcmp(argv[1], "ast") == 0) {
        status = hhs159_parse_cst(context, source, &cst);
        if (status == HHS159_STATUS_OK) status = hhs159_build_ast(context, cst, &ast);
        if (status == HHS159_STATUS_OK) rc = print_artifact(ast);
        goto done;
    } else if (strcmp(argv[1], "types") == 0 || strcmp(argv[1], "graph") == 0 || strcmp(argv[1], "ir") == 0 || strcmp(argv[1], "asm") == 0) {
        status = hhs159_parse_cst(context, source, &cst);
        if (status == HHS159_STATUS_OK) status = hhs159_build_ast(context, cst, &ast);
        if (status == HHS159_STATUS_OK) status = hhs159_typecheck(context, ast, &types);
        if (strcmp(argv[1], "types") == 0 && status == HHS159_STATUS_OK) { rc = print_artifact(types); goto done; }
        if (status == HHS159_STATUS_OK) status = hhs159_build_constraint_graph(context, ast, types, &graph);
        if (strcmp(argv[1], "graph") == 0 && status == HHS159_STATUS_OK) { rc = print_artifact(graph); goto done; }
        if (status == HHS159_STATUS_OK) status = hhs159_lower_hir(context, ast, types, graph, &hir);
        if (strcmp(argv[1], "ir") == 0 && status == HHS159_STATUS_OK) { rc = print_artifact(hir); goto done; }
        if (status == HHS159_STATUS_OK) status = hhs159_lower_vmir(context, hir, &vmir);
        if (status == HHS159_STATUS_OK) rc = print_artifact(vmir);
        goto done;
    } else if (strcmp(argv[1], "run") == 0) {
        HHS159ExecutionOptions options = {{sizeof(options), HHS159_STRUCT_VERSION_1}, HHS159_MODE_EVALUATE_PURE, 0u, 100000u, 128u, 1024u * 1024u, NULL};
        status = hhs159_interpreter_create(context, &interpreter);
        if (status == HHS159_STATUS_OK) status = hhs159_interpret(interpreter, source, &options, &receipt);
        if (status == HHS159_STATUS_OK) rc = print_artifact(receipt);
        goto done;
    } else if (strcmp(argv[1], "compile") == 0) {
        status = hhs159_compiler_create(context, &compiler);
        if (status == HHS159_STATUS_OK) status = hhs159_compile_object(compiler, source, &object, &phase);
        if (status == HHS159_STATUS_OK) rc = print_artifact(object);
        goto done;
    } else if (strcmp(argv[1], "compare") == 0) {
        HHS159ExecutionOptions options = {{sizeof(options), HHS159_STRUCT_VERSION_1}, HHS159_MODE_EVALUATE_PURE, 0u, 100000u, 128u, 1024u * 1024u, NULL};
        HHS159CompareResult result = {0};
        result.header.struct_size = sizeof(result);
        result.header.struct_version = HHS159_STRUCT_VERSION_1;
        status = hhs159_compare_interpreter_compiler(context, source, &options, &result);
        printf("{\"matched\":%s,\"fallback_used\":%s,\"classification\":\"%s\"}\n",
            result.matched ? "true" : "false", result.fallback_used ? "true" : "false", result.classification);
    } else {
        usage(argv[0]);
        status = HHS159_STATUS_INVALID_ARGUMENT;
    }

    rc = status == HHS159_STATUS_OK ? 0 : 1;
done:
    if (status != HHS159_STATUS_OK) {
        HHS159DiagnosticSet *diagnostics = NULL;
        fprintf(stderr, "hhs159: %s\n", hhs159_status_string(status));
        if (hhs159_get_diagnostics(context, &diagnostics) == HHS159_STATUS_OK) {
            print_artifact(diagnostics);
            hhs159_artifact_release(diagnostics);
        }
    }
    hhs159_receipt_release(phase);
    hhs159_receipt_release(receipt);
    hhs159_artifact_release(executable);
    hhs159_artifact_release(object);
    hhs159_artifact_release(vmir);
    hhs159_artifact_release(hir);
    hhs159_artifact_release(graph);
    hhs159_artifact_release(types);
    hhs159_artifact_release(ast);
    hhs159_artifact_release(cst);
    hhs159_interpreter_release(interpreter);
    hhs159_compiler_release(compiler);
    hhs159_source_release(source);
    hhs159_context_release(context);
    return rc;
}
