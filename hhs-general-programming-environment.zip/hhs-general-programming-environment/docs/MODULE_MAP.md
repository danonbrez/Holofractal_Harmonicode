# Module Map

| Module | Purpose |
|---|---|
| `HARMONICODE_KERNEL_v44_2_lockcore_patched_selfsolving_hash72authority_locked-7.py` | Locked kernel authority. |
| `harmonicode_agent_v43_3_dna_lockcore_patched_selfsolving_hash72authority_locked-7.py` | Local agent bridge into locked runtime. |
| `harmonicode_full_schema_v1_1_security_hardened-1.py` | Security-hardened schema constants. |
| `harmonicode_modality_verbatim_ingestion_v1-1.py` | Verbatim modality ingestion layer. |
| `harmonicode_verbatim_semantic_database_v1.py` | Semantic database substrate. |
| `hhs_general_runtime_layer_v1.py` | Core audited runner and Hash72 commitment layer. |
| `hhs_runtime_smoke_tests_v1.py` | Smoke test suite. |
| `hhs_receipt_replay_verifier_v1.py` | Receipt-chain verifier. |
| `hhs_control_flow_gates_v1.py` | IF/LOOP control-flow gates. |
| `hhs_database_integration_layer_v1.py` | SQLite trace/receipt persistence. |
| `hhs_program_format_and_cli_v1.py` | `.hhsprog` and `.hhsrun` CLI. |
| `hhs_regression_suite_v1.py` | Regression tests. |
| `hhs_v1_bundle_runner.py` | Full bundle certification runner. |
| `terminal_hhsprog_v1.py` | Basic interactive shell. |
| `terminal_hhsprog_v2.py` | Variables and pipes. |
| `terminal_hhsprog_v3_algebra.py` | Algebra expression shell. |
| `terminal_hhsprog_v4_symbolic.py` | Symbolic expression ingestion. |
| `terminal_hhsprog_v5_macro_algebra.py` | Macro-capable symbolic algebra terminal. |
| `hhs_input_bridge_v1.py` | GUI/user input event bridge. |
| `hhs_state_layer_v1.py` | Deterministic state machine layer. |
| `hhs_physics_model_v1.py` | Physical observation adapter. |
| `hhs_physics_evolution_v1.py` | Deterministic physics evolution operator. |
