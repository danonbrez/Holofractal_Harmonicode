from __future__ import annotations

import copy
from hashlib import sha256
import importlib
import json
from pathlib import Path
import sys
import types

import pytest


def _canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _hash216(domain, value):
    return sha256((domain + "\0" + _canonical_json(value)).encode("utf-8")).hexdigest()


def _hash72(domain, value):
    digest = sha256((domain + "\0" + _canonical_json(value)).encode("utf-8")).hexdigest()
    return digest + digest[:8]


def _load_oracle_module():
    try:
        return importlib.import_module("hhs_backend.runtime.hhs_pass214_oracle_adjudication_v1")
    except ModuleNotFoundError:
        fake = types.ModuleType("hhs_backend.runtime.hhs_pass214_callable_conformance_v1")
        fake.CONTRACT = "HHS-P214-TEST"
        fake.PASS213_FOUNDATION = {"closure_commit": "86ec461818682fc87232740758769602e8f9fe05"}
        fake.Pass214ConformanceError = type("Pass214ConformanceError", (RuntimeError,), {})
        fake.canonical_json = _canonical_json
        fake.hash216 = _hash216
        fake.hash72 = _hash72
        fake.load_and_validate_callable_conformance_outputs = lambda _path: None
        sys.modules[fake.__name__] = fake
        return importlib.import_module("hhs_backend.runtime.hhs_pass214_oracle_adjudication_v1")


oracle = _load_oracle_module()

A = "a" * 64
B = "b" * 64
C = "c" * 64
D = "d" * 64
E = "e" * 64
F = "f" * 64
G = "1" * 64
H = "2" * 64
SOURCE_COMMIT = "3" * 40
SOURCE_TREE = "4" * 40
I2_ROOT = "5" * 64


def _iteration2_bundle():
    symbols = [A, B, C, D, E, F, G, H]
    records = [{"symbol_hash216": value, "implementation_hash216": sha256(value.encode()).hexdigest()} for value in symbols]
    edges = [
        {"source_symbol_hash216": A, "target_symbol_hash216": B},
        {"source_symbol_hash216": C, "target_symbol_hash216": D},
        {"source_symbol_hash216": E, "target_symbol_hash216": F},
        {"source_symbol_hash216": G, "target_symbol_hash216": H},
    ]
    return {
        "callable_conformance_records": records,
        "compatibility_edges": edges,
        "authority_conflicts": [],
        "iteration2_summary": {
            "source_commit": SOURCE_COMMIT,
            "source_tree": SOURCE_TREE,
            "roots": {"iteration2_semantic_root_hash216": I2_ROOT},
        },
    }


def _handler(handler_id, config=None):
    return {"handler_id": handler_id, "config": config or {}}


def _workloads():
    return [
        {
            "workload_id": "eq-no-adapter",
            "source_symbol_hash216": A,
            "target_symbol_hash216": B,
            "source_handler": _handler("identity"),
            "target_handler": _handler("canonical_roundtrip"),
            "vectors": [{"input": {"x": 1}}, {"input": [1, 2, 3]}],
        },
        {
            "workload_id": "eq-adapter",
            "source_symbol_hash216": C,
            "target_symbol_hash216": D,
            "source_handler": _handler("key_rename", {"mapping": {"old": "new"}}),
            "target_handler": _handler("identity"),
            "target_output_adapter": {
                "adapter_class": "KEY_RENAME",
                "handler_id": "key_rename",
                "config": {"mapping": {"old": "new"}},
            },
            "vectors": [{"input": {"old": 7}}, {"input": {"old": {"nested": True}}}],
        },
        {
            "workload_id": "divergent",
            "source_symbol_hash216": E,
            "target_symbol_hash216": F,
            "source_handler": _handler("identity"),
            "target_handler": _handler("sha256_canonical"),
            "vectors": [{"input": {"x": 9}}],
        },
        {
            "workload_id": "unresolved",
            "source_symbol_hash216": G,
            "target_symbol_hash216": H,
            "source_handler": _handler("identity"),
            "target_handler": _handler("not_registered"),
            "vectors": [{"input": "value"}],
        },
    ]


def _receipt(workload):
    vectors = workload["vectors"]
    input_root = oracle.hash216("pass214-iteration3-oracle-inputs", vectors)
    return oracle.create_pass213_admission_receipt(
        workload_id=workload["workload_id"],
        input_root_hash216=input_root,
        trusted_timestamp_anchor_root_hash216="6" * 64,
        moving_tensor_root_hash216="7" * 64,
        native_dispatch_receipt_root_hash216="8" * 64,
    )


def _manifest(workloads=None):
    workloads = copy.deepcopy(workloads or _workloads())
    return {
        "schema": oracle.MANIFEST_SCHEMA,
        "contract": oracle.CONTRACT,
        "pass213_foundation": oracle.PASS213_FOUNDATION,
        "source_commit": SOURCE_COMMIT,
        "source_tree": SOURCE_TREE,
        "predecessor_iteration2_semantic_root_hash216": I2_ROOT,
        "workloads": workloads,
        "admission_receipts": [_receipt(item) for item in workloads],
    }


@pytest.fixture(autouse=True)
def _bind_iteration2(monkeypatch):
    monkeypatch.setattr(oracle, "load_and_validate_callable_conformance_outputs", lambda _path: _iteration2_bundle())


def test_oracle_adjudication_covers_equivalence_adapter_divergence_and_unresolved(tmp_path):
    result = oracle.build_oracle_adjudication_bundle(tmp_path, _manifest())
    states = {item["workload_id"]: item["oracle_state"] for item in result["oracle_records"]}
    assert states == {
        "divergent": "ORACLE_DIVERGENCE",
        "eq-adapter": "ORACLE_EQUIVALENCE_VERIFIED",
        "eq-no-adapter": "ORACLE_EQUIVALENCE_VERIFIED",
        "unresolved": "ORACLE_HANDLER_UNRESOLVED",
    }
    adjudications = {item["workload_id"]: item["adjudication_status"] for item in result["authority_adjudications"]}
    assert adjudications == {
        "divergent": "DIVERGENT_ORACLE_MODEL_RECORDED",
        "eq-adapter": "IDENTITY_PRESERVING_ADAPTER_MODEL_VERIFIED",
        "eq-no-adapter": "REFERENCE_MODEL_BEHAVIOR_RETAINED",
        "unresolved": "UNRESOLVED",
    }
    assert len(result["integration_adapters"]) == 1
    proof = result["integration_adapters"][0]
    assert proof["deterministic_replay_equal"] is True
    assert proof["authority_promotion_authorized"] is False
    assert all(item["automatic_merge_authorized"] is False for item in result["authority_adjudications"])
    assert all(item["repository_authority_change_authorized"] is False for item in result["authority_adjudications"])
    assert all(item["terminal_authority_minted"] is False for item in result["authority_adjudications"])
    assert result["iteration3_summary"]["claim_boundary"]["pass214_terminal_roots_minted"] is False
    oracle.validate_oracle_adjudication_bundle(result)


def test_forged_pass213_admission_is_inadmissible(tmp_path):
    manifest = _manifest([_workloads()[0]])
    manifest["admission_receipts"][0]["moving_tensor_root_hash216"] = "9" * 64
    result = oracle.build_oracle_adjudication_bundle(tmp_path, manifest)
    record = result["oracle_records"][0]
    assert record["oracle_state"] == "ORACLE_INADMISSIBLE"
    assert record["runtime_verified"] is False
    assert result["authority_adjudications"][0]["adjudication_status"] == "UNRESOLVED"


def test_unauthorized_pair_is_rejected(tmp_path):
    workload = _workloads()[0]
    workload["target_symbol_hash216"] = C
    manifest = _manifest([workload])
    with pytest.raises(oracle.Pass214OracleError, match="PAIR_NOT_IN_ITERATION2_GRAPH"):
        oracle.build_oracle_adjudication_bundle(tmp_path, manifest)


def test_duplicate_admission_receipt_ids_are_rejected(tmp_path):
    manifest = _manifest([_workloads()[0]])
    manifest["admission_receipts"].append(copy.deepcopy(manifest["admission_receipts"][0]))
    with pytest.raises(oracle.Pass214OracleError, match="ADMISSION_RECEIPT_IDS_INVALID"):
        oracle.build_oracle_adjudication_bundle(tmp_path, manifest)


def test_adapter_mismatch_does_not_produce_proof(tmp_path):
    workload = _workloads()[1]
    workload["target_output_adapter"]["handler_id"] = "identity"
    result = oracle.build_oracle_adjudication_bundle(tmp_path, _manifest([workload]))
    assert result["oracle_records"][0]["oracle_state"] == "ORACLE_HANDLER_UNRESOLVED"
    assert result["integration_adapters"] == []


def test_write_load_and_recomputed_tamper_rejection(tmp_path):
    result = oracle.build_oracle_adjudication_bundle(tmp_path, _manifest())
    out = tmp_path / "outputs"
    oracle.write_oracle_adjudication_outputs(result, out)
    loaded = oracle.load_and_validate_oracle_adjudication_outputs(out)
    assert loaded["iteration3_summary"]["receipt_hash72"] == result["iteration3_summary"]["receipt_hash72"]

    tampered = copy.deepcopy(loaded)
    tampered["authority_adjudications"][0]["automatic_merge_authorized"] = True
    body = {
        key: value
        for key, value in tampered["authority_adjudications"][0].items()
        if key != "adjudication_root_hash216"
    }
    tampered["authority_adjudications"][0]["adjudication_root_hash216"] = oracle.hash216(
        "pass214-iteration3-authority-adjudication", body
    )
    tampered["iteration3_summary"]["roots"]["authority_adjudication_root_hash216"] = oracle.hash216(
        "pass214-iteration3-authority-adjudications", tampered["authority_adjudications"]
    )
    with pytest.raises(oracle.Pass214OracleError, match="AUTOMATIC_AUTHORITY_MERGE_FORBIDDEN"):
        oracle.validate_oracle_adjudication_bundle(tampered)


def test_semantic_root_and_receipt_tampering_rejected(tmp_path):
    result = oracle.build_oracle_adjudication_bundle(tmp_path, _manifest())
    tampered = copy.deepcopy(result)
    tampered["iteration3_summary"]["roots"]["iteration3_semantic_root_hash216"] = "0" * 64
    with pytest.raises(oracle.Pass214OracleError, match="SEMANTIC_ROOT_MISMATCH"):
        oracle.validate_oracle_adjudication_bundle(tampered)

    tampered = copy.deepcopy(result)
    tampered["iteration3_summary"]["receipt_hash72"] = "x" * 72
    with pytest.raises(oracle.Pass214OracleError, match="RECEIPT_HASH72_MISMATCH"):
        oracle.validate_oracle_adjudication_bundle(tampered)
