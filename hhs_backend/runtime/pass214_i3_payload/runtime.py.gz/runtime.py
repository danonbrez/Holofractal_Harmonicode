"""Pass 214 Iteration 3: deterministic oracle adjudication and adapter proofs.

This layer consumes a validated Iteration 2 compatibility graph. It executes only
built-in, explicitly named pure handlers. It never imports a candidate repository
module and never promotes an authority merely because a static signature matches.
"""
from __future__ import annotations

from collections import Counter
import copy
from hashlib import sha256
import hmac
import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from hhs_backend.runtime.hhs_pass214_callable_conformance_v1 import (
    CONTRACT,
    PASS213_FOUNDATION,
    Pass214ConformanceError,
    canonical_json,
    hash216,
    hash72,
    load_and_validate_callable_conformance_outputs,
)

ITERATION = 3
RUNTIME_CLASSIFICATION = "HHS_PASS_214_ITERATION_3_ADMITTED_ORACLE_MODEL_AND_ADAPTER_PROOF_IMPLEMENTED"
ORACLE_SCOPE = "MANIFESTED_PASS213_ADMITTED_PURE_HANDLER_MODEL"
MANIFEST_SCHEMA = "HHS_PASS_214_ITERATION_3_ORACLE_WORKLOAD_MANIFEST_V1"
ADMISSION_SCHEMA = "HHS_PASS_214_ITERATION_3_PASS213_ADMISSION_RECEIPT_V1"
ZERO_HASH216 = "0" * 64

PASS213_AUTHORITY_BINDINGS = (
    {
        "path": "hhs_backend/runtime/hhs_pass213_trusted_timestamp_v1.py",
        "callables": ("TimestampAnchorIntent.create", "RFC3161TimestampVerifier", "TrustedTimestampAnchorStore"),
        "purpose": "trusted external timestamp lineage",
    },
    {
        "path": "hhs_backend/runtime/hhs_pass213_moving_tensor_v1.py",
        "callables": ("MovingTensorState.derive", "MovingTensorState.validate_structure"),
        "purpose": "exact moving tensor, closure, and replay authority",
    },
)

HANDLER_IDS = {
    "identity",
    "canonical_roundtrip",
    "positional_to_named",
    "key_rename",
    "field_projection",
    "canonical_bytes_envelope",
    "sha256_canonical",
}
ADAPTER_CLASSES = {
    "IDENTITY",
    "POSITIONAL_TO_NAMED",
    "KEY_RENAME",
    "FIELD_PROJECTION",
    "CANONICAL_BYTES_ENVELOPE",
}


class Pass214OracleError(RuntimeError):
    """Raised when an Iteration 3 oracle or adapter invariant fails."""


def _require_hash216(value: Any, code: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise Pass214OracleError(code)
    try:
        int(value, 16)
    except ValueError as exc:
        raise Pass214OracleError(code) from exc
    return value


def _require_text(value: Any, code: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise Pass214OracleError(code)
    return value


def _deep_copy(value: Any) -> Any:
    return json.loads(canonical_json(value))


def _handler_identity(value: Any, config: Mapping[str, Any]) -> Any:
    if config:
        raise Pass214OracleError("PASS214_ITERATION3_IDENTITY_CONFIG_FORBIDDEN")
    return _deep_copy(value)


def _handler_canonical_roundtrip(value: Any, config: Mapping[str, Any]) -> Any:
    if config:
        raise Pass214OracleError("PASS214_ITERATION3_CANONICAL_CONFIG_FORBIDDEN")
    return json.loads(canonical_json(value))


def _handler_positional_to_named(value: Any, config: Mapping[str, Any]) -> Any:
    names = config.get("names")
    if not isinstance(names, list) or not names or not all(isinstance(item, str) and item for item in names):
        raise Pass214OracleError("PASS214_ITERATION3_POSITIONAL_NAMES_INVALID")
    if not isinstance(value, list) or len(value) != len(names):
        raise Pass214OracleError("PASS214_ITERATION3_POSITIONAL_ARITY_MISMATCH")
    return {name: _deep_copy(item) for name, item in zip(names, value)}


def _handler_key_rename(value: Any, config: Mapping[str, Any]) -> Any:
    mapping = config.get("mapping")
    if not isinstance(value, dict) or not isinstance(mapping, dict) or not mapping:
        raise Pass214OracleError("PASS214_ITERATION3_KEY_RENAME_INVALID")
    if not all(isinstance(key, str) and isinstance(target, str) and key and target for key, target in mapping.items()):
        raise Pass214OracleError("PASS214_ITERATION3_KEY_RENAME_MAP_INVALID")
    output: dict[str, Any] = {}
    for key, item in value.items():
        target = mapping.get(key, key)
        if target in output:
            raise Pass214OracleError("PASS214_ITERATION3_KEY_RENAME_COLLISION")
        output[target] = _deep_copy(item)
    return output


def _handler_field_projection(value: Any, config: Mapping[str, Any]) -> Any:
    fields = config.get("fields")
    if not isinstance(value, dict) or not isinstance(fields, list) or not fields:
        raise Pass214OracleError("PASS214_ITERATION3_FIELD_PROJECTION_INVALID")
    if not all(isinstance(field, str) and field for field in fields):
        raise Pass214OracleError("PASS214_ITERATION3_FIELD_PROJECTION_FIELDS_INVALID")
    missing = [field for field in fields if field not in value]
    if missing:
        raise Pass214OracleError("PASS214_ITERATION3_FIELD_PROJECTION_MISSING:" + ",".join(missing))
    return {field: _deep_copy(value[field]) for field in fields}


def _handler_canonical_bytes_envelope(value: Any, config: Mapping[str, Any]) -> Any:
    if config:
        raise Pass214OracleError("PASS214_ITERATION3_ENVELOPE_CONFIG_FORBIDDEN")
    encoded = canonical_json(value).encode("utf-8")
    return {"canonical_json": encoded.decode("utf-8"), "sha256": sha256(encoded).hexdigest()}


def _handler_sha256_canonical(value: Any, config: Mapping[str, Any]) -> Any:
    if config:
        raise Pass214OracleError("PASS214_ITERATION3_SHA256_CONFIG_FORBIDDEN")
    return sha256(canonical_json(value).encode("utf-8")).hexdigest()


_HANDLERS: Mapping[str, Callable[[Any, Mapping[str, Any]], Any]] = {
    "identity": _handler_identity,
    "canonical_roundtrip": _handler_canonical_roundtrip,
    "positional_to_named": _handler_positional_to_named,
    "key_rename": _handler_key_rename,
    "field_projection": _handler_field_projection,
    "canonical_bytes_envelope": _handler_canonical_bytes_envelope,
    "sha256_canonical": _handler_sha256_canonical,
}


def execute_handler(spec: Mapping[str, Any], value: Any) -> Any:
    handler_id = spec.get("handler_id")
    if handler_id not in _HANDLERS:
        raise Pass214OracleError("PASS214_ITERATION3_HANDLER_UNRESOLVED")
    config = spec.get("config", {})
    if not isinstance(config, dict):
        raise Pass214OracleError("PASS214_ITERATION3_HANDLER_CONFIG_INVALID")
    return _HANDLERS[str(handler_id)](_deep_copy(value), config)


def create_pass213_admission_receipt(
    *,
    workload_id: str,
    input_root_hash216: str,
    trusted_timestamp_anchor_root_hash216: str,
    moving_tensor_root_hash216: str,
    native_dispatch_receipt_root_hash216: str,
    prior_admission_root_hash216: str = ZERO_HASH216,
) -> dict[str, Any]:
    body = {
        "schema": ADMISSION_SCHEMA,
        "pass213_foundation": PASS213_FOUNDATION,
        "workload_id": _require_text(workload_id, "PASS214_ITERATION3_WORKLOAD_ID_INVALID"),
        "input_root_hash216": _require_hash216(input_root_hash216, "PASS214_ITERATION3_INPUT_ROOT_INVALID"),
        "trusted_timestamp_anchor_root_hash216": _require_hash216(
            trusted_timestamp_anchor_root_hash216, "PASS214_ITERATION3_TIMESTAMP_ROOT_INVALID"
        ),
        "moving_tensor_root_hash216": _require_hash216(
            moving_tensor_root_hash216, "PASS214_ITERATION3_TENSOR_ROOT_INVALID"
        ),
        "native_dispatch_receipt_root_hash216": _require_hash216(
            native_dispatch_receipt_root_hash216, "PASS214_ITERATION3_DISPATCH_ROOT_INVALID"
        ),
        "prior_admission_root_hash216": _require_hash216(
            prior_admission_root_hash216, "PASS214_ITERATION3_PRIOR_ADMISSION_ROOT_INVALID"
        ),
        "admitted": True,
        "authority_bindings": PASS213_AUTHORITY_BINDINGS,
    }
    return {**body, "admission_receipt_root_hash216": hash216("pass214-iteration3-pass213-admission", body)}


def validate_pass213_admission_receipt(receipt: Mapping[str, Any], *, workload_id: str, input_root_hash216: str) -> None:
    body = {key: value for key, value in receipt.items() if key != "admission_receipt_root_hash216"}
    if body.get("schema") != ADMISSION_SCHEMA:
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_SCHEMA_INVALID")
    if body.get("pass213_foundation") != PASS213_FOUNDATION:
        raise Pass214OracleError("PASS214_ITERATION3_PASS213_FOUNDATION_MISMATCH")
    if body.get("workload_id") != workload_id or body.get("input_root_hash216") != input_root_hash216:
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_BINDING_MISMATCH")
    if body.get("admitted") is not True:
        raise Pass214OracleError("PASS214_ITERATION3_WORKLOAD_NOT_ADMITTED")
    if canonical_json(body.get("authority_bindings", ())) != canonical_json(PASS213_AUTHORITY_BINDINGS):
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_AUTHORITY_BINDINGS_MISMATCH")
    for field in (
        "trusted_timestamp_anchor_root_hash216",
        "moving_tensor_root_hash216",
        "native_dispatch_receipt_root_hash216",
        "prior_admission_root_hash216",
    ):
        _require_hash216(body.get(field), f"PASS214_ITERATION3_ADMISSION_FIELD_INVALID:{field}")
    expected = hash216("pass214-iteration3-pass213-admission", body)
    if not hmac.compare_digest(str(receipt.get("admission_receipt_root_hash216", "")), expected):
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_RECEIPT_ROOT_MISMATCH")


def _validate_manifest(manifest: Mapping[str, Any], iteration2: Mapping[str, Any]) -> None:
    if manifest.get("schema") != MANIFEST_SCHEMA:
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_SCHEMA_INVALID")
    summary = iteration2["iteration2_summary"]
    if manifest.get("contract") != CONTRACT or manifest.get("pass213_foundation") != PASS213_FOUNDATION:
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_AUTHORITY_MISMATCH")
    if manifest.get("predecessor_iteration2_semantic_root_hash216") != summary["roots"]["iteration2_semantic_root_hash216"]:
        raise Pass214OracleError("PASS214_ITERATION3_PREDECESSOR_ROOT_MISMATCH")
    if manifest.get("source_commit") != summary["source_commit"] or manifest.get("source_tree") != summary["source_tree"]:
        raise Pass214OracleError("PASS214_ITERATION3_SOURCE_BINDING_MISMATCH")
    workloads = manifest.get("workloads")
    if not isinstance(workloads, list) or not workloads:
        raise Pass214OracleError("PASS214_ITERATION3_WORKLOADS_REQUIRED")
    ids = [item.get("workload_id") for item in workloads if isinstance(item, dict)]
    if len(ids) != len(workloads) or len(set(ids)) != len(ids):
        raise Pass214OracleError("PASS214_ITERATION3_WORKLOAD_IDS_INVALID")


def _pair_authorized(workload: Mapping[str, Any], iteration2: Mapping[str, Any]) -> bool:
    pair = {workload.get("source_symbol_hash216"), workload.get("target_symbol_hash216")}
    if None in pair or len(pair) != 2:
        return False
    records = {item["symbol_hash216"] for item in iteration2["callable_conformance_records"]}
    if not pair <= records:
        return False
    for edge in iteration2["compatibility_edges"]:
        if {edge["source_symbol_hash216"], edge["target_symbol_hash216"]} == pair:
            return True
    for conflict in iteration2["authority_conflicts"]:
        if pair <= set(conflict["member_symbol_hash216"]):
            return True
    return False


def _model_binding(workload: Mapping[str, Any], role: str, iteration2: Mapping[str, Any]) -> dict[str, Any]:
    symbol_field = f"{role}_symbol_hash216"
    handler_field = f"{role}_handler"
    symbol_hash = workload.get(symbol_field)
    record = next(
        (item for item in iteration2["callable_conformance_records"] if item.get("symbol_hash216") == symbol_hash),
        None,
    )
    if record is None:
        raise Pass214OracleError(f"PASS214_ITERATION3_MODEL_SYMBOL_UNRESOLVED:{role}")
    implementation_hash = record.get("implementation_hash216", ZERO_HASH216)
    _require_hash216(implementation_hash, f"PASS214_ITERATION3_MODEL_IMPLEMENTATION_ROOT_INVALID:{role}")
    handler = workload.get(handler_field)
    if not isinstance(handler, dict):
        raise Pass214OracleError(f"PASS214_ITERATION3_MODEL_HANDLER_INVALID:{role}")
    body = {
        "oracle_scope": ORACLE_SCOPE,
        "role": role,
        "symbol_hash216": symbol_hash,
        "implementation_hash216": implementation_hash,
        "handler_spec": handler,
        "binding_class": "EXPLICIT_NON_PROMOTING_ORACLE_MODEL",
        "semantic_fidelity_to_repository_callable_claimed": False,
        "repository_callable_executed": False,
    }
    return {**body, "model_binding_root_hash216": hash216("pass214-iteration3-model-binding", body)}


def _adapter_spec(workload: Mapping[str, Any]) -> Mapping[str, Any] | None:
    adapter = workload.get("target_output_adapter")
    if adapter is None:
        return None
    if not isinstance(adapter, dict) or adapter.get("adapter_class") not in ADAPTER_CLASSES:
        raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_CLASS_INVALID")
    handler_id = adapter.get("handler_id")
    expected_handler = {
        "IDENTITY": "identity",
        "POSITIONAL_TO_NAMED": "positional_to_named",
        "KEY_RENAME": "key_rename",
        "FIELD_PROJECTION": "field_projection",
        "CANONICAL_BYTES_ENVELOPE": "canonical_bytes_envelope",
    }[str(adapter["adapter_class"])]
    if handler_id != expected_handler:
        raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_HANDLER_MISMATCH")
    return adapter


def _oracle_record(
    workload: Mapping[str, Any],
    admission: Mapping[str, Any],
    source_model_binding: Mapping[str, Any],
    target_model_binding: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    workload_id = _require_text(workload.get("workload_id"), "PASS214_ITERATION3_WORKLOAD_ID_INVALID")
    vectors = workload.get("vectors")
    if not isinstance(vectors, list) or not vectors:
        raise Pass214OracleError("PASS214_ITERATION3_VECTORS_REQUIRED")
    input_root = hash216("pass214-iteration3-oracle-inputs", vectors)
    try:
        validate_pass213_admission_receipt(admission, workload_id=workload_id, input_root_hash216=input_root)
    except Pass214OracleError as exc:
        body = {
            "workload_id": workload_id,
            "source_symbol_hash216": workload.get("source_symbol_hash216"),
            "target_symbol_hash216": workload.get("target_symbol_hash216"),
            "oracle_scope": ORACLE_SCOPE,
            "source_model_binding": source_model_binding,
            "target_model_binding": target_model_binding,
            "oracle_state": "ORACLE_INADMISSIBLE",
            "vector_count": len(vectors),
            "equal_vector_count": 0,
            "divergent_vector_count": 0,
            "input_root_hash216": input_root,
            "admission_receipt_root_hash216": admission.get("admission_receipt_root_hash216", ZERO_HASH216),
            "detail": str(exc),
            "runtime_verified": False,
        }
        return {**body, "oracle_record_root_hash216": hash216("pass214-iteration3-oracle-record", body)}, None

    try:
        adapter = _adapter_spec(workload)
        vector_records: list[dict[str, Any]] = []
        for index, vector in enumerate(vectors):
            if not isinstance(vector, dict) or "input" not in vector:
                raise Pass214OracleError("PASS214_ITERATION3_VECTOR_INVALID")
            source_output = execute_handler(workload["source_handler"], vector["input"])
            target_raw = execute_handler(workload["target_handler"], vector["input"])
            target_output = execute_handler(adapter, target_raw) if adapter is not None else target_raw
            source_root = hash216("pass214-iteration3-output-identity", source_output)
            target_root = hash216("pass214-iteration3-output-identity", target_output)
            vector_body = {
                "index": index,
                "input_root_hash216": hash216("pass214-iteration3-vector-input", vector["input"]),
                "source_output_root_hash216": source_root,
                "target_output_root_hash216": target_root,
                "equal": hmac.compare_digest(source_root, target_root),
            }
            vector_records.append({**vector_body, "vector_record_root_hash216": hash216("pass214-iteration3-vector-record", vector_body)})
        equal_count = sum(item["equal"] for item in vector_records)
        state = "ORACLE_EQUIVALENCE_VERIFIED" if equal_count == len(vector_records) else "ORACLE_DIVERGENCE"
        body = {
            "workload_id": workload_id,
            "source_symbol_hash216": workload["source_symbol_hash216"],
            "target_symbol_hash216": workload["target_symbol_hash216"],
            "oracle_scope": ORACLE_SCOPE,
            "source_model_binding": source_model_binding,
            "target_model_binding": target_model_binding,
            "source_handler": workload["source_handler"],
            "target_handler": workload["target_handler"],
            "target_output_adapter": adapter,
            "oracle_state": state,
            "vector_count": len(vector_records),
            "equal_vector_count": equal_count,
            "divergent_vector_count": len(vector_records) - equal_count,
            "input_root_hash216": input_root,
            "vector_records_root_hash216": hash216("pass214-iteration3-vector-records", vector_records),
            "admission_receipt_root_hash216": admission["admission_receipt_root_hash216"],
            "runtime_verified": True,
        }
        record = {**body, "oracle_record_root_hash216": hash216("pass214-iteration3-oracle-record", body)}
        proof = None
        if adapter is not None and state == "ORACLE_EQUIVALENCE_VERIFIED":
            proof_body = {
                "schema": "HHS_PASS_214_ITERATION_3_IDENTITY_PRESERVING_ADAPTER_PROOF_V1",
                "workload_id": workload_id,
                "source_symbol_hash216": workload["source_symbol_hash216"],
                "target_symbol_hash216": workload["target_symbol_hash216"],
                "oracle_scope": ORACLE_SCOPE,
                "source_model_binding_root_hash216": source_model_binding["model_binding_root_hash216"],
                "target_model_binding_root_hash216": target_model_binding["model_binding_root_hash216"],
                "adapter": adapter,
                "input_root_hash216": input_root,
                "source_output_root_hash216": hash216(
                    "pass214-iteration3-source-output-roots",
                    [item["source_output_root_hash216"] for item in vector_records],
                ),
                "adapted_target_output_root_hash216": hash216(
                    "pass214-iteration3-target-output-roots",
                    [item["target_output_root_hash216"] for item in vector_records],
                ),
                "pass213_admission_receipt_root_hash216": admission["admission_receipt_root_hash216"],
                "deterministic_replay_equal": True,
                "authority_promotion_authorized": False,
            }
            proof = {**proof_body, "adapter_proof_root_hash216": hash216("pass214-iteration3-adapter-proof", proof_body)}
        return record, proof
    except (KeyError, TypeError, Pass214OracleError) as exc:
        body = {
            "workload_id": workload_id,
            "source_symbol_hash216": workload.get("source_symbol_hash216"),
            "target_symbol_hash216": workload.get("target_symbol_hash216"),
            "oracle_scope": ORACLE_SCOPE,
            "source_model_binding": source_model_binding,
            "target_model_binding": target_model_binding,
            "oracle_state": "ORACLE_HANDLER_UNRESOLVED",
            "vector_count": len(vectors),
            "equal_vector_count": 0,
            "divergent_vector_count": 0,
            "input_root_hash216": input_root,
            "admission_receipt_root_hash216": admission.get("admission_receipt_root_hash216", ZERO_HASH216),
            "detail": str(exc),
            "runtime_verified": False,
        }
        return {**body, "oracle_record_root_hash216": hash216("pass214-iteration3-oracle-record", body)}, None


def _adjudication(record: Mapping[str, Any], adapter_proof: Mapping[str, Any] | None) -> dict[str, Any]:
    state = record["oracle_state"]
    if state == "ORACLE_EQUIVALENCE_VERIFIED" and adapter_proof is not None:
        status = "IDENTITY_PRESERVING_ADAPTER_MODEL_VERIFIED"
        target_disposition = "CALLABLE_ORACLE_REQUIRED_BEFORE_ADAPTER_INTEGRATION"
    elif state == "ORACLE_EQUIVALENCE_VERIFIED":
        status = "REFERENCE_MODEL_BEHAVIOR_RETAINED"
        target_disposition = "CALLABLE_ORACLE_REQUIRED_BEFORE_FALLBACK_DESIGNATION"
    elif state == "ORACLE_DIVERGENCE":
        status = "DIVERGENT_ORACLE_MODEL_RECORDED"
        target_disposition = "CALLABLE_ORACLE_REQUIRED_BEFORE_QUARANTINE"
    else:
        status = "UNRESOLVED"
        target_disposition = "NO_AUTHORITY_CHANGE"
    body = {
        "workload_id": record["workload_id"],
        "source_symbol_hash216": record.get("source_symbol_hash216"),
        "target_symbol_hash216": record.get("target_symbol_hash216"),
        "oracle_record_root_hash216": record["oracle_record_root_hash216"],
        "adjudication_status": status,
        "adjudication_scope": ORACLE_SCOPE,
        "reference_authority_disposition": "UNCHANGED",
        "target_authority_disposition": target_disposition,
        "adapter_proof_root_hash216": adapter_proof["adapter_proof_root_hash216"] if adapter_proof else None,
        "automatic_merge_authorized": False,
        "repository_authority_change_authorized": False,
        "callable_oracle_required_for_authority_change": True,
        "terminal_authority_minted": False,
    }
    return {**body, "adjudication_root_hash216": hash216("pass214-iteration3-authority-adjudication", body)}


def build_oracle_adjudication_bundle(
    iteration2_directory: Path | str,
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    try:
        iteration2 = load_and_validate_callable_conformance_outputs(iteration2_directory)
    except Pass214ConformanceError as exc:
        raise Pass214OracleError(str(exc)) from exc
    _validate_manifest(manifest, iteration2)
    admissions = manifest.get("admission_receipts")
    if not isinstance(admissions, list):
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_RECEIPTS_REQUIRED")
    admission_ids = [item.get("workload_id") for item in admissions if isinstance(item, dict)]
    if len(admission_ids) != len(admissions) or len(set(admission_ids)) != len(admission_ids):
        raise Pass214OracleError("PASS214_ITERATION3_ADMISSION_RECEIPT_IDS_INVALID")
    admission_by_id = {item["workload_id"]: item for item in admissions}
    records: list[dict[str, Any]] = []
    proofs: list[dict[str, Any]] = []
    adjudications: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    for workload in sorted(manifest["workloads"], key=lambda item: item["workload_id"]):
        if not _pair_authorized(workload, iteration2):
            raise Pass214OracleError(f"PASS214_ITERATION3_PAIR_NOT_IN_ITERATION2_GRAPH:{workload['workload_id']}")
        admission = admission_by_id.get(workload["workload_id"], {})
        source_model_binding = _model_binding(workload, "source", iteration2)
        target_model_binding = _model_binding(workload, "target", iteration2)
        record, proof = _oracle_record(workload, admission, source_model_binding, target_model_binding)
        records.append(record)
        if proof is not None:
            proofs.append(proof)
        adjudication = _adjudication(record, proof)
        adjudications.append(adjudication)
        edge_body = {
            "source_symbol_hash216": record.get("source_symbol_hash216"),
            "target_symbol_hash216": record.get("target_symbol_hash216"),
            "relation_class": record["oracle_state"],
            "oracle_record_root_hash216": record["oracle_record_root_hash216"],
            "adjudication_root_hash216": adjudication["adjudication_root_hash216"],
            "runtime_verified": record["runtime_verified"],
        }
        edges.append({**edge_body, "oracle_edge_root_hash216": hash216("pass214-iteration3-oracle-edge", edge_body)})
    state_counts = Counter(item["oracle_state"] for item in records)
    adjudication_counts = Counter(item["adjudication_status"] for item in adjudications)
    roots = {
        "oracle_manifest_root_hash216": hash216("pass214-iteration3-oracle-manifest", manifest),
        "oracle_record_root_hash216": hash216("pass214-iteration3-oracle-records", records),
        "authority_adjudication_root_hash216": hash216("pass214-iteration3-authority-adjudications", adjudications),
        "integration_adapter_root_hash216": hash216("pass214-iteration3-integration-adapters", proofs),
        "oracle_compatibility_edge_root_hash216": hash216("pass214-iteration3-oracle-compatibility-edges", edges),
    }
    predecessor = iteration2["iteration2_summary"]
    semantic = {
        "contract": CONTRACT,
        "iteration": ITERATION,
        "source_commit": predecessor["source_commit"],
        "source_tree": predecessor["source_tree"],
        "pass213_foundation": PASS213_FOUNDATION,
        "predecessor_iteration2_semantic_root_hash216": predecessor["roots"]["iteration2_semantic_root_hash216"],
        "workload_count": len(records),
        "oracle_state_counts": dict(sorted(state_counts.items())),
        "adjudication_counts": dict(sorted(adjudication_counts.items())),
        "adapter_proof_count": len(proofs),
        "runtime_verified_edge_count": sum(item["runtime_verified"] for item in edges),
        "roots": roots,
    }
    summary_body = {
        "schema": "HHS_PASS_214_ITERATION_3_ORACLE_ADJUDICATION_SUMMARY_V1",
        "contract": CONTRACT,
        "pass": 214,
        "iteration": ITERATION,
        "classification": RUNTIME_CLASSIFICATION,
        "source_commit": predecessor["source_commit"],
        "source_tree": predecessor["source_tree"],
        "pass213_foundation": PASS213_FOUNDATION,
        "pass213_authority_bindings": PASS213_AUTHORITY_BINDINGS,
        "oracle_scope": ORACLE_SCOPE,
        "predecessor_iteration2_semantic_root_hash216": predecessor["roots"]["iteration2_semantic_root_hash216"],
        "workload_count": semantic["workload_count"],
        "oracle_state_counts": semantic["oracle_state_counts"],
        "adjudication_counts": semantic["adjudication_counts"],
        "adapter_proof_count": semantic["adapter_proof_count"],
        "runtime_verified_edge_count": semantic["runtime_verified_edge_count"],
        "roots": {**roots, "iteration3_semantic_root_hash216": hash216("pass214-iteration3-semantic-root", semantic)},
        "claim_boundary": {
            "iteration2_static_graph_inherited_and_verified": True,
            "only_explicit_builtin_oracle_handlers_executed": True,
            "candidate_repository_modules_imported": False,
            "pass213_admission_required_per_workload": True,
            "oracle_pilot_complete_for_manifested_workloads": True,
            "manifested_model_adjudication_complete": True,
            "repository_callable_semantic_fidelity_claimed": False,
            "repository_callables_executed": False,
            "repository_authority_changed": False,
            "repository_wide_oracle_coverage_complete": False,
            "all_authority_conflicts_resolved": False,
            "integration_adapters_complete": False,
            "compound_benchmark_complete": False,
            "pass214_terminal_roots_minted": False,
            "pass215_benchmark_authorized": False,
        },
    }
    summary = {**summary_body, "receipt_hash72": hash72("pass214.iteration3.oracle.adjudication", summary_body)}
    return {
        "oracle_workload_manifest": _deep_copy(manifest),
        "oracle_records": records,
        "authority_adjudications": adjudications,
        "integration_adapters": proofs,
        "oracle_compatibility_edges": edges,
        "iteration3_summary": summary,
    }


_OUTPUT_NAMES = (
    "oracle_workload_manifest",
    "oracle_records",
    "authority_adjudications",
    "integration_adapters",
    "oracle_compatibility_edges",
    "iteration3_summary",
)


def write_oracle_adjudication_outputs(result: Mapping[str, Any], output_directory: Path | str) -> dict[str, Path]:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}
    for name in _OUTPUT_NAMES:
        path = output / f"{name}.json"
        path.write_text(canonical_json(result[name]) + "\n", encoding="utf-8")
        paths[name] = path
    return paths


def _validate_item_root(item: Mapping[str, Any], root_field: str, domain: str) -> None:
    body = {key: value for key, value in item.items() if key != root_field}
    expected = hash216(domain, body)
    if not hmac.compare_digest(str(item.get(root_field, "")), expected):
        raise Pass214OracleError(f"PASS214_ITERATION3_ITEM_ROOT_MISMATCH:{root_field}")


def validate_oracle_adjudication_bundle(bundle: Mapping[str, Any]) -> None:
    missing = [name for name in _OUTPUT_NAMES if name not in bundle]
    if missing:
        raise Pass214OracleError("PASS214_ITERATION3_OUTPUTS_MISSING:" + ",".join(missing))
    summary = bundle["iteration3_summary"]
    if summary.get("schema") != "HHS_PASS_214_ITERATION_3_ORACLE_ADJUDICATION_SUMMARY_V1":
        raise Pass214OracleError("PASS214_ITERATION3_SUMMARY_SCHEMA_INVALID")
    if summary.get("contract") != CONTRACT or summary.get("pass") != 214 or summary.get("iteration") != ITERATION:
        raise Pass214OracleError("PASS214_ITERATION3_SUMMARY_IDENTITY_INVALID")
    if summary.get("classification") != RUNTIME_CLASSIFICATION:
        raise Pass214OracleError("PASS214_ITERATION3_CLASSIFICATION_INVALID")
    if summary.get("pass213_foundation") != PASS213_FOUNDATION:
        raise Pass214OracleError("PASS214_ITERATION3_SUMMARY_PASS213_MISMATCH")
    if summary.get("oracle_scope") != ORACLE_SCOPE:
        raise Pass214OracleError("PASS214_ITERATION3_ORACLE_SCOPE_INVALID")
    if canonical_json(summary.get("pass213_authority_bindings", ())) != canonical_json(PASS213_AUTHORITY_BINDINGS):
        raise Pass214OracleError("PASS214_ITERATION3_SUMMARY_AUTHORITY_BINDINGS_MISMATCH")

    records = bundle["oracle_records"]
    adjudications = bundle["authority_adjudications"]
    adapters = bundle["integration_adapters"]
    edges = bundle["oracle_compatibility_edges"]
    for name, value in (
        ("oracle_records", records),
        ("authority_adjudications", adjudications),
        ("integration_adapters", adapters),
        ("oracle_compatibility_edges", edges),
    ):
        if not isinstance(value, list):
            raise Pass214OracleError(f"PASS214_ITERATION3_OUTPUT_NOT_LIST:{name}")

    manifest = bundle["oracle_workload_manifest"]
    if manifest.get("schema") != MANIFEST_SCHEMA or manifest.get("contract") != CONTRACT:
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_IDENTITY_INVALID")
    if manifest.get("pass213_foundation") != PASS213_FOUNDATION:
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_PASS213_MISMATCH")
    workloads = manifest.get("workloads")
    admissions = manifest.get("admission_receipts")
    if not isinstance(workloads, list) or not isinstance(admissions, list):
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_COLLECTIONS_INVALID")
    workload_by_id = {item.get("workload_id"): item for item in workloads if isinstance(item, dict)}
    admission_by_id = {item.get("workload_id"): item for item in admissions if isinstance(item, dict)}
    if len(workload_by_id) != len(workloads) or len(admission_by_id) != len(admissions):
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_IDS_INVALID")
    if set(workload_by_id) != set(admission_by_id):
        raise Pass214OracleError("PASS214_ITERATION3_MANIFEST_ADMISSION_COVERAGE_INVALID")
    for workload_id, workload in workload_by_id.items():
        input_root = hash216("pass214-iteration3-oracle-inputs", workload.get("vectors"))
        validate_pass213_admission_receipt(
            admission_by_id[workload_id], workload_id=workload_id, input_root_hash216=input_root
        )

    for record in records:
        _validate_item_root(record, "oracle_record_root_hash216", "pass214-iteration3-oracle-record")
        for role in ("source", "target"):
            binding = record.get(f"{role}_model_binding")
            if not isinstance(binding, dict):
                raise Pass214OracleError(f"PASS214_ITERATION3_MODEL_BINDING_MISSING:{role}")
            _validate_item_root(binding, "model_binding_root_hash216", "pass214-iteration3-model-binding")
            if binding.get("oracle_scope") != ORACLE_SCOPE:
                raise Pass214OracleError(f"PASS214_ITERATION3_MODEL_BINDING_SCOPE_INVALID:{role}")
            if binding.get("semantic_fidelity_to_repository_callable_claimed") is not False:
                raise Pass214OracleError(f"PASS214_ITERATION3_MODEL_FIDELITY_OVERCLAIM:{role}")
            if binding.get("repository_callable_executed") is not False:
                raise Pass214OracleError(f"PASS214_ITERATION3_REPOSITORY_CALLABLE_EXECUTION_OVERCLAIM:{role}")
    for proof in adapters:
        _validate_item_root(proof, "adapter_proof_root_hash216", "pass214-iteration3-adapter-proof")
        if proof.get("authority_promotion_authorized") is not False or proof.get("deterministic_replay_equal") is not True:
            raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_PROOF_AUTHORITY_INVALID")
    for adjudication in adjudications:
        _validate_item_root(adjudication, "adjudication_root_hash216", "pass214-iteration3-authority-adjudication")
        if (
            adjudication.get("automatic_merge_authorized") is not False
            or adjudication.get("repository_authority_change_authorized") is not False
            or adjudication.get("callable_oracle_required_for_authority_change") is not True
            or adjudication.get("terminal_authority_minted") is not False
        ):
            raise Pass214OracleError("PASS214_ITERATION3_AUTOMATIC_AUTHORITY_MERGE_FORBIDDEN")
    for edge in edges:
        _validate_item_root(edge, "oracle_edge_root_hash216", "pass214-iteration3-oracle-edge")

    record_by_root = {item["oracle_record_root_hash216"]: item for item in records}
    adjudication_by_root = {item["adjudication_root_hash216"]: item for item in adjudications}
    proof_by_root = {item["adapter_proof_root_hash216"]: item for item in adapters}
    proof_roots = set(proof_by_root)
    if len(record_by_root) != len(records) or len(adjudication_by_root) != len(adjudications) or len(proof_roots) != len(adapters):
        raise Pass214OracleError("PASS214_ITERATION3_DUPLICATE_ITEM_ROOT")
    for adjudication in adjudications:
        if adjudication.get("oracle_record_root_hash216") not in record_by_root:
            raise Pass214OracleError("PASS214_ITERATION3_ADJUDICATION_RECORD_LINK_INVALID")
        proof_root = adjudication.get("adapter_proof_root_hash216")
        if proof_root is not None and proof_root not in proof_roots:
            raise Pass214OracleError("PASS214_ITERATION3_ADJUDICATION_ADAPTER_LINK_INVALID")
        record = record_by_root[adjudication["oracle_record_root_hash216"]]
        proof = proof_by_root.get(proof_root)
        expected_adjudication = _adjudication(record, proof)
        if canonical_json(adjudication) != canonical_json(expected_adjudication):
            raise Pass214OracleError("PASS214_ITERATION3_ADJUDICATION_REPLAY_MISMATCH")
        if proof is not None:
            if proof.get("source_model_binding_root_hash216") != record["source_model_binding"]["model_binding_root_hash216"]:
                raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_SOURCE_BINDING_MISMATCH")
            if proof.get("target_model_binding_root_hash216") != record["target_model_binding"]["model_binding_root_hash216"]:
                raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_TARGET_BINDING_MISMATCH")
    for edge in edges:
        if edge.get("oracle_record_root_hash216") not in record_by_root:
            raise Pass214OracleError("PASS214_ITERATION3_EDGE_RECORD_LINK_INVALID")
        if edge.get("adjudication_root_hash216") not in adjudication_by_root:
            raise Pass214OracleError("PASS214_ITERATION3_EDGE_ADJUDICATION_LINK_INVALID")
        record = record_by_root[edge["oracle_record_root_hash216"]]
        if edge.get("relation_class") != record.get("oracle_state"):
            raise Pass214OracleError("PASS214_ITERATION3_EDGE_RELATION_MISMATCH")
        if edge.get("runtime_verified") is not record.get("runtime_verified"):
            raise Pass214OracleError("PASS214_ITERATION3_EDGE_RUNTIME_STATE_MISMATCH")
        if {edge.get("source_symbol_hash216"), edge.get("target_symbol_hash216")} != {
            record.get("source_symbol_hash216"), record.get("target_symbol_hash216")
        }:
            raise Pass214OracleError("PASS214_ITERATION3_EDGE_SYMBOL_LINK_MISMATCH")

    roots = summary.get("roots", {})
    expected_roots = {
        "oracle_manifest_root_hash216": hash216("pass214-iteration3-oracle-manifest", bundle["oracle_workload_manifest"]),
        "oracle_record_root_hash216": hash216("pass214-iteration3-oracle-records", records),
        "authority_adjudication_root_hash216": hash216("pass214-iteration3-authority-adjudications", adjudications),
        "integration_adapter_root_hash216": hash216("pass214-iteration3-integration-adapters", adapters),
        "oracle_compatibility_edge_root_hash216": hash216("pass214-iteration3-oracle-compatibility-edges", edges),
    }
    for field, value in expected_roots.items():
        if roots.get(field) != value:
            raise Pass214OracleError(f"PASS214_ITERATION3_OUTPUT_ROOT_MISMATCH:{field}")

    state_counts = dict(sorted(Counter(item["oracle_state"] for item in records).items()))
    adjudication_counts = dict(sorted(Counter(item["adjudication_status"] for item in adjudications).items()))
    runtime_verified_edge_count = sum(item.get("runtime_verified") is True for item in edges)
    if summary.get("workload_count") != len(records):
        raise Pass214OracleError("PASS214_ITERATION3_WORKLOAD_COUNT_MISMATCH")
    if summary.get("oracle_state_counts") != state_counts:
        raise Pass214OracleError("PASS214_ITERATION3_ORACLE_STATE_COUNTS_MISMATCH")
    if summary.get("adjudication_counts") != adjudication_counts:
        raise Pass214OracleError("PASS214_ITERATION3_ADJUDICATION_COUNTS_MISMATCH")
    if summary.get("adapter_proof_count") != len(adapters):
        raise Pass214OracleError("PASS214_ITERATION3_ADAPTER_COUNT_MISMATCH")
    if summary.get("runtime_verified_edge_count") != runtime_verified_edge_count:
        raise Pass214OracleError("PASS214_ITERATION3_RUNTIME_VERIFIED_EDGE_COUNT_MISMATCH")

    semantic = {
        "contract": CONTRACT,
        "iteration": ITERATION,
        "source_commit": summary["source_commit"],
        "source_tree": summary["source_tree"],
        "pass213_foundation": PASS213_FOUNDATION,
        "predecessor_iteration2_semantic_root_hash216": summary["predecessor_iteration2_semantic_root_hash216"],
        "workload_count": summary["workload_count"],
        "oracle_state_counts": summary["oracle_state_counts"],
        "adjudication_counts": summary["adjudication_counts"],
        "adapter_proof_count": summary["adapter_proof_count"],
        "runtime_verified_edge_count": summary["runtime_verified_edge_count"],
        "roots": expected_roots,
    }
    expected_semantic_root = hash216("pass214-iteration3-semantic-root", semantic)
    if roots.get("iteration3_semantic_root_hash216") != expected_semantic_root:
        raise Pass214OracleError("PASS214_ITERATION3_SEMANTIC_ROOT_MISMATCH")

    expected_claim_boundary = {
        "iteration2_static_graph_inherited_and_verified": True,
        "only_explicit_builtin_oracle_handlers_executed": True,
        "candidate_repository_modules_imported": False,
        "pass213_admission_required_per_workload": True,
        "oracle_pilot_complete_for_manifested_workloads": True,
        "manifested_model_adjudication_complete": True,
        "repository_callable_semantic_fidelity_claimed": False,
        "repository_callables_executed": False,
        "repository_authority_changed": False,
        "repository_wide_oracle_coverage_complete": False,
        "all_authority_conflicts_resolved": False,
        "integration_adapters_complete": False,
        "compound_benchmark_complete": False,
        "pass214_terminal_roots_minted": False,
        "pass215_benchmark_authorized": False,
    }
    if summary.get("claim_boundary") != expected_claim_boundary:
        raise Pass214OracleError("PASS214_ITERATION3_CLAIM_BOUNDARY_INVALID")
    summary_body = {key: value for key, value in summary.items() if key != "receipt_hash72"}
    expected_receipt = hash72("pass214.iteration3.oracle.adjudication", summary_body)
    if not hmac.compare_digest(str(summary.get("receipt_hash72", "")), expected_receipt):
        raise Pass214OracleError("PASS214_ITERATION3_RECEIPT_HASH72_MISMATCH")


def load_and_validate_oracle_adjudication_outputs(output_directory: Path | str) -> dict[str, Any]:
    output = Path(output_directory)
    payloads = {name: json.loads((output / f"{name}.json").read_text(encoding="utf-8")) for name in _OUTPUT_NAMES}
    validate_oracle_adjudication_bundle(payloads)
    return payloads
