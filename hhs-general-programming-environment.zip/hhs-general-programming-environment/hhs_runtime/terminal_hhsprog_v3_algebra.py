"""
terminal_hhsprog_v3_algebra.py

Native algebra-syntax terminal for the HARMONICODE General Programming Environment.

Purpose
-------
Make the custom HHS algebra the primary syntax instead of command words.

Supported algebra syntax
------------------------
Assignments:
    A := 2
    B := 3
    R := A + B

Arithmetic:
    A + B
    A - B
    A * B
    A / B
    A^2
    A²

Canonical symbols:
    a²
    b²
    c²
    xy
    yx
    x
    y
    z
    w

Invariant / projection assertions:
    c² - a² == b²
    a² == c² - b²
    a² == b²/2 == c²-b²

List/vector helpers remain available:
    sort [3,1,2]
    search [1,3,5,7] 5

Maintenance commands:
    help
    vars
    status
    chain
    receipts
    save file.hhsrun
    load file.hhsrun
    quit

Execution model
---------------
Algebra source -> AST-ish compiled op sequence -> AuditedRunner -> drift gate
-> Hash72 receipt -> witness.

This file does not replace the locked kernel.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import ast
import json
import re
import shlex
import sys

from hhs_general_runtime_layer_v1 import AuditedRunner, DEFAULT_KERNEL_PATH, canonicalize_for_hash72
from hhs_receipt_replay_verifier_v1 import HHSReceiptReplayVerifierV1
from hhs_program_format_and_cli_v1 import verify_run_file, RUN_RESULT_FORMAT, load_json


TERMINAL_FORMAT = "TERMINAL_HHSPROG_V3_ALGEBRA"


SUPERSCRIPT_TRANSLATION = str.maketrans({
    "⁰": "0",
    "¹": "1",
    "²": "2",
    "³": "3",
    "⁴": "4",
    "⁵": "5",
    "⁶": "6",
    "⁷": "7",
    "⁸": "8",
    "⁹": "9",
})


DEFAULT_SYMBOLS: Dict[str, Any] = {
    "x": Fraction(1, 1),
    "y": Fraction(-1, 1),
    "xy": Fraction(1, 1),
    "yx": Fraction(-1, 1),
    "a²": Fraction(1, 1),
    "b²": Fraction(2, 1),
    "c²": Fraction(3, 1),
    "z": Fraction(1, 1),
    "w": Fraction(-1, 1),
    "zw": Fraction(1, 1),
    "wz": Fraction(-1, 1),
}


@dataclass
class AlgebraEvalResult:
    ok: bool
    source: str
    value: Any = None
    normalized_source: str = ""
    receipts: List[Dict[str, Any]] = None
    witness: Dict[str, Any] = None
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AlgebraSyntaxError(RuntimeError):
    pass


class HHSAlgebraCompilerV1:
    """
    Small audited algebra compiler.

    It intentionally supports a restricted expression language so arbitrary Python
    cannot execute through eval/exec.
    """

    def __init__(self, runner: AuditedRunner, symbols: Optional[Dict[str, Any]] = None):
        self.runner = runner
        self.symbols: Dict[str, Any] = dict(DEFAULT_SYMBOLS)
        if symbols:
            self.symbols.update(symbols)

    # ------------------------------------------------------------------
    # Normalization
    # ------------------------------------------------------------------

    @staticmethod
    def normalize_source(source: str) -> str:
        s = source.strip()
        s = s.replace(" ", "")
        s = s.translate(SUPERSCRIPT_TRANSLATION)
        # Normalize common algebraic glyphs.
        s = s.replace("−", "-")
        s = s.replace("÷", "/")
        s = s.replace("×", "*")
        return s

    @staticmethod
    def external_symbol_name(name: str) -> str:
        # Internal parser names cannot contain superscript.
        if name == "a2":
            return "a²"
        if name == "b2":
            return "b²"
        if name == "c2":
            return "c²"
        return name

    @staticmethod
    def internalize_symbols(s: str) -> str:
        # Must replace longer canonical tokens before single-letter tokens.
        s = s.replace("a2", "a2")
        s = s.replace("b2", "b2")
        s = s.replace("c2", "c2")
        return s

    @staticmethod
    def restore_power_syntax(s: str) -> str:
        # HHS uses ^, Python AST uses **.
        return s.replace("^", "**")

    def parser_source(self, source: str) -> str:
        s = self.normalize_source(source)
        s = self.restore_power_syntax(s)
        return s

    # ------------------------------------------------------------------
    # Values
    # ------------------------------------------------------------------

    def resolve_name(self, name: str) -> Any:
        ext = self.external_symbol_name(name)
        if ext not in self.symbols:
            raise AlgebraSyntaxError(f"unknown symbol: {ext}")
        return self.symbols[ext]

    @staticmethod
    def to_fraction(value: Any) -> Fraction:
        if isinstance(value, Fraction):
            return value
        if isinstance(value, int):
            return Fraction(value, 1)
        if isinstance(value, str):
            if "/" in value:
                a, b = value.split("/", 1)
                return Fraction(int(a), int(b))
            return Fraction(value)
        if isinstance(value, dict) and "__fraction__" in value:
            n, d = value["__fraction__"]
            return Fraction(n, d)
        return Fraction(value)

    @staticmethod
    def canonical_value(value: Any) -> Any:
        if isinstance(value, Fraction):
            if value.denominator == 1:
                return value.numerator
            return {"__fraction__": [value.numerator, value.denominator]}
        if isinstance(value, list):
            return [HHSAlgebraCompilerV1.canonical_value(v) for v in value]
        if isinstance(value, dict):
            return {k: HHSAlgebraCompilerV1.canonical_value(v) for k, v in value.items()}
        return value

    # ------------------------------------------------------------------
    # Audited operation execution
    # ------------------------------------------------------------------

    def audited_binary(self, op: str, left: Any, right: Any, *, source: str) -> Fraction:
        op_map = {
            "ADD": "ADD",
            "SUB": "SUB",
            "MUL": "MUL",
            "DIV": "DIV",
        }
        out = self.runner.execute(
            op_map[op],
            left,
            right,
            input_payload={
                "terminal": TERMINAL_FORMAT,
                "algebra_source": source,
                "operation": op,
                "left": canonicalize_for_hash72(left),
                "right": canonicalize_for_hash72(right),
            },
        )
        if not out.get("ok"):
            raise AlgebraSyntaxError(f"audited operation failed: {op}: {out.get('reason', out)}")
        return self.to_fraction(out["result"])

    def audited_power(self, base: Any, exp: int, *, source: str) -> Fraction:
        if exp < 0:
            # rational negative power path
            b = self.to_fraction(base)
            if b == 0:
                raise ZeroDivisionError("negative power of zero")
            value = Fraction(1, 1) / (b ** abs(exp))
        else:
            value = self.to_fraction(base) ** exp

        # Commit the power as a MUL chain witness by auditing the final value.
        out = self.runner.execute(
            "SUM",
            [value],
            input_payload={
                "terminal": TERMINAL_FORMAT,
                "algebra_source": source,
                "operation": "POW",
                "base": canonicalize_for_hash72(base),
                "exp": exp,
                "value": value,
            },
        )
        if not out.get("ok"):
            raise AlgebraSyntaxError(f"audited power failed: {out.get('reason', out)}")
        return value

    # ------------------------------------------------------------------
    # AST evaluator
    # ------------------------------------------------------------------

    def eval_expr(self, expr: str, *, source: Optional[str] = None) -> Fraction:
        source = source or expr
        parser_expr = self.parser_source(expr)
        try:
            tree = ast.parse(parser_expr, mode="eval")
        except SyntaxError as exc:
            raise AlgebraSyntaxError(f"parse error: {exc}") from exc
        return self.eval_node(tree.body, source=source)

    def eval_node(self, node: ast.AST, *, source: str) -> Fraction:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float, str)):
                return self.to_fraction(str(node.value))
            raise AlgebraSyntaxError(f"unsupported constant: {node.value!r}")

        if isinstance(node, ast.Name):
            return self.to_fraction(self.resolve_name(node.id))

        if isinstance(node, ast.UnaryOp):
            val = self.eval_node(node.operand, source=source)
            if isinstance(node.op, ast.USub):
                return -val
            if isinstance(node.op, ast.UAdd):
                return val
            raise AlgebraSyntaxError("unsupported unary operator")

        if isinstance(node, ast.BinOp):
            left = self.eval_node(node.left, source=source)
            right = self.eval_node(node.right, source=source)

            if isinstance(node.op, ast.Add):
                return self.audited_binary("ADD", left, right, source=source)
            if isinstance(node.op, ast.Sub):
                return self.audited_binary("SUB", left, right, source=source)
            if isinstance(node.op, ast.Mult):
                return self.audited_binary("MUL", left, right, source=source)
            if isinstance(node.op, ast.Div):
                return self.audited_binary("DIV", left, right, source=source)
            if isinstance(node.op, ast.Pow):
                if right.denominator != 1:
                    raise AlgebraSyntaxError("power exponent must be integer")
                return self.audited_power(left, int(right), source=source)

            raise AlgebraSyntaxError("unsupported binary operator")

        raise AlgebraSyntaxError(f"unsupported AST node: {type(node).__name__}")

    # ------------------------------------------------------------------
    # High-level forms
    # ------------------------------------------------------------------

    def assign(self, lhs: str, rhs: str) -> AlgebraEvalResult:
        lhs_norm = lhs.strip().translate(SUPERSCRIPT_TRANSLATION)
        lhs_ext = self.external_symbol_name(lhs_norm)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*|[abc]²|xy|yx|zw|wz|[xyzw]", lhs_ext):
            return AlgebraEvalResult(
                ok=False,
                source=f"{lhs}:={rhs}",
                error=f"invalid assignment target: {lhs}",
                receipts=[],
                witness={},
            )

        before_tip = self.runner.commitments.tip_hash72
        value = self.eval_expr(rhs, source=f"{lhs_ext}:={rhs}")
        self.symbols[lhs_ext] = value
        after_tip = self.runner.commitments.tip_hash72

        # Commit the assignment itself as a witness using SUM audit.
        out = self.runner.execute(
            "SUM",
            [value],
            input_payload={
                "terminal": TERMINAL_FORMAT,
                "form": "ASSIGN",
                "lhs": lhs_ext,
                "rhs": rhs,
                "value": value,
                "before_tip": before_tip,
            },
        )

        return AlgebraEvalResult(
            ok=bool(out.get("ok")),
            source=f"{lhs_ext}:={rhs}",
            normalized_source=self.parser_source(rhs),
            value=self.canonical_value(value),
            receipts=[out.get("receipt")],
            witness={
                "form": "ASSIGN",
                "lhs": lhs_ext,
                "rhs": rhs,
                "value": self.canonical_value(value),
                "before_tip": before_tip,
                "after_tip": after_tip,
                "assignment_receipt": out.get("receipt"),
            },
            error="" if out.get("ok") else out.get("reason", "assignment audit failed"),
        )

    def equality_chain(self, source: str) -> AlgebraEvalResult:
        parts = [p for p in self.normalize_source(source).split("==") if p]
        if len(parts) < 2:
            raise AlgebraSyntaxError("equality chain requires at least two terms")

        before_count = len(self.runner.commitments.receipts)
        values = []
        for p in parts:
            values.append(self.eval_expr(p, source=source))

        first = values[0]
        equalities = [v == first for v in values]
        ok = all(equalities)

        witness = {
            "form": "EQUALITY_CHAIN",
            "source": source,
            "terms": parts,
            "values": [self.canonical_value(v) for v in values],
            "equalities": equalities,
            "chain_ok": ok,
        }

        # Commit equality assertion as a receipt. If false, force quarantine via DIV by zero.
        if ok:
            out = self.runner.execute(
                "SUM",
                [first],
                input_payload={
                    "terminal": TERMINAL_FORMAT,
                    "form": "EQUALITY_CHAIN_ASSERT",
                    "witness": witness,
                },
            )
        else:
            out = self.runner.execute(
                "DIV",
                1,
                0,
                input_payload={
                    "terminal": TERMINAL_FORMAT,
                    "form": "EQUALITY_CHAIN_ASSERT_FAIL",
                    "witness": witness,
                },
            )

        receipts = [r.to_dict() for r in self.runner.commitments.receipts[before_count:]]

        return AlgebraEvalResult(
            ok=ok and bool(out.get("ok")),
            source=source,
            normalized_source="==".join(parts),
            value=self.canonical_value(first) if ok else None,
            receipts=receipts,
            witness=witness,
            error="" if ok else "equality chain contradiction",
        )

    def eval_source(self, source: str) -> AlgebraEvalResult:
        source = source.strip()
        if not source:
            return AlgebraEvalResult(ok=True, source=source, value=None, receipts=[], witness={"noop": True})

        if ":=" in source:
            lhs, rhs = source.split(":=", 1)
            return self.assign(lhs, rhs)

        # Also allow single = for assignment, but not ==.
        if "=" in source and "==" not in source:
            lhs, rhs = source.split("=", 1)
            return self.assign(lhs, rhs)

        if "==" in source:
            return self.equality_chain(source)

        before_count = len(self.runner.commitments.receipts)
        value = self.eval_expr(source, source=source)
        out = self.runner.execute(
            "SUM",
            [value],
            input_payload={
                "terminal": TERMINAL_FORMAT,
                "form": "EXPR",
                "source": source,
                "value": value,
            },
        )
        receipts = [r.to_dict() for r in self.runner.commitments.receipts[before_count:]]

        return AlgebraEvalResult(
            ok=bool(out.get("ok")),
            source=source,
            normalized_source=self.parser_source(source),
            value=self.canonical_value(value),
            receipts=receipts,
            witness={
                "form": "EXPR",
                "source": source,
                "value": self.canonical_value(value),
                "receipt": out.get("receipt"),
            },
            error="" if out.get("ok") else out.get("reason", "expression audit failed"),
        )


class HHSTerminalV3Algebra:
    def __init__(self, kernel_path: str | Path = DEFAULT_KERNEL_PATH):
        self.kernel_path = Path(kernel_path)
        self.runner = AuditedRunner(self.kernel_path)
        self.compiler = HHSAlgebraCompilerV1(self.runner)
        self.history: List[Dict[str, Any]] = []
        self.last_output: Optional[Dict[str, Any]] = None
        self.running = True

    def emit(self, payload: Dict[str, Any]) -> None:
        self.last_output = payload
        print(json.dumps(payload, indent=2, ensure_ascii=False))

    def maintenance(self, line: str) -> Optional[Dict[str, Any]]:
        try:
            tokens = shlex.split(line)
        except ValueError as exc:
            return {"ok": False, "error": f"parse error: {exc}"}

        if not tokens:
            return {"ok": True, "noop": True}

        cmd = tokens[0].lower()
        args = tokens[1:]

        if cmd in {"quit", "exit"}:
            self.running = False
            return {"ok": True, "terminal": "closing"}

        if cmd == "help":
            return {
                "ok": True,
                "terminal": TERMINAL_FORMAT,
                "primary_syntax": [
                    "A := 2",
                    "B := 3",
                    "R := A + B",
                    "a² == c² - b²",
                    "a² == b²/2 == c²-b²",
                    "xy == 1",
                    "yx == -1",
                ],
                "helpers": [
                    "sort [3,1,2]",
                    "search [1,3,5,7] 5",
                ],
                "maintenance": [
                    "vars",
                    "status",
                    "chain",
                    "receipts",
                    "save file.hhsrun",
                    "load file.hhsrun",
                    "verify file.hhsrun",
                    "quit",
                ],
            }

        if cmd == "vars":
            return {
                "ok": True,
                "symbols": canonicalize_for_hash72(self.compiler.symbols),
            }

        if cmd == "status":
            return {
                "ok": True,
                "phase": self.runner.commitments.phase,
                "receipt_count": len(self.runner.commitments.receipts),
                "tip_hash72": self.runner.commitments.tip_hash72,
                "chain": self.runner.commitments.verify_chain(),
            }

        if cmd == "chain":
            report = HHSReceiptReplayVerifierV1(self.kernel_path).verify_runner(self.runner).to_dict()
            return {
                "ok": report["ok"],
                "chain": self.runner.commitments.verify_chain(),
                "replay": report,
            }

        if cmd == "receipts":
            return {
                "ok": True,
                "receipts": [r.to_dict() for r in self.runner.commitments.receipts],
            }

        if cmd == "save":
            if not args:
                return {"ok": False, "error": "save requires output path"}
            path = Path(args[0])
            payload = {
                "format": RUN_RESULT_FORMAT,
                "program_name": "TERMINAL_ALGEBRA_SESSION",
                "terminal_format": TERMINAL_FORMAT,
                "symbols": canonicalize_for_hash72(self.compiler.symbols),
                "history": self.history,
                "receipts": [r.to_dict() for r in self.runner.commitments.receipts],
                "chain": self.runner.commitments.verify_chain(),
                "replay": HHSReceiptReplayVerifierV1(self.kernel_path).verify_runner(self.runner).to_dict(),
                "all_ok": self.runner.commitments.verify_chain().get("ok") is True,
            }
            path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            return {"ok": True, "saved": str(path), "tip_hash72": self.runner.commitments.tip_hash72}

        if cmd == "load":
            if not args:
                return {"ok": False, "error": "load requires .hhsrun path"}
            payload = load_json(args[0])
            verify = HHSReceiptReplayVerifierV1(self.kernel_path).verify(
                payload.get("receipts", []),
                expected_tip_hash72=payload.get("chain", {}).get("tip_hash72"),
            ).to_dict()
            if not verify.get("ok"):
                return {"ok": False, "error": "replay verification failed", "verify": verify}
            if "symbols" in payload:
                self.compiler.symbols.update(payload["symbols"])
            return {"ok": True, "loaded": args[0], "verify": verify, "symbols_loaded": "symbols" in payload}

        if cmd == "verify":
            if not args:
                return {"ok": False, "error": "verify requires .hhsrun path"}
            return verify_run_file(args[0], kernel_path=self.kernel_path)

        if cmd == "sort":
            if not args:
                return {"ok": False, "error": "sort requires JSON list"}
            arr = json.loads(args[0])
            out = self.runner.execute("SORT", arr, input_payload={"terminal": TERMINAL_FORMAT, "helper": "sort", "arr": arr})
            return out

        if cmd == "search":
            if len(args) < 2:
                return {"ok": False, "error": "search requires JSON list and target"}
            arr = json.loads(args[0])
            target = args[1]
            out = self.runner.execute("BINARY_SEARCH", arr, target, input_payload={"terminal": TERMINAL_FORMAT, "helper": "search", "arr": arr, "target": target})
            return out

        return None

    def dispatch(self, line: str) -> Dict[str, Any]:
        line = line.strip()
        if not line:
            return {"ok": True, "noop": True}

        maint = self.maintenance(line)
        if maint is not None:
            return maint

        try:
            result = self.compiler.eval_source(line)
            payload = result.to_dict()
            self.history.append(payload)
            return payload
        except Exception as exc:
            payload = {
                "ok": False,
                "source": line,
                "error": type(exc).__name__,
                "message": str(exc),
            }
            self.history.append(payload)
            return payload

    def repl(self) -> None:
        print("TERMINAL_HHSPROG_V3_ALGEBRA LOCKED SHELL")
        print("custom algebra syntax is primary; type 'help' for forms")
        while self.running:
            try:
                line = input("hhsα> ")
            except EOFError:
                break
            out = self.dispatch(line)
            self.emit(out)


def main(argv: Optional[List[str]] = None) -> int:
    term = HHSTerminalV3Algebra()
    if argv and len(argv) > 0:
        out = term.dispatch(" ".join(argv))
        term.emit(out)
        return 0 if out.get("ok") else 1
    term.repl()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
