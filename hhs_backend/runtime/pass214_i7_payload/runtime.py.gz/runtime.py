from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

PASS_NUMBER = 214
ITERATION = 7
RUNTIME_CLASSIFICATION = "HHS_PASS_214_ITERATION_7_LIVE_ADMISSION_ABLATION_BRIDGE_V1"
BASE_COMMIT = "5be251a3df5bd3f949dbae8e34c71cfd5465bcd6"
BASE_TREE = "8106623e074c5ec939e64c838f102ead403bc832"
PASS213_CLOSURE = "86ec461818682fc87232740758769602e8f9fe05"
ITERATION6_CANDIDATE_SET_ROOT = "f11bdbb9940e90500692cd0a0c505727ad94cafc0ea4fca85b134253f72cab9f"
ITERATION6_REPORT_ROOT = "f5712fb2c95c47908bf2fc74251fc3d7296ea68617086b299b3aa17e7f60df8f"
ITERATION6_RECEIPT = "b2080cbe321f34f8e384b47be95c8cbb3f00b5429445207775e0a2b26d527d34"

CHALLENGE_SCHEMA = "HHS_PASS_214_ITERATION_7_LIVE_ADMISSION_CHALLENGE_V1"
ADMISSION_SCHEMA = "HHS_PASS_213_LIVE_GOVERNED_SURFACE_ADMISSION_V1"
PLAN_SCHEMA = "HHS_PASS_214_ITERATION_7_FIVE_FAMILY_ABLATION_PLAN_V1"
REPORT_SCHEMA = "HHS_PASS_214_ITERATION_7_LIVE_ADMISSION_REPORT_V1"
LIVE_CLASSIFICATION = "PASS213_LIVE_GOVERNED_SURFACE"
FIXTURE_MARKERS = ("fixture", "synthetic", " mock", "mock ", "test-only", "test_only")
ZERO64 = "0" * 64
ZERO72 = "0" * 72

CANDIDATES = (
    {
        "family": "vector_cache",
        "path": "hhs_runtime/hhs_semantic_composition_cache_v1.py",
        "surface": "SemanticCompositionCache",
        "git_blob_sha1": "8809e746bb270db89bdd3a5cdcc7fda8a0b6e97e",
    },
    {
        "family": "wrapper_duplication",
        "path": "hhs_backend/runtime/hhs_agent_algorithm_identity_v1.py",
        "surface": "self_test",
        "git_blob_sha1": "ab698bcb745e0333e79116a71f06c9ebd6cc94c0",
    },
    {
        "family": "numeric_lookup",
        "path": "hhs_backend/runtime/hhs_pass213_tensor_geometry_v1.py",
        "surface": "lo_shu_grid/fibonacci_phase/permutation",
        "git_blob_sha1": "9046f6b3b8ecc1c39ce423fd67b98660415490e2",
    },
    {
        "family": "serialization_import",
        "path": "hhs_backend/runtime/hhs_pass213_compiled_rom_v1.py",
        "surface": "canonical_bytes/CompiledROMStore",
        "git_blob_sha1": "daffda13abedcc77bb48fe1936aaef22b7d610b9",
    },
    {
        "family": "coprime_lookup",
        "path": "hhs_backend/runtime/hhs_pass213_tensor_closure_v1.py",
        "surface": "_coprime/TensorClosureProof",
        "git_blob_sha1": "83699bfe237a2d73e47dedf0bfb6eef8beb6919c",
    },
)


class Pass214Iteration7Error(RuntimeError):
    pass


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def hash216(domain: str, value: Any) -> str:
    payload = value if isinstance(value, (bytes, bytearray)) else canonical_bytes(value)
    domain_bytes = domain.encode("utf-8")
    framed = b"HHS-P213-HASH216-V1\0" + len(domain_bytes).to_bytes(2, "big") + domain_bytes + len(payload).to_bytes(8, "big") + bytes(payload)
    return sha256(framed).hexdigest()


def _require_hex(value: Any, length: int, code: str, *, nonzero: bool = True) -> str:
    if not isinstance(value, str) or len(value) != length:
        raise Pass214Iteration7Error(code)
    try:
        int(value, 16)
    except ValueError as exc:
        raise Pass214Iteration7Error(code) from exc
    if nonzero and set(value) == {"0"}:
        raise Pass214Iteration7Error(code)
    return value.lower()


def _require_text(value: Any, code: str, maximum: int = 512) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise Pass214Iteration7Error(code)
    return value.strip()


def _reject_fixture_text(*values: Any) -> None:
    joined = " ".join(str(value).lower() for value in values if value is not None)
    if any(marker in joined for marker in FIXTURE_MARKERS):
        raise Pass214Iteration7Error("PASS214_I7_FIXTURE_OR_SYNTHETIC_AUTHORITY_REJECTED")


def build_challenge(*, nonce: str, requested_timestamp_ns: int) -> dict[str, Any]:
    nonce = _require_text(nonce, "PASS214_I7_NONCE_INVALID", 256)
    if isinstance(requested_timestamp_ns, bool) or not isinstance(requested_timestamp_ns, int) or requested_timestamp_ns <= 0:
        raise Pass214Iteration7Error("PASS214_I7_REQUEST_TIME_INVALID")
    unsigned = {
        "schema": CHALLENGE_SCHEMA,
        "pass": PASS_NUMBER,
        "iteration": ITERATION,
        "base_commit": BASE_COMMIT,
        "pass213_closure": PASS213_CLOSURE,
        "iteration6_candidate_set_root_hash216": ITERATION6_CANDIDATE_SET_ROOT,
        "iteration6_receipt_sha256": ITERATION6_RECEIPT,
        "nonce": nonce,
        "requested_timestamp_ns": requested_timestamp_ns,
    }
    return {**unsigned, "challenge_root_hash216": hash216("pass214-iteration7-live-admission-challenge", unsigned)}


def validate_challenge(value: Mapping[str, Any]) -> dict[str, Any]:
    candidate = dict(value)
    if candidate.get("schema") != CHALLENGE_SCHEMA or candidate.get("pass") != PASS_NUMBER or candidate.get("iteration") != ITERATION:
        raise Pass214Iteration7Error("PASS214_I7_CHALLENGE_SCHEMA_INVALID")
    if candidate.get("base_commit") != BASE_COMMIT or candidate.get("pass213_closure") != PASS213_CLOSURE:
        raise Pass214Iteration7Error("PASS214_I7_CHALLENGE_LINEAGE_INVALID")
    if candidate.get("iteration6_candidate_set_root_hash216") != ITERATION6_CANDIDATE_SET_ROOT or candidate.get("iteration6_receipt_sha256") != ITERATION6_RECEIPT:
        raise Pass214Iteration7Error("PASS214_I7_CHALLENGE_CANDIDATE_BINDING_INVALID")
    unsigned = {key: candidate[key] for key in candidate if key != "challenge_root_hash216"}
    expected = hash216("pass214-iteration7-live-admission-challenge", unsigned)
    if candidate.get("challenge_root_hash216") != expected:
        raise Pass214Iteration7Error("PASS214_I7_CHALLENGE_ROOT_MISMATCH")
    _require_text(candidate.get("nonce"), "PASS214_I7_NONCE_INVALID", 256)
    if int(candidate.get("requested_timestamp_ns", 0)) <= 0:
        raise Pass214Iteration7Error("PASS214_I7_REQUEST_TIME_INVALID")
    return candidate


def _record_mapping(record: Any) -> dict[str, Any]:
    if record is None:
        raise Pass214Iteration7Error("PASS214_I7_REQUIRED_RECORD_MISSING")
    if isinstance(record, Mapping):
        return dict(record)
    if hasattr(record, "to_mapping"):
        value = record.to_mapping()
        if isinstance(value, Mapping):
            return dict(value)
    raise Pass214Iteration7Error("PASS214_I7_RECORD_MAPPING_REQUIRED")


def _public(record: Any) -> dict[str, Any]:
    mapping = _record_mapping(record)
    public = mapping.get("public_data", {})
    if not isinstance(public, Mapping):
        raise Pass214Iteration7Error("PASS214_I7_PUBLIC_DATA_INVALID")
    return dict(public)


def _verify_operational_anchor(*, trusted_anchor_mapping: Mapping[str, Any], verifier_bundle_mapping: Mapping[str, Any], trust_bundle_path: str | Path) -> dict[str, Any]:
    try:
        from hhs_backend.runtime.hhs_pass213_pqc_enclosure_v1 import PQCVerifierBundle
        from hhs_backend.runtime.hhs_pass213_trusted_timestamp_v1 import RFC3161TimestampVerifier, TrustedTimestampAnchorRecord
    except Exception as exc:
        raise Pass214Iteration7Error("PASS214_I7_PASS213_TIMESTAMP_RUNTIME_UNAVAILABLE") from exc
    record = TrustedTimestampAnchorRecord.from_mapping(dict(trusted_anchor_mapping))
    bundle = PQCVerifierBundle.from_mapping(dict(verifier_bundle_mapping))
    verifier = RFC3161TimestampVerifier(trust_bundle_path=trust_bundle_path)
    if not record.validate(verifier_bundle=bundle, timestamp_verifier=verifier):
        raise Pass214Iteration7Error("PASS214_I7_TRUSTED_TIMESTAMP_REVERIFY_FAILED")
    mapped = record.to_mapping()
    intent = dict(mapped["intent"])
    evidence = dict(mapped["evidence"])
    _reject_fixture_text(intent.get("authority_id"), evidence.get("tsa_subject"))
    _require_hex(mapped.get("anchor_root_hash216"), 64, "PASS214_I7_TIMESTAMP_ANCHOR_ROOT_INVALID")
    _require_hex(evidence.get("verification_receipt_hash216"), 64, "PASS214_I7_TIMESTAMP_VERIFICATION_RECEIPT_INVALID")
    _require_hex(evidence.get("trust_bundle_sha256"), 64, "PASS214_I7_TIMESTAMP_TRUST_BUNDLE_INVALID")
    return mapped


def inspect_runtime_dependencies(*, surface: Any, dispatch_service: Any, trusted_anchor_mapping: Mapping[str, Any] | None = None, verifier_bundle_mapping: Mapping[str, Any] | None = None, trust_bundle_path: str | Path | None = None, anchor_verifier: Callable[..., Mapping[str, Any]] | None = None) -> dict[str, Any]:
    blockers: list[str] = []
    details: dict[str, Any] = {}
    try:
        if not surface.store.verify_chain():
            blockers.append("PASS213_SURFACE_CHAIN_INVALID")
        summary = dict(surface.store.summary())
        details["surface_summary"] = summary
        _require_hex(summary.get("projection_head_hash216"), 64, "PASS214_I7_SURFACE_HEAD_INVALID")
        timestamp_record = surface.store.latest("TIMESTAMP_ANCHOR")
        tensor_record = surface.store.latest("MOVING_TENSOR")
        if timestamp_record is None:
            blockers.append("PASS213_LIVE_TIMESTAMP_ANCHOR_MISSING")
        if tensor_record is None:
            blockers.append("PASS213_LIVE_MOVING_TENSOR_MISSING")
    except Exception as exc:
        blockers.append(f"PASS213_SURFACE_INSPECTION_FAILED:{type(exc).__name__}:{exc}")
        timestamp_record = None
        tensor_record = None

    try:
        if not dispatch_service.authority.ledger.verify_chain():
            blockers.append("PASS213_NATIVE_DISPATCH_LEDGER_INVALID")
        dispatch_status = dict(dispatch_service.authority.status())
        latest_dispatch = dispatch_service.authority.ledger.latest()
        details["native_dispatch_status"] = dispatch_status
        if latest_dispatch is None:
            blockers.append("PASS213_NATIVE_DISPATCH_RECEIPT_MISSING")
    except Exception as exc:
        blockers.append(f"PASS213_NATIVE_DISPATCH_INSPECTION_FAILED:{type(exc).__name__}:{exc}")
        dispatch_status = {}
        latest_dispatch = None

    verified_anchor = None
    if trusted_anchor_mapping is None or verifier_bundle_mapping is None or trust_bundle_path is None:
        blockers.append("PASS213_OPERATIONAL_RFC3161_REVERIFICATION_INPUTS_MISSING")
    else:
        try:
            verifier = anchor_verifier or _verify_operational_anchor
            verified_anchor = dict(verifier(
                trusted_anchor_mapping=trusted_anchor_mapping,
                verifier_bundle_mapping=verifier_bundle_mapping,
                trust_bundle_path=trust_bundle_path,
            ))
            verified_intent = dict(verified_anchor.get("intent", {}))
            verified_evidence = dict(verified_anchor.get("evidence", {}))
            details["trusted_anchor_verification"] = {
                "anchor_root_hash216": verified_anchor.get("anchor_root_hash216"),
                "authority_id": verified_intent.get("authority_id"),
                "evidence_root_hash216": verified_evidence.get("evidence_root_hash216"),
                "verification_receipt_hash216": verified_evidence.get("verification_receipt_hash216"),
                "trust_bundle_sha256": verified_evidence.get("trust_bundle_sha256"),
                "tsa_subject": verified_evidence.get("tsa_subject"),
                "tsa_policy_oid": verified_evidence.get("tsa_policy_oid"),
                "gen_time_utc": verified_evidence.get("gen_time_utc"),
            }
        except Exception as exc:
            blockers.append(f"PASS213_OPERATIONAL_RFC3161_REVERIFICATION_FAILED:{type(exc).__name__}:{exc}")

    if timestamp_record is not None and tensor_record is not None and latest_dispatch is not None and verified_anchor is not None:
        try:
            timestamp_public = _public(timestamp_record)
            tensor_public = _public(tensor_record)
            latest_dispatch = dict(latest_dispatch)
            runtime_state = dict(dispatch_status.get("runtime_state", {}))
            verified_intent = dict(verified_anchor.get("intent", {}))
            verified_evidence = dict(verified_anchor.get("evidence", {}))
            anchor_root = _require_hex(verified_anchor.get("anchor_root_hash216"), 64, "PASS214_I7_TIMESTAMP_ANCHOR_ROOT_INVALID")
            verified_receipt = _require_hex(verified_evidence.get("verification_receipt_hash216"), 64, "PASS214_I7_TIMESTAMP_VERIFICATION_RECEIPT_INVALID")
            verified_trust = _require_hex(verified_evidence.get("trust_bundle_sha256"), 64, "PASS214_I7_TIMESTAMP_TRUST_BUNDLE_INVALID")
            verified_evidence_root = _require_hex(verified_evidence.get("evidence_root_hash216"), 64, "PASS214_I7_TIMESTAMP_EVIDENCE_ROOT_INVALID")
            verified_authority = _require_text(verified_intent.get("authority_id"), "PASS214_I7_TIMESTAMP_AUTHORITY_ID_INVALID")
            verified_subject = _require_text(verified_evidence.get("tsa_subject"), "PASS214_I7_TIMESTAMP_TSA_SUBJECT_INVALID")
            surface_anchor = _require_hex(timestamp_public.get("anchor_root_hash216"), 64, "PASS214_I7_SURFACE_ANCHOR_ROOT_INVALID")
            tensor_root = _require_hex(tensor_public.get("tensor_root_hash216"), 64, "PASS214_I7_TENSOR_ROOT_INVALID")
            tensor_anchor = _require_hex(tensor_public.get("anchor_root_hash216"), 64, "PASS214_I7_TENSOR_ANCHOR_ROOT_INVALID")
            dispatch_tensor = _require_hex(runtime_state.get("tensor_root_hash216"), 64, "PASS214_I7_DISPATCH_TENSOR_ROOT_INVALID")
            dispatch_anchor = _require_hex(runtime_state.get("trusted_anchor_root_hash216"), 64, "PASS214_I7_DISPATCH_ANCHOR_ROOT_INVALID")
            dispatch_receipt = _require_hex(latest_dispatch.get("receipt_hash72"), 72, "PASS214_I7_DISPATCH_RECEIPT_INVALID")
            dispatch_successor = _require_hex(latest_dispatch.get("successor_state_root_hash216"), 64, "PASS214_I7_DISPATCH_SUCCESSOR_ROOT_INVALID")
            dispatch_receipt_tensor = _require_hex(latest_dispatch.get("tensor_root_hash216"), 64, "PASS214_I7_DISPATCH_RECEIPT_TENSOR_ROOT_INVALID")
            dispatch_lineage = _require_hex(latest_dispatch.get("lineage_root_hash216"), 64, "PASS214_I7_DISPATCH_LINEAGE_ROOT_INVALID")
            runtime_lineage = _require_hex(runtime_state.get("lineage_root_hash216"), 64, "PASS214_I7_RUNTIME_LINEAGE_ROOT_INVALID")
            _reject_fixture_text(timestamp_public.get("authority_id"), timestamp_public.get("tsa_subject"), verified_authority, verified_subject)
            surface_trust = _require_hex(timestamp_public.get("trust_bundle_sha256"), 64, "PASS214_I7_SURFACE_TRUST_BUNDLE_INVALID")
            if timestamp_public.get("authority_id") != verified_authority or timestamp_public.get("tsa_subject") != verified_subject or surface_trust != verified_trust:
                blockers.append("PASS213_TIMESTAMP_PROJECTION_REVERIFICATION_MISMATCH")
            if not (anchor_root == surface_anchor == tensor_anchor == dispatch_anchor):
                blockers.append("PASS213_ANCHOR_BINDING_MISMATCH")
            if tensor_root != dispatch_tensor or tensor_root != dispatch_receipt_tensor:
                blockers.append("PASS213_TENSOR_DISPATCH_BINDING_MISMATCH")
            if dispatch_lineage != runtime_lineage:
                blockers.append("PASS213_NATIVE_DISPATCH_LINEAGE_MISMATCH")
            details.update({
                "timestamp_projection": _record_mapping(timestamp_record),
                "tensor_projection": _record_mapping(tensor_record),
                "latest_native_dispatch_receipt": latest_dispatch,
                "dispatch_receipt_hash72": dispatch_receipt,
                "dispatch_successor_state_root_hash216": dispatch_successor,
                "dispatch_lineage_root_hash216": dispatch_lineage,
                "trusted_timestamp_verification_receipt_hash216": verified_receipt,
                "trusted_timestamp_evidence_root_hash216": verified_evidence_root,
                "trusted_timestamp_trust_bundle_sha256": verified_trust,
            })
        except Exception as exc:
            blockers.append(f"PASS213_CROSS_AUTHORITY_BINDING_FAILED:{type(exc).__name__}:{exc}")

    return {
        "schema": "HHS_PASS_214_ITERATION_7_LIVE_DEPENDENCY_INSPECTION_V1",
        "ready": not blockers,
        "blockers": blockers,
        "details": details,
    }


def create_live_admission(*, surface: Any, dispatch_service: Any, trusted_anchor_mapping: Mapping[str, Any], verifier_bundle_mapping: Mapping[str, Any], trust_bundle_path: str | Path, nonce: str, requested_timestamp_ns: int, anchor_verifier: Callable[..., Mapping[str, Any]] | None = None, hash72_factory: Callable[[str], str] | None = None) -> dict[str, Any]:
    challenge = build_challenge(nonce=nonce, requested_timestamp_ns=requested_timestamp_ns)
    inspection = inspect_runtime_dependencies(
        surface=surface,
        dispatch_service=dispatch_service,
        trusted_anchor_mapping=trusted_anchor_mapping,
        verifier_bundle_mapping=verifier_bundle_mapping,
        trust_bundle_path=trust_bundle_path,
        anchor_verifier=anchor_verifier,
    )
    if not inspection["ready"]:
        raise Pass214Iteration7Error("PASS214_I7_LIVE_DEPENDENCIES_BLOCKED:" + "|".join(inspection["blockers"]))
    challenge_root = challenge["challenge_root_hash216"]
    if hash72_factory is None:
        try:
            from hhs_runtime.core.hash72_digest_v1 import hash72_digest
        except Exception as exc:
            raise Pass214Iteration7Error("PASS214_I7_HASH72_RUNTIME_UNAVAILABLE") from exc
        source_receipt = hash72_digest({"domain": "HHS-P214-I7-CANDIDATE-ADMISSION-CHALLENGE-V1"}, bytes.fromhex(challenge_root))
    else:
        source_receipt = hash72_factory(challenge_root)
    source_receipt = _require_hex(source_receipt, 72, "PASS214_I7_CHALLENGE_HASH72_INVALID")
    projection = surface.publish_receipt(
        object_id=f"pass214-i7-candidate-set-{ITERATION6_CANDIDATE_SET_ROOT}",
        source_root_hash216=challenge_root,
        receipt_hash72=source_receipt,
        classification="HHS_PASS_214_ITERATION_7_CANDIDATE_SET_LIVE_ADMISSION",
        published_timestamp_ns=requested_timestamp_ns,
    )
    if not surface.store.verify_chain():
        raise Pass214Iteration7Error("PASS214_I7_POST_PUBLISH_SURFACE_CHAIN_INVALID")
    projection_mapping = _record_mapping(projection)
    details = inspection["details"]
    timestamp_public = _public(details["timestamp_projection"])
    tensor_public = _public(details["tensor_projection"])
    latest_dispatch = dict(details["latest_native_dispatch_receipt"])
    unsigned = {
        "schema": ADMISSION_SCHEMA,
        "classification": LIVE_CLASSIFICATION,
        "pass": PASS_NUMBER,
        "iteration": ITERATION,
        "base_commit": BASE_COMMIT,
        "pass213_closure": PASS213_CLOSURE,
        "candidate_set_root_hash216": ITERATION6_CANDIDATE_SET_ROOT,
        "challenge": challenge,
        "governed_projection": projection_mapping,
        "governed_surface_head_hash216": surface.store.current_head(),
        "trusted_timestamp_anchor_root_hash216": timestamp_public["anchor_root_hash216"],
        "trusted_timestamp_evidence_root_hash216": details["trusted_timestamp_evidence_root_hash216"],
        "trusted_timestamp_verification_receipt_hash216": details["trusted_timestamp_verification_receipt_hash216"],
        "trusted_timestamp_trust_bundle_sha256": details["trusted_timestamp_trust_bundle_sha256"],
        "moving_tensor_root_hash216": tensor_public["tensor_root_hash216"],
        "native_dispatch_receipt_hash72": latest_dispatch["receipt_hash72"],
        "native_dispatch_successor_state_root_hash216": latest_dispatch["successor_state_root_hash216"],
        "native_dispatch_lineage_root_hash216": details["dispatch_lineage_root_hash216"],
        "native_dispatch_sequence": int(latest_dispatch["sequence"]),
        "trusted_timestamp_reverified_in_process": True,
        "surface_chain_reverified_in_process": True,
        "native_dispatch_ledger_reverified_in_process": True,
        "fixture_or_synthetic_authority": False,
        "candidate_execution_started": False,
        "migration_active": False,
        "authority_promoted": False,
        "terminal_roots_minted": False,
        "pass215_authorized": False,
    }
    return {**unsigned, "admission_root_hash216": hash216("pass214-iteration7-live-governed-admission", unsigned)}


def validate_recorded_admission(value: Mapping[str, Any]) -> dict[str, Any]:
    admission = dict(value)
    if admission.get("schema") != ADMISSION_SCHEMA or admission.get("classification") != LIVE_CLASSIFICATION:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_SCHEMA_INVALID")
    if admission.get("pass") != PASS_NUMBER or admission.get("iteration") != ITERATION or admission.get("base_commit") != BASE_COMMIT:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_LINEAGE_INVALID")
    if admission.get("pass213_closure") != PASS213_CLOSURE or admission.get("candidate_set_root_hash216") != ITERATION6_CANDIDATE_SET_ROOT:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_CANDIDATE_BINDING_INVALID")
    validate_challenge(dict(admission.get("challenge", {})))
    for field, length in (
        ("governed_surface_head_hash216", 64),
        ("trusted_timestamp_anchor_root_hash216", 64),
        ("trusted_timestamp_evidence_root_hash216", 64),
        ("trusted_timestamp_verification_receipt_hash216", 64),
        ("trusted_timestamp_trust_bundle_sha256", 64),
        ("moving_tensor_root_hash216", 64),
        ("native_dispatch_receipt_hash72", 72),
        ("native_dispatch_successor_state_root_hash216", 64),
        ("native_dispatch_lineage_root_hash216", 64),
    ):
        _require_hex(admission.get(field), length, f"PASS214_I7_ADMISSION_{field.upper()}_INVALID")
    if admission.get("fixture_or_synthetic_authority") is not False:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_FIXTURE_FLAG_INVALID")
    if admission.get("candidate_execution_started") is not False or admission.get("migration_active") is not False or admission.get("authority_promoted") is not False or admission.get("terminal_roots_minted") is not False or admission.get("pass215_authorized") is not False:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_NONPROMOTING_POLICY_VIOLATION")
    unsigned = {key: admission[key] for key in admission if key != "admission_root_hash216"}
    expected = hash216("pass214-iteration7-live-governed-admission", unsigned)
    if admission.get("admission_root_hash216") != expected:
        raise Pass214Iteration7Error("PASS214_I7_ADMISSION_ROOT_MISMATCH")
    return admission


def build_ablation_plan(admission: Mapping[str, Any], *, require_live_in_process: bool = True) -> dict[str, Any]:
    verified = validate_recorded_admission(admission)
    if require_live_in_process and not all(verified.get(field) is True for field in (
        "trusted_timestamp_reverified_in_process",
        "surface_chain_reverified_in_process",
        "native_dispatch_ledger_reverified_in_process",
    )):
        raise Pass214Iteration7Error("PASS214_I7_RECORDED_ADMISSION_REQUIRES_LIVE_RECHECK")
    families = []
    for index, candidate in enumerate(CANDIDATES, 1):
        families.append({
            "order": index,
            **candidate,
            "baseline": "INHERITED_REPOSITORY_NATIVE_CALLABLE",
            "optimized_comparator": f"PASS214_ITERATION5_{candidate['family']}_GENERATOR_TRANSITION",
            "required_trials": 3,
            "checks": [
                "canonical_output_bit_exact",
                "no_float_canonical_authority",
                "deterministic_replay",
                "candidate_git_blob_unchanged",
                "pass213_live_admission_still_valid",
                "representation_bytes",
                "integer_nanosecond_observation",
            ],
            "ablations": [
                "baseline_only",
                "generator_transition_only",
                "generator_transition_without_cache_reuse",
                "generator_transition_without_cross_family_compounding",
            ],
            "migration_allowed": False,
        })
    unsigned = {
        "schema": PLAN_SCHEMA,
        "pass": PASS_NUMBER,
        "iteration": ITERATION,
        "admission_root_hash216": verified["admission_root_hash216"],
        "candidate_set_root_hash216": ITERATION6_CANDIDATE_SET_ROOT,
        "family_count": len(families),
        "families": families,
        "compound_order": [candidate["family"] for candidate in CANDIDATES],
        "execution_policy": {
            "candidate_import_for_benchmark_only": True,
            "candidate_execution_for_migration": False,
            "migration_active": False,
            "authority_promoted": False,
            "terminal_roots_minted": False,
            "pass215_authorized": False,
            "abort_on_live_admission_change": True,
        },
    }
    return {**unsigned, "plan_root_hash216": hash216("pass214-iteration7-five-family-ablation-plan", unsigned)}


def inspect_default_runtime(*, trusted_anchor_mapping: Mapping[str, Any] | None = None, verifier_bundle_mapping: Mapping[str, Any] | None = None, trust_bundle_path: str | Path | None = None) -> dict[str, Any]:
    try:
        from hhs_backend.runtime.hhs_pass213_governed_surface_v2 import get_default_pass213_surface
        from hhs_backend.runtime.hhs_pass213_native_dispatch_authority_v1 import get_default_native_dispatch_service
        surface = get_default_pass213_surface()
        dispatch = get_default_native_dispatch_service()
    except Exception as exc:
        return {
            "schema": REPORT_SCHEMA,
            "status": "LIVE_RUNTIME_UNAVAILABLE",
            "ready": False,
            "blockers": [f"PASS213_DEFAULT_RUNTIME_UNAVAILABLE:{type(exc).__name__}:{exc}"],
            "migration_active": False,
            "authority_promoted": False,
            "pass215_authorized": False,
        }
    inspection = inspect_runtime_dependencies(
        surface=surface,
        dispatch_service=dispatch,
        trusted_anchor_mapping=trusted_anchor_mapping,
        verifier_bundle_mapping=verifier_bundle_mapping,
        trust_bundle_path=trust_bundle_path,
    )
    return {
        "schema": REPORT_SCHEMA,
        "status": "LIVE_ADMISSION_READY" if inspection["ready"] else "LIVE_ADMISSION_BLOCKED",
        "ready": inspection["ready"],
        "blockers": inspection["blockers"],
        "details": inspection["details"],
        "migration_active": False,
        "authority_promoted": False,
        "pass215_authorized": False,
    }
