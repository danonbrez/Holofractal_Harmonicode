# Operating Guide

## Program files

`.hhsprog` defines operation sequences. `.hhsrun` stores run results and receipts.

## Symbolic macro terminal

```text
DEF CLOSURE(a,b,c) := c^2-a^2==b^2
CALL CLOSURE(a,b,c)
```

## State writes

Use `HHSStateLayerV1.set`, `.merge`, or `.delete`. Writes produce transition records and receipts.

## Physics evolution

Use `HHSPhysicsModelV1` to observe quantities, then `HHSPhysicsEvolutionV1` to add rules and step time.
