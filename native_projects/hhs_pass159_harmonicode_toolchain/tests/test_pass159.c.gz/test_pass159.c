#include "hhs_pass159_api.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int positive = 0;
static int negative = 0;
static int failures = 0;

#define CHECK_POS(expr) do { \
    HHS159Status _s = (expr); \
    if (_s == HHS159_STATUS_OK) ++positive; \
    else { ++failures; fprintf(stderr, "POSITIVE FAILED line %d: %s\n", __LINE__, hhs159_status_string(_s)); } \
} while (0)

#define CHECK_NEG(expr, expected) do { \
    HHS159Status _s = (expr); \
    if (_s == (expected)) ++negative; \
    else { ++failures; fprintf(stderr, "NEGATIVE FAILED line %d: got %s expected %s\n", __LINE__, hhs159_status_string(_s), hhs159_status_string(expected)); } \
} while (0)

static HHS159Source *open_text(HHS159Context *ctx, const char *text) {
    HHS159Source *src = NULL;
    HHS159SourceOpenOptions opts = {{sizeof(opts), HHS159_STRUCT_VERSION_1}, {(const uint8_t *)"test.hc", 7u}, {(const uint8_t *)"UTF-8", 5u}, 1u, 0u};
    HHS159ByteSpan span = {(const uint8_t *)text, strlen(text)};
    if (hhs159_source_open_bytes(ctx, span, &opts, &src) != HHS159_STATUS_OK) return NULL;
    return src;
}

int main(void) {
    HHS159ContextConfig cfg = {{sizeof(cfg), HHS159_STRUCT_VERSION_1}, 1u << 20, 100000u, 512u, 1u << 22, 0u, 0u, 0u};
    HHS159Context *ctx = NULL;
    HHS159Source *src = NULL;
    HHS159CST *cst = NULL;
    HHS159AST *ast = NULL;
    HHS159TypeEnvironment *types = NULL;
    HHS159ConstraintGraph *graph = NULL;
    HHS159IR *tokens = NULL, *hir = NULL, *vmir = NULL, *trace = NULL;
    HHS159Interpreter *interpreter = NULL;
    HHS159Compiler *compiler = NULL;
    HHS159Object *object = NULL;
    HHS159Executable *exe = NULL;
    HHS159Receipt *ireceipt = NULL, *creceipt = NULL, *phase = NULL, *replay = NULL, *reverse = NULL;
    HHS159ExecutionOptions exec = {{sizeof(exec), HHS159_STRUCT_VERSION_1}, HHS159_MODE_EVALUATE_PURE, 0u, 10000u, 64u, 1u << 20, NULL};
    HHS159CompareResult compare = {0};
    HHS159MutableByteSpan out = {0};
    compare.header.struct_size = sizeof(compare);
    compare.header.struct_version = HHS159_STRUCT_VERSION_1;
    void *roundtrip = NULL;

    CHECK_POS(hhs159_context_create(&cfg, &ctx));
    src = open_text(ctx, "x/y=y/x\n1+2*3\nO!=pi\n");
    if (!src) { fprintf(stderr, "source open failed\n"); return 1; }
    ++positive;

    {
        HHS159Status probe = hhs159_source_hash216(src, &out);
        if (probe == HHS159_STATUS_RESOURCE_BOUNDED && out.size_written == HHS159_HASH216_LENGTH) ++positive;
        else { ++failures; fprintf(stderr, "hash size probe failed\n"); }
    }

    CHECK_POS(hhs159_lex(ctx, src, &tokens));
    CHECK_POS(hhs159_parse_cst(ctx, src, &cst));
    out.data = NULL; out.capacity = 0u; out.size_written = 0u;
    {
        HHS159Status probe = hhs159_artifact_bytes(cst, &out);
        if (probe == HHS159_STATUS_RESOURCE_BOUNDED && out.size_written == strlen("x/y=y/x\n1+2*3\nO!=pi\n")) ++positive;
        else { ++failures; fprintf(stderr, "CST size probe failed\n"); }
    }

    CHECK_POS(hhs159_build_ast(ctx, cst, &ast));
    CHECK_POS(hhs159_typecheck(ctx, ast, &types));
    CHECK_POS(hhs159_build_constraint_graph(ctx, ast, types, &graph));
    CHECK_POS(hhs159_lower_hir(ctx, ast, types, graph, &hir));
    CHECK_POS(hhs159_lower_vmir(ctx, hir, &vmir));
    CHECK_POS(hhs159_interpreter_create(ctx, &interpreter));
    CHECK_POS(hhs159_interpret(interpreter, src, &exec, &ireceipt));
    CHECK_POS(hhs159_compiler_create(ctx, &compiler));
    CHECK_POS(hhs159_compile_object(compiler, src, &object, &phase));
    hhs159_receipt_release(phase); phase = NULL;
    {
        HHS159Object *objects[1] = {object};
        CHECK_POS(hhs159_link(ctx, objects, 1u, &exe, &phase));
    }
    hhs159_receipt_release(phase); phase = NULL;
    CHECK_POS(hhs159_execute(ctx, exe, &exec, &creceipt));
    CHECK_POS(hhs159_compare_interpreter_compiler(ctx, src, &exec, &compare));
    if (compare.matched && !compare.fallback_used) ++positive; else ++failures;
    CHECK_POS(hhs159_interpreter_replay(interpreter, ireceipt, &replay));
    CHECK_POS(hhs159_reverse(ctx, ireceipt, &reverse));
    CHECK_POS(hhs159_lift_trace(ctx, ireceipt, &trace));

    out.data = NULL; out.capacity = 0u; out.size_written = 0u;
    {
        HHS159Status probe = hhs159_serialize(object, &out);
        if (probe == HHS159_STATUS_RESOURCE_BOUNDED && out.size_written > 0u) ++positive;
        else { ++failures; fprintf(stderr, "serialization size probe failed\n"); }
    }
    {
        uint8_t *serialized = (uint8_t *)malloc(out.size_written);
        HHS159ByteSpan input;
        if (!serialized) return 1;
        out.data = serialized; out.capacity = out.size_written;
        CHECK_POS(hhs159_serialize(object, &out));
        input.data = serialized; input.size = out.size_written;
        CHECK_POS(hhs159_deserialize(ctx, input, HHS159_ARTIFACT_OBJECT, &roundtrip));
        free(serialized);
    }

    {
        HHS159Source *bad = open_text(ctx, "(1+2");
        HHS159CST *bad_cst = NULL;
        CHECK_NEG(hhs159_parse_cst(ctx, bad, &bad_cst), HHS159_STATUS_PARSE_ERROR);
        hhs159_source_release(bad);
    }
    {
        HHS159Source *bad = open_text(ctx, "1.25+2");
        HHS159CST *bc = NULL; HHS159AST *ba = NULL; HHS159TypeEnvironment *bt = NULL;
        CHECK_POS(hhs159_parse_cst(ctx, bad, &bc));
        CHECK_POS(hhs159_build_ast(ctx, bc, &ba));
        CHECK_NEG(hhs159_typecheck(ctx, ba, &bt), HHS159_STATUS_TYPE_ERROR);
        hhs159_artifact_release(ba); hhs159_artifact_release(bc); hhs159_source_release(bad);
    }
    {
        HHS159Source *bad = open_text(ctx, "1/0");
        HHS159CST *bc = NULL; HHS159AST *ba = NULL; HHS159TypeEnvironment *bt = NULL;
        CHECK_POS(hhs159_parse_cst(ctx, bad, &bc));
        CHECK_POS(hhs159_build_ast(ctx, bc, &ba));
        CHECK_NEG(hhs159_typecheck(ctx, ba, &bt), HHS159_STATUS_TYPE_ERROR);
        hhs159_artifact_release(ba); hhs159_artifact_release(bc); hhs159_source_release(bad);
    }
    {
        HHS159Source *good = open_text(ctx, "@profile native_zero\n1/0");
        HHS159CST *gc = NULL; HHS159AST *ga = NULL; HHS159TypeEnvironment *gt = NULL;
        CHECK_POS(hhs159_parse_cst(ctx, good, &gc));
        CHECK_POS(hhs159_build_ast(ctx, gc, &ga));
        CHECK_POS(hhs159_typecheck(ctx, ga, &gt));
        hhs159_artifact_release(gt); hhs159_artifact_release(ga); hhs159_artifact_release(gc); hhs159_source_release(good);
    }
    {
        HHS159Source *bad = open_text(ctx, "O=π");
        HHS159CST *bc = NULL; HHS159AST *ba = NULL; HHS159TypeEnvironment *bt = NULL;
        CHECK_POS(hhs159_parse_cst(ctx, bad, &bc));
        CHECK_POS(hhs159_build_ast(ctx, bc, &ba));
        CHECK_NEG(hhs159_typecheck(ctx, ba, &bt), HHS159_STATUS_TYPE_ERROR);
        hhs159_artifact_release(ba); hhs159_artifact_release(bc); hhs159_source_release(bad);
    }
    {
        uint8_t invalid_utf8[] = {0xC0u, 0xAFu};
        HHS159ByteSpan span = {invalid_utf8, sizeof(invalid_utf8)};
        HHS159Source *bad = NULL;
        CHECK_NEG(hhs159_source_open_bytes(ctx, span, NULL, &bad), HHS159_STATUS_INVALID_UTF8);
    }
    {
        uint8_t malformed[16] = {0};
        HHS159ByteSpan span = {malformed, sizeof(malformed)};
        void *bad = NULL;
        CHECK_NEG(hhs159_deserialize(ctx, span, 0u, &bad), HHS159_STATUS_SERIALIZATION_ERROR);
    }
    {
        volatile uint32_t cancel = 1u;
        HHS159ExecutionOptions cancelled = exec;
        HHS159Receipt *r = NULL;
        cancelled.cancel_flag = &cancel;
        CHECK_NEG(hhs159_interpret(interpreter, src, &cancelled, &r), HHS159_STATUS_CANCELLED);
    }

    printf("{\"classification\":\"HHS_PASS_159_FOUNDATION_IMPLEMENTED_PENDING_FULL_CLOSURE\",\"positive_total\":%d,\"negative_total\":%d,\"failures\":%d,\"interpreter_compiler_equivalence\":%s,\"fallback_used\":%s}\n",
        positive, negative, failures, compare.matched ? "true" : "false", compare.fallback_used ? "true" : "false");

    hhs159_artifact_release(roundtrip);
    hhs159_artifact_release(trace);
    hhs159_receipt_release(reverse);
    hhs159_receipt_release(replay);
    hhs159_receipt_release(creceipt);
    hhs159_receipt_release(ireceipt);
    hhs159_artifact_release(exe);
    hhs159_artifact_release(object);
    hhs159_compiler_release(compiler);
    hhs159_interpreter_release(interpreter);
    hhs159_artifact_release(vmir);
    hhs159_artifact_release(hir);
    hhs159_artifact_release(graph);
    hhs159_artifact_release(types);
    hhs159_artifact_release(ast);
    hhs159_artifact_release(cst);
    hhs159_artifact_release(tokens);
    hhs159_source_release(src);
    hhs159_context_release(ctx);
    return failures ? 1 : 0;
}
