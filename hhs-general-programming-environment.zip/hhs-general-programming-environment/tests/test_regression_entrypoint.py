from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "hhs_runtime"))
from hhs_regression_suite_v1 import HHSRegressionSuiteV1

if __name__ == "__main__":
    report = HHSRegressionSuiteV1().run_all()
    print(report)
    raise SystemExit(0 if report.get("all_ok") else 1)
