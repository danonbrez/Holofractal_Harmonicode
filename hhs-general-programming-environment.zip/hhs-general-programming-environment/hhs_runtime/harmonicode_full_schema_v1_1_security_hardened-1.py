from __future__ import annotations
from dataclasses import dataclass, asdict, field
from fractions import Fraction
from typing import Any, Dict, List

@dataclass(frozen=True)
class ClosureAnchorV11:
    omega: bool = True
    delta_e: Fraction = Fraction(0, 1)
    psi: Fraction = Fraction(0, 1)
    theta15: bool = True
    global_closure_ok: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "omega": self.omega,
            "delta_e": str(self.delta_e),
            "psi": str(self.psi),
            "theta15": self.theta15,
            "global_closure_ok": self.global_closure_ok,
        }

@dataclass(frozen=True)
class SchemaV11SecurityHardened:
    schema_version: str = "v1.1-security-hardened"
    lock_core: Dict[str, Any] = field(default_factory=lambda: {
        "x": "1/y",
        "y": "-x",
        "xy": "1",
        "yx": "-1",
    })
    closure_anchor: ClosureAnchorV11 = field(default_factory=ClosureAnchorV11)
    boundary: Dict[str, Any] = field(default_factory=lambda: {
        "carrier_cardinality": 72,
        "closure_modulus": 64,
        "refresh_cycle": 576,
        "palindromic_seed": "179971.179971",
    })
    ratio_spine: List[int] = field(default_factory=lambda: [2, 3, 5])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "lock_core": dict(self.lock_core),
            "closure_anchor": self.closure_anchor.to_dict(),
            "boundary": dict(self.boundary),
            "ratio_spine": list(self.ratio_spine),
        }

UHMCA_SCHEMA_V1_1 = SchemaV11SecurityHardened()

def schema_summary_dict_v1_1() -> Dict[str, Any]:
    return UHMCA_SCHEMA_V1_1.to_dict()

def schema_summary_dict_security_hardened() -> Dict[str, Any]:
    return UHMCA_SCHEMA_V1_1.to_dict()
